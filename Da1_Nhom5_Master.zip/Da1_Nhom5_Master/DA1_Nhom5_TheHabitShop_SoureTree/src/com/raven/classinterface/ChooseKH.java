/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.raven.classinterface;

import com.raven.classmodel.KhachHang;

/**
 *
 * @author ADMIN
 */
public interface ChooseKH {
    public void chonKH(String makh, String tenkh, String sdt);
}
