/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.classmodel;

import java.util.Date;
import java.util.UUID;

/**
 *
 * @author ADMIN
 */
public class HinhThucThanhToan {

    private UUID ID;
    private String ma;
    private String hoadon_id;
    private String thanhtoan_id;
    private HoaDon id_hoaDon;
    private ThanhToan id_thanhToan;
    private UUID id_nguoiTao;
    private Date ngayTao;
    private boolean xoa_trangthai;

    public HinhThucThanhToan() {
    }
    
    public HinhThucThanhToan(UUID ID) {
        this.ID=ID;
    }

    public HinhThucThanhToan(UUID ID, String ma, String hoadon_id, String thanhtoan_id, HoaDon id_hoaDon, ThanhToan id_thanhToan, UUID id_nguoiTao, Date ngayTao, boolean xoa_trangthai) {
        this.ID = ID;
        this.ma = ma;
        this.hoadon_id = hoadon_id;
        this.thanhtoan_id = thanhtoan_id;
        this.id_hoaDon = id_hoaDon;
        this.id_thanhToan = id_thanhToan;
        this.id_nguoiTao = id_nguoiTao;
        this.ngayTao = ngayTao;
        this.xoa_trangthai = xoa_trangthai;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public UUID getID() {
        return ID;
    }

    public void setID(UUID ID) {
        this.ID = ID;
    }

    public String getHoadon_id() {
        return hoadon_id;
    }

    public void setHoadon_id(String hoadon_id) {
        this.hoadon_id = hoadon_id;
    }

    public String getThanhtoan_id() {
        return thanhtoan_id;
    }

    public void setThanhtoan_id(String thanhtoan_id) {
        this.thanhtoan_id = thanhtoan_id;
    }

    public boolean isXoa_trangthai() {
        return xoa_trangthai;
    }

    public void setXoa_trangthai(boolean xoa_trangthai) {
        this.xoa_trangthai = xoa_trangthai;
    }

    public HoaDon getId_hoaDon() {
        return id_hoaDon;
    }

    public void setId_hoaDon(HoaDon id_hoaDon) {
        this.id_hoaDon = id_hoaDon;
    }

    public ThanhToan getId_thanhToan() {
        return id_thanhToan;
    }

    public void setId_thanhToan(ThanhToan id_thanhToan) {
        this.id_thanhToan = id_thanhToan;
    }

    public UUID getId_nguoiTao() {
        return id_nguoiTao;
    }

    public void setId_nguoiTao(UUID id_nguoiTao) {
        this.id_nguoiTao = id_nguoiTao;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

}
