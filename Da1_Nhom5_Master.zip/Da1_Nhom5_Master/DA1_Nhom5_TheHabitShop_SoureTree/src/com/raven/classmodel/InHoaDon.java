/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.classmodel;

import java.io.BufferedInputStream;

/**
 *
 * @author ADMIN
 */
public class InHoaDon {

    public InHoaDon(BufferedInputStream excelBIS) {
    }

    public XemInHoaDon getSheetAt(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
