/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.classmodel;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

/**
 *
 * @author ADMIN
 */
public class ThanhToan {

    private UUID id;
    private String ma;
    private String tenhinhthuc;
    private Integer trangthai;
    private String ghichu;
    private Date ngaytao;
    private boolean xoa_trangthai;

    public ThanhToan() {
    }

    public ThanhToan(UUID id, String ma, String tenhinhthuc, Integer trangthai, String ghichu, Date ngaytao, boolean xoa_trangthai) {
        this.id = id;
        this.ma = ma;
        this.tenhinhthuc = tenhinhthuc;
        this.trangthai = trangthai;
        this.ghichu = ghichu;
        this.ngaytao = ngaytao;
        this.xoa_trangthai = xoa_trangthai;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public Integer getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(Integer trangthai) {
        this.trangthai = trangthai;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }

    public Date getNgaytao() {
        return ngaytao;
    }

    public void setNgaytao(Date ngaytao) {
        this.ngaytao = ngaytao;
    }

    public String getTenhinhthuc() {
        return tenhinhthuc;
    }

    public void setTenhinhthuc(String tenhinhthuc) {
        this.tenhinhthuc = tenhinhthuc;
    }

    public boolean isXoa_trangthai() {
        return xoa_trangthai;
    }

    public void setXoa_trangthai(boolean xoa_trangthai) {
        this.xoa_trangthai = xoa_trangthai;
    }

    @Override
    public String toString() {
        return  tenhinhthuc;
    }

}
