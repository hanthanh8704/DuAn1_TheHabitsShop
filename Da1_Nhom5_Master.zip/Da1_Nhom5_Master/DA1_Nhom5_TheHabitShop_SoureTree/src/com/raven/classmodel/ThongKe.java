/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.classmodel;

/**
 *
 * @author Ninh Than Thanh
 */

public class ThongKe {
    private double tongTien;
    private int thang;

    public ThongKe() {
    }

    public ThongKe(double tongTien, int thang) {
        this.tongTien = tongTien;
        this.thang = thang;
    }

    public ThongKe(double tongTien) {
        this.tongTien = tongTien;
    }
    
    public double getTongTien() {
        return tongTien;
    }

    public void setTongTien(double tongTien) {
        this.tongTien = tongTien;
    }

    public int getThang() {
        return thang;
    }

    public void setThang(int thang) {
        this.thang = thang;
    }

}
