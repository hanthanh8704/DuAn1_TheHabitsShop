/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.classmodel;

/**
 *
 * @author Ninh Than Thanh
 */
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ThongKeTheoKhoangResponse {
    private int ngay;
    private int thang;
    private int nam;
    private double doanhThu;

    public ThongKeTheoKhoangResponse() {
    }

    public ThongKeTheoKhoangResponse( double doanhThu,int ngay) {
        this.doanhThu = doanhThu;
        this.ngay = ngay;
    }

    
    public ThongKeTheoKhoangResponse(int ngay, int thang, int nam, double doanhThu) {
        this.ngay = ngay;
        this.thang = thang;
        this.nam = nam;
        this.doanhThu = doanhThu;
    }

    public ThongKeTheoKhoangResponse(int ngay, int thang, int nam) {
        this.ngay = ngay;
        this.thang = thang;
        this.nam = nam;
    }
    
    public int getNgay() {
        return ngay;
    }

    public int getThang() {
        return thang;
    }

    public int getNam() {
        return nam;
    }

    public double getDoanhThu() {
        return doanhThu;
    }

    public void setNgay(int ngay) {
        this.ngay = ngay;
    }

    public void setThang(int thang) {
        this.thang = thang;
    }

    public void setNam(int nam) {
        this.nam = nam;
    }

    public void setDoanhThu(double doanhThu) {
        this.doanhThu = doanhThu;
    }
    
    
    public String formatNgayThangNam() {
        // Định dạng ngày tháng năm để sử dụng trong biểu đồ
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(new Date(nam - 1900, thang - 1, ngay));
    }
}

