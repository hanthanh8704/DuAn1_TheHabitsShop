/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.classmodel;

import java.util.Date;

/**
 *
 * @author Ninh Than Thanh
 */
public class Voucher_KhachHang {
    private String ma;
    private int trangthai;
    private String id_Voucher;
    private String id_KhachHang;
    private String id_NguoiTao;
    private Date ngayTao;
    private int xoaTT;

    public Voucher_KhachHang() {
    }

    public Voucher_KhachHang(String ma, int trangthai, String id_Voucher, Date ngayTao, int xoaTT) {
        this.ma = ma;
        this.trangthai = trangthai;
        this.id_Voucher = id_Voucher;
        this.ngayTao = ngayTao;
        this.xoaTT = xoaTT;
    }

    public Voucher_KhachHang(String ma, int trangthai, String id_Voucher, String id_KhachHang, String id_NguoiTao, Date ngayTao, int xoaTT) {
        this.ma = ma;
        this.trangthai = trangthai;
        this.id_Voucher = id_Voucher;
        this.id_KhachHang = id_KhachHang;
        this.id_NguoiTao = id_NguoiTao;
        this.ngayTao = ngayTao;
        this.xoaTT = xoaTT;
    }

    public Voucher_KhachHang(String ma, int trangthai, String id_Voucher, String id_KhachHang, String id_NguoiTao, Date ngayTao) {
        this.ma = ma;
        this.trangthai = trangthai;
        this.id_Voucher = id_Voucher;
        this.id_KhachHang = id_KhachHang;
        this.id_NguoiTao = id_NguoiTao;
        this.ngayTao = ngayTao;
    }

    public Voucher_KhachHang(String ma, int trangthai, String id_Voucher, String id_KhachHang, Date ngayTao) {
        this.ma = ma;
        this.trangthai = trangthai;
        this.id_Voucher = id_Voucher;
        this.id_KhachHang = id_KhachHang;
        this.ngayTao = ngayTao;
        
    }

    public Voucher_KhachHang(String ma, int trangthai, String id_Voucher, Date ngayTao) {
        this.ma = ma;
        this.trangthai = trangthai;
        this.id_Voucher = id_Voucher;
        this.ngayTao = ngayTao;
    }

    public int getXoaTT() {
        return xoaTT;
    }

    public void setXoaTT(int xoaTT) {
        this.xoaTT = xoaTT;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    public String getId_Voucher() {
        return id_Voucher;
    }

    public void setId_Voucher(String id_Voucher) {
        this.id_Voucher = id_Voucher;
    }

    public String getId_KhachHang() {
        return id_KhachHang;
    }

    public void setId_KhachHang(String id_KhachHang) {
        this.id_KhachHang = id_KhachHang;
    }

    public String getId_NguoiTao() {
        return id_NguoiTao;
    }

    public void setId_NguoiTao(String id_NguoiTao) {
        this.id_NguoiTao = id_NguoiTao;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }
    
}
