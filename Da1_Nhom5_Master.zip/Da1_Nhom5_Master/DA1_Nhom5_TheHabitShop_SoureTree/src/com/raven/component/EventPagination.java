package com.raven.component;

public interface EventPagination {

    public void pageChanged(int page);
}
