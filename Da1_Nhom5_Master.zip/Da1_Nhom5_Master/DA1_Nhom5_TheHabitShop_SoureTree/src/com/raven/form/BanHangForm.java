/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.raven.form;

import com.raven.classinterface.ChooseKH;
import com.raven.classinterface.TaoMaTuSinh_inf;
import com.raven.classmodel.ChatLieu;
import com.raven.classmodel.GioHang;
import com.raven.classmodel.HinhThucThanhToan;
import com.raven.classmodel.HoaDon;
import com.raven.classmodel.HoaDonChiTiet;
import com.raven.classmodel.KhachHang;
import com.raven.classmodel.KichCo;
import com.raven.classmodel.MauSac;
import com.raven.classmodel.NhanVien;
import com.raven.classmodel.SanPhamChiTiet;
import com.raven.classmodel.ThanhToan;
import com.raven.classmodel.Voucher;
import com.raven.classmodel.XLogin;
import com.raven.reponsitory.BanHangReponsitory;
import com.raven.reponsitory.ChatLieuRepository;
import com.raven.reponsitory.HoaDonRepon;
import com.raven.reponsitory.KhachHang_DAO;
import com.raven.reponsitory.KichCoRepository;
import com.raven.reponsitory.MauSacRepository;
import com.raven.reponsitory.ThanhToanRepon;
import com.raven.service.VoucherService;
import com.raven.service.getidNhanVienService;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN
 */
public class BanHangForm extends javax.swing.JPanel implements ChooseKH {

    private BanHangReponsitory reponBanHang = new BanHangReponsitory();
    private List<HoaDon> listHD = new ArrayList<>();
    private int index = -1;
    public NhanVien nv = new NhanVien();
    public getidNhanVienService getid = new getidNhanVienService();
    private Map<UUID, HoaDonChiTiet> mapGioHang = new HashMap<>();
    private static List<GioHang> listGH = new ArrayList<>();
    private DefaultComboBoxModel<String> dcbHTTT = new DefaultComboBoxModel<>();
    private DefaultComboBoxModel dcbVoucher = new DefaultComboBoxModel<>();
    private HoaDonRepon reponHD = new HoaDonRepon();
    private VoucherService reponVC = new VoucherService();
    private ThanhToanRepon reponTT = new ThanhToanRepon();
    // Call list
    List<SanPhamChiTiet> listMCTSP = new ArrayList<>();
    private HoaDon hoaDon = null;
    private KhachHang khachHang = new KhachHang();
    private NhanVien nhanVien = new NhanVien();
    private KhachHang_DAO dao = new KhachHang_DAO();
    public DefaultTableModel modelSP = new DefaultTableModel();
    public DefaultTableModel modelGH = new DefaultTableModel();
    private DefaultComboBoxModel dcbMauSac = new DefaultComboBoxModel();
    private DefaultComboBoxModel dcbKichCo = new DefaultComboBoxModel();
    private DefaultComboBoxModel dcbChatLieu = new DefaultComboBoxModel();
    private MauSacRepository reponMauSac = new MauSacRepository();
    private ChatLieuRepository reponChatLieu = new ChatLieuRepository();
    private KichCoRepository reponKichCo = new KichCoRepository();

    // tinhtrang = 0 =  "Chờ Thanh Toán"; 
    // tinhtrang = 1 = "Đã Thanh Toán";
    /**
     * Creates new form HoaDonForm
     */
    public BanHangForm() {
        initComponents();
        loadCBB();
        loadCBBVoucher();
        loadCBBKichCo();
        loadCBBChatLieu();
        loadCBBMauSac();
        txtTienMat.setEnabled(false);
        // Create a KeyStroke for the Enter key
        KeyStroke enterKey = KeyStroke.getKeyStroke("ENTER");
        // Create an Action to be performed when Enter key is pressed
        Action enterAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle the action, for example, get the selected row
                int selectedRow = tblGioHang.getSelectedRow();
                if (selectedRow != -1) {
                    suasoluongsp();
                    tinhTongTien();
                }
            }
        };
        // Add the Enter key binding to the JTable
        tblGioHang.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(enterKey, "Enter");
        tblGioHang.getActionMap().put("Enter", enterAction);
        loadTableSanPham(reponBanHang.getAllSP());
        loadTableHoaDon(reponBanHang.getAllHD());
        List<HoaDon> list = reponBanHang.getAllHD();
        tuDongTinhTienMatKhachDua();
        tuDongTinhTienChuyenKhoanKhachDua();
    }

    public static JPanel createPanel() {
        BanHangForm panel = new BanHangForm();
        // Cấu hình JPanel
        return panel;
    }

    void cleanData() {

    }

    // tính tiền thừa của hóa đơn
    private void tuDongTinhTienMatKhachDua() {
        txtTienMat.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateTienThua();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateTienThua();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // Not used for plain text components
            }

            private void updateTienThua() {
                try {
                    String tienKhachDuaStr = txtTienMat.getText();
                    if (!tienKhachDuaStr.isEmpty()) {
                        BigDecimal tienKhachDua = new BigDecimal(tienKhachDuaStr);
                        BigDecimal tienThua = BigDecimal.ZERO;
                        if (cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {

                            tienThua = tienKhachDua.subtract(tinhTongTien());
                        } else {
                            tienThua = tienKhachDua.subtract(BigDecimal.valueOf(Double.parseDouble(txtTienSauGiamGia.getText())));
                        }

                        if (tienThua.compareTo(BigDecimal.ZERO) >= 0) {
                            lblTienThuaThieu.setText("Tiền thừa:");
                        } else {
                            lblTienThuaThieu.setText("Tiền thiếu:");
                        }
                        txtTienThua.setText(String.valueOf(tienThua.abs()));
                    } else {
                        // Chuỗi trống, có thể thực hiện các xử lý khác tùy thuộc vào yêu cầu của bạn.
                        // Hiện tại, tôi chỉ đặt lblTienThua và lblTienThuaThieu về giá trị mặc định.
                        txtTienThua.setText("0.000");
                        lblTienThuaThieu.setText("Tiền thừa:");
                    }
                } catch (NumberFormatException ex) {
                    txtTienThua.setText("Nhập số hợp lệ");
                    lblTienThuaThieu.setText("");
                }
            }
        });
    }
    // tính tiền thừa của hóa đơn

    private void tuDongTinhTienChuyenKhoanKhachDua() {
        txtTienCK.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateTienThua();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateTienThua();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // Not used for plain text components
            }

            private void updateTienThua() {
                try {
                    String tienKhachDuaStr = txtTienCK.getText();
                    if (!tienKhachDuaStr.isEmpty()) {
                        BigDecimal tienKhachDua = new BigDecimal(tienKhachDuaStr);
                        BigDecimal tienThua = BigDecimal.ZERO;
                        if (cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
                            tienThua = tienKhachDua.subtract(tinhTongTien());
                        } else {
                            tienThua = tienKhachDua.subtract(BigDecimal.valueOf(Double.parseDouble(txtTienSauGiamGia.getText())));
                        }
                        if (tienThua.compareTo(BigDecimal.ZERO) >= 0) {
                            lblTienThuaThieu.setText("Tiền thừa:");
                        } else {
                            lblTienThuaThieu.setText("Tiền thiếu:");
                        }
                        txtTienThua.setText(String.valueOf(tienThua.abs()));
                    } else {
                        // Chuỗi trống, có thể thực hiện các xử lý khác tùy thuộc vào yêu cầu của bạn.
                        // Hiện tại, tôi chỉ đặt lblTienThua và lblTienThuaThieu về giá trị mặc định.
                        txtTienThua.setText("0.000");
                        lblTienThuaThieu.setText("Tiền thừa:");
                    }
                } catch (NumberFormatException ex) {
                    txtTienThua.setText("Nhập số hợp lệ");
                    lblTienThuaThieu.setText("");
                }
            }
        });
    }
    // 

    public void loadTableHoaDonCT(List<HoaDonChiTiet> listHDCT) {
        modelGH = (DefaultTableModel) tblGioHang.getModel();
        modelGH.setRowCount(0);
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
        int stt = 1;
        for (HoaDonChiTiet h : listHDCT) {
            modelGH.addRow(new Object[]{
                stt++,
                h.getMaspct(),
                h.getTensp(),
                h.getTenmausac(),
                h.getTenchatlieu(),
                h.getTenkichco(),
                h.getSoLuong(),
                NumberFormat.getInstance().format(h.getGia_SPCT()),
                NumberFormat.getInstance().format((h.getTongTienCuaHDCT()))
            });
        }
        System.out.println("lLoad hdct");
    }

    void loadTableHoaDon(List<HoaDon> listHD) {
        DefaultTableModel model = (DefaultTableModel) tblHoaDon.getModel();
        model.setRowCount(0);
        int stt = 1;
        String tinhtrang = "";
        for (HoaDon h : listHD) {
            if (h.getTinhTrang() == 0) {
                tinhtrang = "Chờ Thanh Toán";
            }
            model.addRow(new Object[]{
                stt++,
                h.getMa(),
                h.getManhanvien(),
                h.getNgayTao(),
                tinhtrang
            });
        }
    }

    public void loadTableSanPham(List<SanPhamChiTiet> listSPCT) {
        modelSP = (DefaultTableModel) tblSanPham.getModel();
        modelSP.setRowCount(0);
        int stt = 1;
        for (SanPhamChiTiet s : listSPCT) {
            modelSP.addRow(new Object[]{
                stt++,
                s.getMa(),
                s.getTenSanPham().getTenSP(),
                s.getTenMauSac().getTenMauSac(),
                s.getTenChatlieu().getTen(),
                s.getTenKichCo().getTenKichCo(),
                s.getTenNhanHieu().getTen(),
                s.getSoLuong(),
                NumberFormat.getInstance().format(s.getGiaBan1()), //  hoaDon.getTongTienHoaDon() == null ? "0" : NumberFormat.getInstance().format(hoaDon.getTongTienHoaDon()),
            });
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane3 = new javax.swing.JTabbedPane();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGioHang = new javax.swing.JTable();
        jPanel15 = new javax.swing.JPanel();
        txt_TimKiem = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnXoaSPGH = new javax.swing.JButton();
        btnHuyHoaDon = new javax.swing.JButton();
        btnSuaSPTRONGGH = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        btnQuetMa = new javax.swing.JButton();
        btnThanhToan = new javax.swing.JButton();
        btnToaHoaDon = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtMaKH = new javax.swing.JTextField();
        btnFindKH = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        txtTenKH = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel9 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cbbHinhThuc = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtTienCK = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        lblTienThuaThieu = new javax.swing.JLabel();
        txtMaHD = new javax.swing.JTextField();
        txtTienThua = new javax.swing.JTextField();
        txtNgayTao = new javax.swing.JTextField();
        txtMaNV = new javax.swing.JTextField();
        txtTongTien = new javax.swing.JTextField();
        txtTienMat = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtGhiChu = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        cbbGiamGia = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        txtTienSauGiamGia = new javax.swing.JTextField();
        btnTK = new javax.swing.JButton();
        cbbMauSac = new javax.swing.JComboBox<>();
        cbbChatLieu = new javax.swing.JComboBox<>();
        cbbKichCo = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Bán Hàng", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sản Phẩm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã SPCT", "Tên SP", "Màu Sắc", "Chất Liệu", "Size", "Nhãn Hiệu", "SL SP tồn tại", "Giá Bán"
            }
        ));
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblSanPham);
        if (tblSanPham.getColumnModel().getColumnCount() > 0) {
            tblSanPham.getColumnModel().getColumn(0).setMinWidth(50);
            tblSanPham.getColumnModel().getColumn(0).setMaxWidth(50);
            tblSanPham.getColumnModel().getColumn(8).setResizable(false);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 21, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Giỏ Hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã SPCT", "Tên SP", "Màu Sắc", "Chất Liệu", "Size", "Số Lượng", "Giá Bán", "Thành Tiền", "Chọn"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblGioHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGioHangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGioHang);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
        );

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 195, Short.MAX_VALUE)
        );

        txt_TimKiem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_TimKiemMouseClicked(evt);
            }
        });
        txt_TimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_TimKiemKeyReleased(evt);
            }
        });

        jLabel10.setText("Tìm Kiếm");

        btnXoaSPGH.setText("Xóa Sản Phẩm");
        btnXoaSPGH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnXoaSPGHMouseClicked(evt);
            }
        });
        btnXoaSPGH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaSPGHActionPerformed(evt);
            }
        });

        btnHuyHoaDon.setText("Hủy Hóa Đơn");
        btnHuyHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyHoaDonActionPerformed(evt);
            }
        });

        btnSuaSPTRONGGH.setText("Sửa Số Lượng SP");
        btnSuaSPTRONGGH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSuaSPTRONGGHMouseClicked(evt);
            }
        });

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hóa Đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã HĐ", "Mã Nhân Viên", "Ngày Tạo", "Trạng Thái"
            }
        ));
        tblHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHoaDonMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblHoaDon);
        if (tblHoaDon.getColumnModel().getColumnCount() > 0) {
            tblHoaDon.getColumnModel().getColumn(0).setMinWidth(50);
            tblHoaDon.getColumnModel().getColumn(0).setMaxWidth(50);
        }

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        btnQuetMa.setText("Quét Mã Sản Phẩm");
        btnQuetMa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnQuetMaMouseClicked(evt);
            }
        });
        btnQuetMa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuetMaActionPerformed(evt);
            }
        });

        btnThanhToan.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnThanhToan.setText("Thanh Toán");
        btnThanhToan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnThanhToanMouseClicked(evt);
            }
        });
        btnThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhToanActionPerformed(evt);
            }
        });

        btnToaHoaDon.setText("Tạo Hóa Đơn");
        btnToaHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnToaHoaDonMouseClicked(evt);
            }
        });

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thông Tin Đơn Hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thông Tin Khách Hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jLabel12.setText("Mã KH");

        txtMaKH.setEditable(false);
        txtMaKH.setBackground(new java.awt.Color(255, 255, 255));
        txtMaKH.setText("KH000");
        txtMaKH.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnFindKH.setBackground(new java.awt.Color(0, 204, 255));
        btnFindKH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/5.png"))); // NOI18N
        btnFindKH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFindKHMouseClicked(evt);
            }
        });
        btnFindKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindKHActionPerformed(evt);
            }
        });

        jLabel13.setText("Tên KH");

        txtTenKH.setEditable(false);
        txtTenKH.setBackground(new java.awt.Color(255, 255, 255));
        txtTenKH.setText("Khách Hàng Lẻ");
        txtTenKH.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setText("SDT");

        txtSDT.setEditable(false);
        txtSDT.setBackground(new java.awt.Color(255, 255, 255));
        txtSDT.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtSDT)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(txtMaKH)
                                .addGap(18, 18, 18)
                                .addComponent(btnFindKH, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE)))
                .addGap(54, 54, 54))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMaKH, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)))
                    .addComponent(btnFindKH))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(txtTenKH)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thông Tin Đơn Hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jLabel8.setText("Hình Thức");

        jLabel2.setText("Ngày Tạo");

        cbbHinhThuc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbHinhThuc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbHinhThucItemStateChanged(evt);
            }
        });
        cbbHinhThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbHinhThucActionPerformed(evt);
            }
        });

        jLabel3.setText("Mã NV");

        jLabel9.setText("Tiền CK");

        jLabel4.setText("Tổng Tiền");

        txtTienCK.setText("0");
        txtTienCK.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setText("Tiền Mặt ");

        lblTienThuaThieu.setText("Tiền Thừa");

        txtMaHD.setEditable(false);
        txtMaHD.setBackground(new java.awt.Color(255, 255, 255));
        txtMaHD.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtTienThua.setEditable(false);
        txtTienThua.setBackground(new java.awt.Color(255, 255, 255));
        txtTienThua.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtNgayTao.setEditable(false);
        txtNgayTao.setBackground(new java.awt.Color(255, 255, 255));
        txtNgayTao.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtMaNV.setEditable(false);
        txtMaNV.setBackground(new java.awt.Color(255, 255, 255));
        txtMaNV.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtMaNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMaNVActionPerformed(evt);
            }
        });

        txtTongTien.setEditable(false);
        txtTongTien.setBackground(new java.awt.Color(255, 255, 255));
        txtTongTien.setText("0");
        txtTongTien.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtTienMat.setText("0");
        txtTienMat.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtTienMat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTienMatActionPerformed(evt);
            }
        });

        jLabel1.setText("Mã HD");

        jLabel14.setText("Ghi Chú");

        txtGhiChu.setColumns(20);
        txtGhiChu.setRows(5);
        jScrollPane3.setViewportView(txtGhiChu);

        jLabel7.setText("Chọn Voucher");

        cbbGiamGia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbGiamGia.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbGiamGiaItemStateChanged(evt);
            }
        });
        cbbGiamGia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbGiamGiaActionPerformed(evt);
            }
        });

        jLabel11.setText("Tiền Sau Giảm Giá");

        txtTienSauGiamGia.setEditable(false);
        txtTienSauGiamGia.setBackground(new java.awt.Color(255, 255, 255));
        txtTienSauGiamGia.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(lblTienThuaThieu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(160, 160, 160))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtTienSauGiamGia, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbbGiamGia, javax.swing.GroupLayout.Alignment.LEADING, 0, 186, Short.MAX_VALUE)
                            .addComponent(txtTongTien, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMaNV, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNgayTao, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMaHD, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbbHinhThuc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTienThua, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTienMat, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                            .addComponent(txtTienCK)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel9Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cbbGiamGia, cbbHinhThuc, jScrollPane3, txtMaHD, txtMaNV, txtNgayTao, txtTienCK, txtTienMat, txtTienSauGiamGia, txtTienThua, txtTongTien});

        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMaHD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNgayTao, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbGiamGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtTienSauGiamGia, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbHinhThuc, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTienMat, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTienCK, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTienThuaThieu)
                    .addComponent(txtTienThua, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addContainerGap(105, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Bán Hàng", jPanel2);

        btnTK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/edit.png"))); // NOI18N
        btnTK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTKMouseClicked(evt);
            }
        });

        cbbMauSac.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbMauSac.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbMauSacItemStateChanged(evt);
            }
        });

        cbbChatLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbChatLieu.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbChatLieuItemStateChanged(evt);
            }
        });

        cbbKichCo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbKichCo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbKichCoItemStateChanged(evt);
            }
        });

        jLabel15.setText("Màu Sắc");

        jLabel16.setText("Chất Liệu");

        jLabel17.setText("Kích Cỡ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_TimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnTK)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbbMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addComponent(cbbChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel17)
                                .addGap(18, 18, 18)
                                .addComponent(cbbKichCo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnToaHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnThanhToan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnQuetMa, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnHuyHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnXoaSPGH, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(btnSuaSPTRONGGH, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(2, 2, 2)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(btnThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnHuyHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnQuetMa, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(5, 5, 5)
                                .addComponent(btnXoaSPGH, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnToaHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(btnSuaSPTRONGGH, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(242, 242, 242))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel10)
                                        .addComponent(txt_TimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btnTK)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel15)
                                        .addComponent(cbbMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel16)
                                        .addComponent(cbbChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel17)
                                        .addComponent(cbbKichCo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(52, 52, 52))))
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addhoaDOnCT() {
        HoaDonChiTiet hdct = readFormHDCT();
    }
    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        // TODO add your handling code here:
        if (tblHoaDon.getSelectedRow() < 0) {
            JOptionPane.showMessageDialog(this, "Hãy chọn hóa đơn trước khi thêm sản phẩm");
        } else {
            int index = tblSanPham.getSelectedRow();
            HoaDonChiTiet hdct = readFormHDCT();
            if (reponBanHang.themSPGioHang(hdct) != 0) {
                System.out.println("Them thanh cong");
                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(txtMaHD.getText()));
                loadTableSanPham(reponBanHang.getAllSP());
                tinhTongTien();
            }
        }
    }//GEN-LAST:event_tblSanPhamMouseClicked

    TaoMaTuSinh_inf genMaHDCT = new TaoMaTuSinh_inf() {
        @Override
        public String maTuSinh() {
            int maTuSinh = new Random().nextInt(1000000);
            return "HDCT" + maTuSinh;
        }
    };
    int soluong = 0;

    boolean checkValidateSoLuong() {
        try {
            soluong = Integer.parseInt(JOptionPane.showInputDialog(this, "Nhập số lượng"));
            // Kiểm tra số lượng phải lớn hơn 0
            if (soluong <= 0) {
                JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!");
                return false;
            }

            // Kiểm tra số lượng nhập vào có lớn hơn số lượng trong JTable hay không
            int soLuongTrongBang = Integer.parseInt(tblSanPham.getValueAt(tblSanPham.getSelectedRow(), 7).toString());
            if (soluong > soLuongTrongBang) {
                JOptionPane.showMessageDialog(this, "Số lượng vượt quá số lượng có sẵn!");
                return false;
            }
            // Nếu số lượng hợp lệ và đủ, trả về true
            return true;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số nguyên dương!");
            return false;
        }
    }

    // check số lượng quét qr
    boolean checkValidateSoLuongQuetQR() {
        try {
            soluong = Integer.parseInt(JOptionPane.showInputDialog(this, "Nhập số lượng"));
            // Kiểm tra số lượng phải lớn hơn 0
            if (soluong <= 0) {
                JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!");
                return false;
            }

            // Kiểm tra số lượng nhập vào có lớn hơn số lượng trong JTable hay không
            int soLuongTrongBang = reponBanHang.selecSanPhamChiTietByID(reponBanHang.selectIDSPCTByMaSPCT(QR_Code.maSPCT));
            if (soluong > soLuongTrongBang) {
                JOptionPane.showMessageDialog(this, "Số lượng vượt quá số lượng có sẵn!");
                return false;
            }
            // Nếu số lượng hợp lệ và đủ, trả về true
            return true;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số nguyên dương!");
            return false;
        }
    }

    HoaDonChiTiet readFormHDCT() {
        if (checkValidateSoLuong()) {
            int index = tblSanPham.getSelectedRow();
            String idHd = reponBanHang.selectIdHDByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString());
            String idSPCT = reponBanHang.selectIDSPCTByMaSPCT(tblSanPham.getValueAt(index, 1).toString());
            String id_nguoitao = XLogin.user.getId().toString();

            System.out.println(idHd);
            System.out.println(idSPCT);
            System.out.println(id_nguoitao);

            return new HoaDonChiTiet(genMaHDCT.maTuSinh(),
                    soluong,
                    idHd,
                    idSPCT,
                    id_nguoitao,
                    0
            );
        } else {
            return null;
        }
    }


    private void tblHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHoaDonMouseClicked
        txtMaHD.setText(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString());
        // String mahd = reponBanHang.selectIdHDByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString());
        loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString()));
        tinhTongTien();
        index = tblHoaDon.getSelectedRow();
        showDataHoaDon(this.index);
//        cbbGiamGia.setSelectedItem("Chọn Voucher");
//        lblTienGiamCuaVoucher.setText("0");
    }//GEN-LAST:event_tblHoaDonMouseClicked

    private void btnHuyHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyHoaDonActionPerformed
        // TODO add your handling code here:
        if (tblHoaDon.getSelectedRow() < 0) {
            JOptionPane.showMessageDialog(this, "Mời chọn dòng");
        } else {
            int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn hủy hóa đơn không", "abc", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                if (tblGioHang.getRowCount() <= 0) {
                    String mahd = reponBanHang.selectIdHDByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString());
                    reponBanHang.huyHoaDonKhongCoHang(mahd);
                    JOptionPane.showMessageDialog(this, "Hủy Thành Công");
                    loadTableHoaDon(reponBanHang.getAllHD());
                    System.out.println(mahd);
                } else {
                    for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                        String mahd = reponBanHang.selectIdHDByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString());
                        String maspct = reponBanHang.selectIDSPCTByMaSPCT(tblGioHang.getValueAt(i, 1).toString());
                        String mahdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(mahd, maspct);
                        reponBanHang.huyHoaDon(mahd, mahdct, maspct);
                    }
                    JOptionPane.showMessageDialog(this, "Hủy Thành Công");
                }
                loadTableHoaDon(reponBanHang.getAllHD());
                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(""));
                loadTableSanPham(reponBanHang.getAllSP());
            }
        }
//        showDataHoaDon();
    }//GEN-LAST:event_btnHuyHoaDonActionPerformed

    private void btnXoaSPGHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnXoaSPGHMouseClicked
        // TODO add your handling code here:
        //int index = tblGioHang.getSelectedRow();
        int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn xóa không", "thông báo", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            String mahd = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
            System.out.println("mahd" + mahd);
            for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                if (null != tblGioHang.getValueAt(i, 9)) {
                    String check = tblGioHang.getValueAt(i, 9).toString();
                    if (check.endsWith("true")) {
                        String maspct = tblGioHang.getValueAt(i, 1).toString();
                        String mahdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(reponBanHang.selectIdHDByMaHD(mahd), reponBanHang.selectIDSPCTByMaSPCT(maspct));
                        reponBanHang.xoaHoaDonChiTiet(reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(reponBanHang.selectIdHDByMaHD(mahd),
                                reponBanHang.selectIDSPCTByMaSPCT(maspct)),
                                reponBanHang.selectIDSPCTByMaSPCT(maspct),
                                reponBanHang.selectIdHDByMaHD(mahd)
                        );
                        System.out.println("id_spct : " + reponBanHang.selectIDSPCTByMaSPCT(maspct));
                    }
                }
            }
            JOptionPane.showMessageDialog(this, "Xoa thanh cong");
            loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
            loadTableSanPham(reponBanHang.getAllSP());
            tinhTongTien();
        }
    }//GEN-LAST:event_btnXoaSPGHMouseClicked

    private void btnXoaSPGHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaSPGHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnXoaSPGHActionPerformed

    private void tblGioHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGioHangMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblGioHangMouseClicked

//        @mahdct UNIQUEIDENTIFIER,
//    @maspct UNIQUEIDENTIFIER,
//    @mahd UNIQUEIDENTIFIER,
//    @soluongthaydoi INT,
//    @soluongtronggiohang INT

    private void btnSuaSPTRONGGHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSuaSPTRONGGHMouseClicked
        suasoluongsp();
    }//GEN-LAST:event_btnSuaSPTRONGGHMouseClicked

    // thanh toán bill
    void ThanhToanBill() throws ParseException {
        HoaDon hd = new HoaDon();
    }

    boolean checkThanhToanTienMat() {
        if (txtTienMat.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tiền mặt khách đưa không được để trống");
            return false;
        }
        try {
            if (Double.parseDouble(txtTienMat.getText()) < 0) {

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tiền phải là số");
            return false;
        }
        return true;
    }

    boolean checkThanhToanTienCK() {
        if (txtTienCK.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tiền CK khách đưa không được để trống");
            return false;
        }
        try {
            if (Double.parseDouble(txtTienCK.getText()) < 0) {

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tiền phải là số");
            return false;
        }
        return true;
    }

    private void btnThanhToanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnThanhToanMouseClicked
        // TODO add your handling code here:
        // check thanh toán tiên mặt
        if (cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
            if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                if (checkThanhToanTienMat()) {
                    if (Double.valueOf(txtTienMat.getText()) >= Double.valueOf(txtTongTien.getText())) {
                        int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn thanh toán không", "THANH TOÁN", JOptionPane.YES_NO_OPTION);
                        if (choice == JOptionPane.YES_OPTION) {
                            String mahd = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
                            String id_hd = reponBanHang.selectIdHDByMaHD(mahd);
                            String id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                            String id_tt = reponBanHang.selectThanhToanByIdTenThanhToan(cbbHinhThuc.getSelectedItem().toString());
                            if (tblHoaDon.getSelectedRow() < 0) {
                                JOptionPane.showMessageDialog(this, "Mời chọn hóa đơn để thanh toán");
                            } else {
                                for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                                    // lấy gt từ bảng
                                    String maspct = tblGioHang.getValueAt(i, 1).toString(); // lấy gt từ bảng
                                    String id_hdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(reponBanHang.selectIdHDByMaHD(mahd), reponBanHang.selectIDSPCTByMaSPCT(maspct));
                                    String id_spct = reponBanHang.selectIDSPCTByMaSPCT(maspct);

                                    if (txtTenKH.getText().equalsIgnoreCase("Khách Hàng Lẻ")) {
                                        id_kh = reponBanHang.selectIdKhachHangByTen("KH000");
                                        System.out.println("khachHangle");
                                    } else {
                                        id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                                        System.out.println("khachHangin");
                                    }
                                    BigDecimal tienmat = null;
                                    BigDecimal tienthe = null;
                                    System.out.println("---------------------------------------------------");
                                    System.out.println("Id_spct : " + id_spct);
                                    System.out.println("id_hd : " + id_hd);
                                    System.out.println("tinhTongTien : " + tinhTongTien());
                                    System.out.println("id_hdct : " + id_hdct);
                                    System.out.println("id_kh : " + id_kh);
                                    System.out.println("id_tt : " + id_tt);
                                    System.out.println("tienmat : " + tienmat);
                                    System.out.println("tienthe : " + tienthe);
                                    System.out.println("---------------------------------------------------");
                                    if (!txtTienCK.getText().trim().isEmpty()) {
                                        tienthe = new BigDecimal(txtTienCK.getText());
                                    }
                                    if (!txtTienMat.getText().trim().isEmpty()) {
                                        tienmat = new BigDecimal(txtTienMat.getText());
                                    }
                                    BigDecimal tongtiencuahoadon = tinhTongTien();
                                    if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                                        tienthe = null;
                                        tienmat = tongtiencuahoadon;
                                    } else if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
                                        tienmat = null;
                                        tienthe = tongtiencuahoadon;
                                    }
                                    try {
                                        reponBanHang.thanhToanHoaDon(id_spct, id_hd,
                                                tinhTongTien(), id_hdct,
                                                id_kh, id_tt,
                                                genMaHTTT.maTuSinh(),
                                                tienmat, tienthe, txtGhiChu.getText());
                                    } catch (SQLException ex) {
                                        Logger.getLogger(BanHangForm.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                                JOptionPane.showMessageDialog(this, "Thanh Toán Thành Công");

                                System.out.println("Tổng tiền : " + BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText())));

                                reponBanHang.themHinhThucThanhToan(id_hd, BigDecimal.valueOf(
                                        Double.parseDouble(txtTongTien.getText())), id_kh,
                                        id_tt, genMaHTTT.maTuSinh(), "0");
                                loadTableHoaDon(reponBanHang.getAllHD());
                                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(""));
                                cleanKhachHang();
                                cleanForm();
                                return;
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Tiền Khách Đưa Thiếu");
                        return;
                    }
                }
            }
            if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {

                // check tiền chuyển khoản
                if (checkThanhToanTienCK()) {
                    if (Double.valueOf(txtTienCK.getText()) >= Double.valueOf(txtTongTien.getText())) {
                        int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn thanh toán không", "THANH TOÁN", JOptionPane.YES_NO_OPTION);
                        if (choice == JOptionPane.YES_OPTION) {
                            String mahd = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
                            String id_hd = reponBanHang.selectIdHDByMaHD(mahd);
                            String id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                            String id_tt = reponBanHang.selectThanhToanByIdTenThanhToan(cbbHinhThuc.getSelectedItem().toString());
                            if (tblHoaDon.getSelectedRow() < 0) {
                                JOptionPane.showMessageDialog(this, "Mời chọn hóa đơn để thanh toán");
                            } else {
                                for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                                    // lấy gt từ bảng
                                    String maspct = tblGioHang.getValueAt(i, 1).toString(); // lấy gt từ bảng
                                    String id_hdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(reponBanHang.selectIdHDByMaHD(mahd), reponBanHang.selectIDSPCTByMaSPCT(maspct));
                                    String id_spct = reponBanHang.selectIDSPCTByMaSPCT(maspct);

                                    if (txtTenKH.getText().equalsIgnoreCase("Khách Hàng Lẻ")) {
                                        id_kh = reponBanHang.selectIdKhachHangByTen("KH000");
                                        System.out.println("khachHangle");
                                    } else {
                                        id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                                        System.out.println("khachHangin");
                                    }
                                    BigDecimal tienmat = null;
                                    BigDecimal tienthe = null;
                                    if (!txtTienCK.getText().trim().isEmpty()) {
                                        tienthe = new BigDecimal(txtTienCK.getText());
                                    }
                                    if (!txtTienMat.getText().trim().isEmpty()) {
                                        tienmat = new BigDecimal(txtTienMat.getText());
                                    }
                                    BigDecimal tongtiencuahoadon = tinhTongTien();
                                    //nếu tiền mặt nhỏ hơn tổng tiền tien mat = tong tien - tien mat
                                    // if (tienmat.compareTo(tongtiencuahoadon) < 0) {
                                    //       tienmat = tongtiencuahoadon.subtract(tienmat);
                                    // } else {
                                    //       tienmat = tienmat.subtract(tongtiencuahoadon);
                                    // }
                                    if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                                        tienthe = null;
                                        tienmat = tongtiencuahoadon;
                                    } else if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
                                        tienmat = null;
                                        tienthe = tongtiencuahoadon;
                                    }
                                    System.out.println("---------------------------------------------------");
                                    System.out.println("Id_spct : " + id_spct);
                                    System.out.println("id_hd : " + id_hd);
                                    System.out.println("tinhTongTien : " + tinhTongTien());
                                    System.out.println("id_hdct : " + id_hdct);
                                    System.out.println("id_kh : " + id_kh);
                                    System.out.println("id_tt : " + id_tt);
                                    System.out.println("tienmat : " + tienmat);
                                    System.out.println("tienthe : " + tienthe);
                                    System.out.println("---------------------------------------------------");
                                    try {
                                        reponBanHang.thanhToanHoaDon(id_spct, id_hd,
                                                tinhTongTien(), id_hdct,
                                                id_kh, id_tt,
                                                genMaHTTT.maTuSinh(),
                                                tienmat, tienthe, txtGhiChu.getText());
                                        String magd = "";
                                        do {
                                            magd = JOptionPane.showInputDialog(this, "Vui lòng nhập mã giao dịch");
                                            System.out.println("Mã giao dich cua ba la : " + magd);
                                            if (magd == null) {
                                                JOptionPane.showMessageDialog(this, "Bạn phải nhập mã giao dịch để thanh toán");
                                            } else if (magd.length() > 8) {
                                                JOptionPane.showMessageDialog(this, "Mã giao dịch không được quá 8 số");
                                            } else {
                                                break;
                                            }
                                        } while (magd == null || magd.isEmpty() || magd.length() > 8);
                                        reponBanHang.themHinhThucThanhToan(id_hd, BigDecimal.valueOf(
                                                Double.parseDouble(txtTongTien.getText())), id_kh, id_tt, genMaHTTT.maTuSinh(), magd);

                                    } catch (SQLException ex) {
                                        Logger.getLogger(BanHangForm.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                                JOptionPane.showMessageDialog(this, "Thanh Toán Thành Công");
                                System.out.println("Tổng tiền : " + BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText())));
                                loadTableHoaDon(reponBanHang.getAllHD());
                                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(""));
                                cleanKhachHang();
                                cleanForm();
                                return;
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Tiền Khách Đưa Thiếu");
                        System.out.println("Tien thieu : " + Double.valueOf(txtTienCK.getText()) + " " + Double.valueOf(txtTongTien.getText()));
                        return;
                    }
                }
            }
        } else {
            if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                if (checkThanhToanTienMat()) {
                    //BigDecimal tienmat = BigDecimal.valueOf(Double.valueOf(txtTienMat.getText()));
                    //BigDecimal tongtien = BigDecimal.valueOf(Double.valueOf(txtTongTien.getText()));
                    if (Double.valueOf(txtTienMat.getText()) >= Double.valueOf(txtTienSauGiamGia.getText())) {
                        int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn thanh toán không", "THANH TOÁN", JOptionPane.YES_NO_OPTION);
                        if (choice == JOptionPane.YES_OPTION) {
                            String mahd = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
                            String id_hd = reponBanHang.selectIdHDByMaHD(mahd);
                            String id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                            String id_tt = reponBanHang.selectThanhToanByIdTenThanhToan(cbbHinhThuc.getSelectedItem().toString());
                            Voucher vc = (Voucher) cbbGiamGia.getSelectedItem();
                            System.out.println("Id cua voucher : " + vc.getId());
                            String id_vc = vc.getId().toString();

                            if (tblHoaDon.getSelectedRow() < 0) {
                                JOptionPane.showMessageDialog(this, "Mời chọn hóa đơn để thanh toán");
                            } else {
                                for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                                    // lấy gt từ bảng
                                    String maspct = tblGioHang.getValueAt(i, 1).toString(); // lấy gt từ bảng
                                    String id_hdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(
                                            reponBanHang.selectIdHDByMaHD(mahd), reponBanHang.selectIDSPCTByMaSPCT(maspct));
                                    String id_spct = reponBanHang.selectIDSPCTByMaSPCT(maspct);

                                    if (txtTenKH.getText().equalsIgnoreCase("Khách Hàng Lẻ")) {
                                        id_kh = reponBanHang.selectIdKhachHangByTen("KH000");
                                        System.out.println("khachHangle");
                                    } else {
                                        id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                                        System.out.println("khachHangin");
                                    }
                                    BigDecimal tienmat = null;
                                    BigDecimal tienthe = null;
                                    if (!txtTienCK.getText().trim().isEmpty()) {
                                        tienthe = new BigDecimal(txtTienCK.getText());
                                    }
                                    if (!txtTienMat.getText().trim().isEmpty()) {
                                        tienmat = new BigDecimal(txtTienMat.getText());
                                    }
                                    BigDecimal tongtiencuahoadon = tinhTongTien();
                                    if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                                        tienthe = null;
                                        tienmat = tongtiencuahoadon;
                                    } else if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
                                        tienmat = null;
                                        tienthe = tongtiencuahoadon;
                                    }
                                    try {
                                        reponBanHang.thanhToanHoaDonVoucher(id_spct, id_hd,
                                                tinhTongTien(), id_hdct,
                                                id_kh, id_tt,
                                                genMaHTTT.maTuSinh(),
                                                tienmat, tienthe, id_vc,
                                                genMaVC_KH.maTuSinh(),
                                                BigDecimal.valueOf(Double.parseDouble(txtTienSauGiamGia.getText())), txtGhiChu.getText());

                                    } catch (SQLException ex) {
                                        Logger.getLogger(BanHangForm.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                                JOptionPane.showMessageDialog(this, "Thanh Toán Thành Công");
                                System.out.println("Tổng tiền : " + BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText())));

                                reponBanHang.themHinhThucThanhToan(id_hd, BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText())), id_kh, id_tt, genMaHTTT.maTuSinh(), "0");
                                loadTableHoaDon(reponBanHang.getAllHD());
                                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(""));
                                cleanKhachHang();
                                cleanForm();
                                return;
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Tiền Khách Đưa Thiếu");
                        return;
                    }
                }
            }
            if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
                // check tiền chuyển khoản
                if (checkThanhToanTienCK()) {
                    if (Double.valueOf(txtTienCK.getText()) >= Double.valueOf(txtTienSauGiamGia.getText())) {
                        int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn thanh toán không", "THANH TOÁN", JOptionPane.YES_NO_OPTION);
                        if (choice == JOptionPane.YES_OPTION) {
                            String mahd = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
                            String id_hd = reponBanHang.selectIdHDByMaHD(mahd);
                            String id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                            String id_tt = reponBanHang.selectThanhToanByIdTenThanhToan(cbbHinhThuc.getSelectedItem().toString());
                            if (tblHoaDon.getSelectedRow() < 0) {
                                JOptionPane.showMessageDialog(this, "Mời chọn hóa đơn để thanh toán");
                            } else {
                                for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                                    // lấy gt từ bảng
                                    String maspct = tblGioHang.getValueAt(i, 1).toString(); // lấy gt từ bảng
                                    String id_hdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(reponBanHang.selectIdHDByMaHD(mahd), reponBanHang.selectIDSPCTByMaSPCT(maspct));
                                    String id_spct = reponBanHang.selectIDSPCTByMaSPCT(maspct);
                                    Voucher vc = (Voucher) cbbGiamGia.getSelectedItem();
                                    String id_vc = vc.getId().toString();
                                    if (txtTenKH.getText().equalsIgnoreCase("Khách Hàng Lẻ")) {
                                        id_kh = reponBanHang.selectIdKhachHangByTen("KH000");
                                        System.out.println("khachHangle");
                                    } else {
                                        id_kh = reponBanHang.selectKhachHangByIdKhachHang(txtMaKH.getText(), txtSDT.getText());
                                        System.out.println("khachHangin");
                                    }
                                    BigDecimal tienmat = null;
                                    BigDecimal tienthe = null;
                                    if (!txtTienCK.getText().trim().isEmpty()) {
                                        tienthe = new BigDecimal(txtTienCK.getText());
                                    }
                                    if (!txtTienMat.getText().trim().isEmpty()) {
                                        tienmat = new BigDecimal(txtTienMat.getText());
                                    }
                                    BigDecimal tongtiencuahoadon = tinhTongTien();
                                    //nếu tiền mặt nhỏ hơn tổng tiền tien mat = tong tien - tien mat
                                    // if (tienmat.compareTo(tongtiencuahoadon) < 0) {
                                    //       tienmat = tongtiencuahoadon.subtract(tienmat);
                                    // } else {
                                    //       tienmat = tienmat.subtract(tongtiencuahoadon);
                                    // }
                                    if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                                        tienthe = null;
                                        tienmat = tongtiencuahoadon;
                                    } else if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
                                        tienmat = null;
                                        tienthe = tongtiencuahoadon;
                                    }
                                    try {
                                        reponBanHang.thanhToanHoaDonVoucher(id_spct, id_hd,
                                                tinhTongTien(), id_hdct,
                                                id_kh, id_tt,
                                                genMaHTTT.maTuSinh(),
                                                tienmat, tienthe, id_vc,
                                                genMaVC_KH.maTuSinh(), BigDecimal.valueOf(Double.parseDouble(txtTienSauGiamGia.getText())),
                                                txtGhiChu.getText());
                                        String magd = "";
                                        do {
                                            magd = JOptionPane.showInputDialog(this, "Vui lòng nhập mã giao dịch");
                                            System.out.println("Mã giao dich cua ba la : " + magd);
                                            if (magd == null) {
                                                JOptionPane.showMessageDialog(this, "Bạn phải nhập mã giao dịch để thanh toán");
                                            } else if (magd.length() > 8) {
                                                JOptionPane.showMessageDialog(this, "Mã giao dịch không được quá 8 số");
                                            } else {
                                                break;
                                            }
                                        } while (magd == null || magd.isEmpty() || magd.length() > 8);
                                        reponBanHang.themHinhThucThanhToan(id_hd, BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText())), id_kh, id_tt, genMaHTTT.maTuSinh(), magd);
                                    } catch (SQLException ex) {
                                        Logger.getLogger(BanHangForm.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                                JOptionPane.showMessageDialog(this, "Thanh Toán Thành Công");
                                System.out.println("Tổng tiền : " + BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText())));

                                loadTableHoaDon(reponBanHang.getAllHD());
                                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(""));
                                cleanKhachHang();
                                cleanForm();
                                return;
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Tiền Khách Đưa Thiếu");
                        System.out.println("Tien thieu : " + Double.valueOf(txtTienCK.getText()) + " " + Double.valueOf(txtTongTien.getText()));
                        return;
                    }
                }
            }
        }
    }//GEN-LAST:event_btnThanhToanMouseClicked

    void openViewKhachHang() {
        KhachHangLeJDiaLog khle = new KhachHangLeJDiaLog(this, true);
        khle.setVisible(true);
    }

    Date homnay() {
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String formatdate = sdf.format(now);
        return now;
    }

    TaoMaTuSinh_inf genMaHD = new TaoMaTuSinh_inf() {
        @Override
        public String maTuSinh() {
            int maTuSinh = new Random().nextInt(1000000);
            return "HD" + maTuSinh;
        }
    };

    TaoMaTuSinh_inf genMaHTTT = new TaoMaTuSinh_inf() {
        @Override
        public String maTuSinh() {
            int maTuSinh = new Random().nextInt(1000000);
            return "HTTT" + maTuSinh;
        }
    };

    TaoMaTuSinh_inf genMaVC_KH = new TaoMaTuSinh_inf() {
        @Override
        public String maTuSinh() {
            //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            int maTuSinh = new Random().nextInt(1000000);
            return "MaVC_KH" + maTuSinh;
        }
    };

    HoaDon readFormHoaDon() {
        KhachHang kh = new KhachHang();
        String id = reponBanHang.selectKhachHangLeByMa("KH000", "Khách Hàng Lẻ");
        HinhThucThanhToan httt = new HinhThucThanhToan();
        String id_httt = "9475E3F6-0DE3-4563-B634-3D780F8423B8";
        UUID id_tt = UUID.fromString(id_httt);
        UUID uuid = UUID.fromString(id);
        kh.setID(uuid);
        httt.setID(id_tt);
        return new HoaDon(
                genMaHD.maTuSinh(),
                "",
                "",
                homnay(),
                BigDecimal.valueOf(0),
                homnay(),
                homnay(),
                homnay(),
                homnay(),
                BigDecimal.valueOf(0),
                BigDecimal.valueOf(0),
                0,
                "",
                id,
                XLogin.user.getId(),
                XLogin.user.getId(),
                homnay(),
                0
        );
    }

//    void showData(int index) {
//        String ma = "KH000";
//        String ten = "Khách Hàng Lẻ";
//        KhachHang kh = dao.selectAll().get(index);
//        txtMaKH.setText(kh.getMaKH());
//        txtTenKH.setText(kh.getTenKH());
//    }

    private void btnToaHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnToaHoaDonMouseClicked
        // TODO add your handling code here:
        if (reponBanHang.check10truong() < 9) {
            System.out.println("CHekc so luong");
//            int option = JOptionPane.showConfirmDialog(this, "Bạn có đồng ý thêm?", "Xác nhận",
//                    JOptionPane.YES_NO_OPTION);
//            if (option == JOptionPane.YES_OPTION) {
            HoaDon hd = readFormHoaDon();
            reponHD.addHoaDonCho(hd);
            JOptionPane.showMessageDialog(this, "Tạo hóa đơn thành công");
            loadTableHoaDon(reponBanHang.getAllHD());
            loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(""));
            tblHoaDon.setRowSelectionInterval(0, 0);
            loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString()));
            tinhTongTien();
            index = tblHoaDon.getSelectedRow();
            showDataHoaDon(this.index);
        } //        else {
        //                // Xử lý khi người dùng không đồng ý thêm
        //                JOptionPane.showMessageDialog(this, "Đã hủy thêm", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        //            }
        //        }
        else {
            JOptionPane.showMessageDialog(this, "Đã vượt quá số lượng hóa đơn chờ!!");
        }
    }//GEN-LAST:event_btnToaHoaDonMouseClicked

    private void btnThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhToanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThanhToanActionPerformed

    private void btnQuetMaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuetMaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnQuetMaActionPerformed

//    public static String id_hd = reponBanHang.selectIdHDByMaHD(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString());
    // read form để tạo qr code
    HoaDonChiTiet readFormQUetQR() {
        if (checkValidateSoLuongQuetQR()) {
            String idHd = reponBanHang.selectIdHDByMaHD(txtMaHD.getText());
            String idSPCT = reponBanHang.selectIDSPCTByMaSPCT(QR_Code.maSPCT);
            String id_nguoitao = XLogin.user.getId().toString();
            System.out.println(idHd);
            System.out.println(idSPCT);
            System.out.println(id_nguoitao);
            return new HoaDonChiTiet(genMaHDCT.maTuSinh(),
                    soluong,
                    idHd,
                    idSPCT,
                    id_nguoitao,
                    0
            );
        } else {
            return null;
        }
    }
    private void btnQuetMaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnQuetMaMouseClicked
        // TODO add your handling code here:
        if (tblHoaDon.getSelectedRow() < 0) {
            JOptionPane.showMessageDialog(this, "Chọn hóa đơn trước khi quét");
            return;
        } else {
            openQuetQR();
        }
    }//GEN-LAST:event_btnQuetMaMouseClicked

    private void txt_TimKiemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_TimKiemMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_txt_TimKiemMouseClicked

    private void txt_TimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_TimKiemKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_TimKiemKeyReleased

    private void btnTKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTKMouseClicked
        // TODO add your handling code here:
        reponBanHang.findTerSanPham(txt_TimKiem.getText());
        loadTableSanPham(reponBanHang.findTerSanPham(txt_TimKiem.getText()));
    }//GEN-LAST:event_btnTKMouseClicked

    private void txtTienMatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTienMatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTienMatActionPerformed

    private void cbbGiamGiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbGiamGiaActionPerformed
        // TODO add your handling code here:
        // check chọn hóa đơn
        if (reponBanHang.getAllVC().size() + 1 == cbbGiamGia.getItemCount()) {
            if (!cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
                if (tblGioHang.getRowCount() <= 0) {
                    JOptionPane.showMessageDialog(this, "Vui lòng chọn thêm sản phẩm vào giỏ hàng");
                    System.out.println("Giỏ hàng lỗi");
                    cbbGiamGia.setSelectedItem("Chọn Voucher");
                    return;
                }
                //check chọn hóa đơn
                if (tblHoaDon.getSelectedRow() < 0) {
                    JOptionPane.showMessageDialog(this, "Vui lòng chọn chọn hóa đơn");
                    cbbGiamGia.setSelectedItem("Chọn Voucher");
                    return;
                }
                //check chọn chọn khách hàng
                if (txtTenKH.getText().equalsIgnoreCase("Khách Hàng Lẻ")) {
                    JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng");
                    cbbGiamGia.setSelectedItem("Chọn Voucher");
                } else {
                    giamGiaTheoVoucher();
                }
            }
        }

        //giamGiaTheoVoucher();
    }//GEN-LAST:event_cbbGiamGiaActionPerformed

    private void cbbGiamGiaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbGiamGiaItemStateChanged

    }//GEN-LAST:event_cbbGiamGiaItemStateChanged

    public void GiamGia() throws HeadlessException, NumberFormatException {
        // TODO add your handling code here:
        if (cbbGiamGia.getItemCount() + 1 > reponBanHang.getAllVC().size()) {
            System.out.println("Meo meo");
            if (cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
            } else {
                String selectedVoucher = cbbGiamGia.getSelectedItem().toString();
                String idvc = reponBanHang.selectIdVoucherByMaHD(selectedVoucher);
                BigDecimal tongTien = BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText()));
                BigDecimal giatrimin = BigDecimal.ZERO;
                List<Voucher> selectedVouchers = reponBanHang.selectAllVoucherById(idvc);
                if (!selectedVouchers.isEmpty()) {
                    giatrimin = selectedVouchers.get(0).getGiatrimin();
                }
                if (tongTien.compareTo(giatrimin) < 0) {
                    JOptionPane.showMessageDialog(this, "Hóa đơn không đủ giá trị sử dụng");
                    cbbGiamGia.setSelectedItem("Chọn Voucher");
                } else {
                    BigDecimal giatrimax = selectedVouchers.get(0).getGiatrimax();
                    BigDecimal tiensaugiam = tongTien.subtract(giatrimax);
                    txtTienSauGiamGia.setText(tiensaugiam + "");
                }
            }
        }
    }

    private void cbbHinhThucItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbHinhThucItemStateChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_cbbHinhThucItemStateChanged

    private void btnFindKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindKHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFindKHActionPerformed

    private void btnFindKHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFindKHMouseClicked
        // TODO add your handling code here:
        openViewKhachHang();
    }//GEN-LAST:event_btnFindKHMouseClicked

    private void cbbMauSacItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbMauSacItemStateChanged
        // TODO add your handling code here:
        locCBBTruongDacTrung();
    }//GEN-LAST:event_cbbMauSacItemStateChanged

    private void cbbChatLieuItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbChatLieuItemStateChanged
        // TODO add your handling code here:
        locCBBTruongDacTrung();
    }//GEN-LAST:event_cbbChatLieuItemStateChanged

    private void cbbKichCoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbKichCoItemStateChanged
        // TODO add your handling code here:
        locCBBTruongDacTrung();
    }//GEN-LAST:event_cbbKichCoItemStateChanged

    private void txtMaNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMaNVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMaNVActionPerformed

    private void cbbHinhThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbHinhThucActionPerformed
        // TODO add your handling code here:
        if (cbbHinhThuc.getItemCount() == 2) {
            if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
                // txtTienMat.setText("0");
                txtTienCK.setEnabled(false);
                txtTienMat.setEnabled(true);

            } else if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
                // txtTienCK.setText("0");
                txtTienMat.setEnabled(false);
                txtTienCK.setEnabled(true);

            } else {
                txtTienCK.setEnabled(true);
                txtTienMat.setEnabled(true);
            }
        }
    }//GEN-LAST:event_cbbHinhThucActionPerformed

    void openQuetQR() {
        QR_Code qr = new QR_Code();
        qr.setVisible(true);
        qr.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                System.out.println("Alo maspct :" + QR_Code.maSPCT);
                if (QR_Code.maSPCT != null) {
                    HoaDonChiTiet hdct = readFormQUetQR();
                    if (reponBanHang.themSPGioHang(hdct) != 0) {
                        System.out.println("Them thanh cong");
                        loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(txtMaHD.getText()));
                        loadTableSanPham(reponBanHang.getAllSP());
                        tinhTongTien();
                    }
                }
            }
        });
    }
//
//        public void QuetQR() throws HeadlessException {
//                //   if (QuetQRR_BanHang.maSPCT != null) {
//                int index = tblSanPham.getSelectedRow();
//                HoaDonChiTiet hdct = readFormQUetQR();
//                if (reponBanHang.themSPGioHang(hdct) != 0) {
//                        System.out.println("Them thanh cong");
//                        loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(txtMaHD.getText()));
//                        loadTableSanPham(reponBanHang.getAllSP());
//                        tinhTongTien();
//                }
//
//                // }
//        }

    private void suasoluongsp() throws NumberFormatException, HeadlessException {
        // TODO add your handling code here:
        int i = tblGioHang.getSelectedRow();
        String mahd = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();   // lấy gt từ bảng
        //       for (int i = 0; i < tblGioHang.getRowCount(); i++) {
        String maspct = tblGioHang.getValueAt(tblGioHang.getSelectedRow(), 1).toString(); // lấy gt từ bảng
        System.out.println(maspct + "hihi");
        String mahdct = reponBanHang.selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(
                reponBanHang.selectIdHDByMaHD(mahd),
                reponBanHang.selectIDSPCTByMaSPCT(maspct)
        );
        String id_hd = reponBanHang.selectIdHDByMaHD(mahd);
        String id_spct = reponBanHang.selectIDSPCTByMaSPCT(maspct);
        int soluongthaydoi = 0;
        try {
            soluongthaydoi = Integer.parseInt(tblGioHang.getValueAt(i, 6).toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Số lượng thay đổi không hợp lệ");
            loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
            return;
        }
        // lấy gt từ bảng
        try {
            if (tblGioHang.getValueAt(i, 6).toString().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Không được để trống số lượng thay đổi");
                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
                return;
            } else if (soluongthaydoi <= 0) {
                JOptionPane.showMessageDialog(this, "Số lượng thay đổi không hợp lệ");
                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
                return;
            } else if (soluongthaydoi > reponBanHang.selectSoLuongBySanPhamChiTiet(id_spct, mahdct)) {
                JOptionPane.showMessageDialog(this, "Số lượng sản phẩm không đủ");
                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
                return;
            } else {
                reponBanHang.suaHoaDonChiTiet(mahdct, id_spct, id_hd, soluongthaydoi);
                JOptionPane.showMessageDialog(this, "Sửa thành công ");
                loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
                loadTableSanPham(reponBanHang.getAllSP());
            }
        } catch (Exception e) {
            loadTableHoaDonCT(reponBanHang.selectHDCTByMaHD(mahd));
            return;
        }
        //       int soluongtronggio = reponBanHang.selectSoLuongByHoaDonChiTietID(mahdct);
        //        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFindKH;
    private javax.swing.JButton btnHuyHoaDon;
    private javax.swing.JButton btnQuetMa;
    private javax.swing.JButton btnSuaSPTRONGGH;
    private javax.swing.JButton btnTK;
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JButton btnToaHoaDon;
    private javax.swing.JButton btnXoaSPGH;
    private javax.swing.JComboBox<String> cbbChatLieu;
    private javax.swing.JComboBox<String> cbbGiamGia;
    private javax.swing.JComboBox<String> cbbHinhThuc;
    private javax.swing.JComboBox<String> cbbKichCo;
    private javax.swing.JComboBox<String> cbbMauSac;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JLabel lblTienThuaThieu;
    public static javax.swing.JTable tblGioHang;
    public javax.swing.JTable tblHoaDon;
    public static javax.swing.JTable tblSanPham;
    private javax.swing.JTextArea txtGhiChu;
    public javax.swing.JTextField txtMaHD;
    private javax.swing.JTextField txtMaKH;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JTextField txtNgayTao;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTenKH;
    private javax.swing.JTextField txtTienCK;
    private javax.swing.JTextField txtTienMat;
    private javax.swing.JTextField txtTienSauGiamGia;
    private javax.swing.JTextField txtTienThua;
    private javax.swing.JTextField txtTongTien;
    private javax.swing.JTextField txt_TimKiem;
    // End of variables declaration//GEN-END:variables

    void loadCBB() {
        dcbHTTT = (DefaultComboBoxModel<String>) cbbHinhThuc.getModel();
        dcbHTTT.removeAllElements();
        for (ThanhToan tt : reponTT.getAll()) {
            dcbHTTT.addElement(tt.toString());
        }
    }

    void loadCBBVoucher() {
        dcbVoucher = (DefaultComboBoxModel) cbbGiamGia.getModel();
        dcbVoucher.removeAllElements();
        List<Voucher> listVc = reponBanHang.selectVoucherDangDienRa();
        dcbVoucher.addElement("Chọn Voucher");
        for (Voucher vc : listVc) {
            dcbVoucher.addElement(vc);
        }
    }

    void loadCBBMauSac() {
        dcbMauSac = (DefaultComboBoxModel) cbbMauSac.getModel();
        dcbMauSac.removeAllElements();
        dcbMauSac.addElement("Tất Cả");
        for (MauSac sp : reponMauSac.getAll()) {
            dcbMauSac.addElement(sp.getTenMauSac());
        }
    }

    void loadCBBKichCo() {
        dcbKichCo = (DefaultComboBoxModel) cbbKichCo.getModel();
        dcbKichCo.removeAllElements();
        dcbKichCo.addElement("Tất Cả");
        for (KichCo sp : reponKichCo.getAll()) {
            dcbKichCo.addElement(sp.getTenKichCo());
        }
    }

    void loadCBBChatLieu() {
        dcbChatLieu = (DefaultComboBoxModel) cbbChatLieu.getModel();
        dcbChatLieu.removeAllElements();
        dcbChatLieu.addElement("Tất Cả");
        for (ChatLieu sp : reponChatLieu.getAll()) {
            dcbChatLieu.addElement(sp.getTen());

        }
    }

//     void giamGiaTheoVoucher() {
//        if (cbbGiamGia.getSelectedItem() != null && !cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
//            Voucher vc = (Voucher) cbbGiamGia.getSelectedItem();
//            String tongtienString = txtTongTien.getText();
//
//            if (tongtienString.isEmpty()) {
//                tongtienString = "0";
//            }
//
//            BigDecimal tongtien = new BigDecimal(tongtienString);
//            BigDecimal sotiengiam = vc.getGiatrimax();
//            lblTienGiamCuaVoucher.setText(sotiengiam.toString());
//
//            if (vc.getLoaiGiamGia().equals("VND")) {
//                if (tongtien.compareTo(vc.getGiatrimin()) >= 0) {
//                    BigDecimal tienSauGiam = tongtien.subtract(vc.getGiatrimax()).max(BigDecimal.ZERO);
//                    txtTienSauGiamGia.setText(tienSauGiam.toString());
//                    if (txtTienMat.getText().isEmpty()) {
//                        JOptionPane.showMessageDialog(this, "Vui lòng nhập tiền thừa");
//                    } else {
//                        BigDecimal tienmatkhachdua = BigDecimal.valueOf(Double.parseDouble((txtTienMat.getText())));
//                        // BigDecimal tienckkhachdua = BigDecimal.valueOf(Double.parseDouble((txtTienCK.getText())));
//                        // BigDecimal tienckkhachdua = new BigDecimal(txtTienCK.getText());
//                        if (tienmatkhachdua.compareTo(tienSauGiam) >= 0) {
//                            txtTienThua.setText(tienmatkhachdua.subtract(tienSauGiam).toString());
//                        }
//                    }else {
//                    JOptionPane.showMessageDialog(this, "Tổng tiền của hóa đơn không đủ");
//                    resetVoucherSelection();
//                }
//                } else if (vc.getLoaiGiamGia().equals("Phần trăm")) {
//                    if (tongtien.compareTo(vc.getGiatrimin()) >= 0) {
//                        BigDecimal tienGiam = tongtien.multiply(vc.getGiatrimax().divide(BigDecimal.valueOf(100)));
//                        BigDecimal tienSauGiam = tongtien.subtract(tienGiam).max(BigDecimal.ZERO);
//                        txtTienSauGiamGia.setText(tienSauGiam.toString());
//                        BigDecimal tienmatkhachdua = BigDecimal.valueOf(Double.parseDouble((txtTienMat.getText())));
//                        BigDecimal tienckkhachdua = BigDecimal.valueOf(Double.parseDouble((txtTienCK.getText())));
//                        if (tienmatkhachdua.compareTo(tienSauGiam) >= 0) {
//                            txtTienThua.setText(tienmatkhachdua.subtract(tienSauGiam).toString());
//                        }
//                    } else {
//                        JOptionPane.showMessageDialog(this, "Tổng tiền của hóa đơn không đủ");
//                        resetVoucherSelection();
//                    }
//                }
//            }
//        }
//    }
    // giảm giá của phiếu giảm giá    
    void giamGiaTheoVoucher() {
        if (cbbGiamGia.getSelectedItem() != null && !cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
            Voucher vc = (Voucher) cbbGiamGia.getSelectedItem();
            String tongtienString = txtTongTien.getText();
            if (tongtienString.isEmpty()) {
                tongtienString = "0";
            }
            BigDecimal tongtien = new BigDecimal(tongtienString);
            BigDecimal sotiengiam = vc.getGiatrimax();
            if (vc.getLoaiGiamGia().equals("VND")) {
                if (tongtien.compareTo(vc.getGiatrimin()) >= 0) {
                    BigDecimal tienSauGiam = tongtien.subtract(vc.getGiatrimax()).max(BigDecimal.ZERO);
                    txtTienSauGiamGia.setText(tienSauGiam.toString());
//                    BigDecimal tienmatkhachdua = BigDecimal.valueOf(Double.parseDouble((txtTienMat.getText())));
//                    BigDecimal tienckkhachdua = BigDecimal.valueOf(Double.parseDouble((txtTienCK.getText())));
//                    BigDecimal tienthua = tienmatkhachdua.subtract(tienSauGiam);
//                    if (cbbHinhThuc.getSelectedItem().equals("Chuyển khoản")) {
//                        tienthua = tienckkhachdua.subtract(tienSauGiam);
//                        txtTienThua.setText(tienthua + "");
//                    } else if (cbbHinhThuc.getSelectedItem().equals("Tiền mặt")) {
//                        txtTienThua.setText(tienthua + "");
//                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Tổng tiền của hóa đơn không đủ");
                    resetVoucherSelection();
                }
            }
        }
    }

    void resetVoucherSelection() {
        cbbGiamGia.setSelectedItem("Chọn Voucher");
    }

    public void GiamGia2() throws HeadlessException, NumberFormatException {
        // TODO add your handling code here:
        if (cbbGiamGia.getItemCount() + 1 > reponBanHang.getAllVC().size()) {
            System.out.println("Meo meo");
            if (cbbGiamGia.getSelectedItem().equals("Chọn Voucher")) {
            } else {
                String selectedVoucher = cbbGiamGia.getSelectedItem().toString();
                String idvc = reponBanHang.selectIdVoucherByMaHD(selectedVoucher);
                BigDecimal tongTien = BigDecimal.valueOf(Double.parseDouble(txtTongTien.getText()));
                BigDecimal giatrimin = BigDecimal.ZERO;
                List<Voucher> selectedVouchers = reponBanHang.selectAllVoucherById(idvc);
                if (!selectedVouchers.isEmpty()) {
                    giatrimin = selectedVouchers.get(0).getGiatrimin();
                }
                if (tongTien.compareTo(giatrimin) < 0) {
                    JOptionPane.showMessageDialog(this, "Hóa đơn không đủ giá trị sử dụng");
                    cbbGiamGia.setSelectedItem("Chọn Voucher");
                } else {
                    BigDecimal giatrimax = selectedVouchers.get(0).getGiatrimax();
                    BigDecimal tiensaugiam = tongTien.subtract(giatrimax);
                    txtTienSauGiamGia.setText(tiensaugiam + "");
                }
            }
        }
    }

    private String date2String(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-YYYY hh:mm:ss");
        return sdf.format(date);
    }

    // Hàm tự viết để chuyển đổi ngày tháng
    private Date parseDate(String ngayThang) {
        // Đối tượng hỗ trợ đọc kiểu dữ liệu ngày tháng
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        //String date = DateFormat.
        try {
            return sdf.parse(ngayThang);
        } catch (Exception e) {
            //Nếu lỗi trả về thời điểm hiện tại
            return new Date();
        }
    }

    void showDataHoaDon(int index) {
        HoaDon hd = reponBanHang.getAllHD().get(index);
        txtMaHD.setText(hd.getMa());
        txtNgayTao.setText(date2String(hd.getNgayTao()));
        txtMaNV.setText(hd.getManhanvien());
    }

    private BigDecimal tinhTongTien() throws NumberFormatException {
        // TODO add your handling code here:
        BigDecimal tongTien2 = BigDecimal.ZERO;
        DecimalFormat currencyFormat = new DecimalFormat("#,###");
        for (int i = 0; i < tblGioHang.getRowCount(); i++) {
            BigDecimal donGia = null;
            try {
                donGia = BigDecimal.valueOf(currencyFormat.parse(tblGioHang.getValueAt(i, 7).toString()).doubleValue());

            } catch (ParseException ex) {
                Logger.getLogger(SanPhamView.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            int soLuong = Integer.parseInt(tblGioHang.getValueAt(i, 6).toString());
            BigDecimal tongTien1 = donGia.multiply(BigDecimal.valueOf(soLuong));
            tongTien2 = tongTien2.add(tongTien1);
        }
        txtTongTien.setText(tongTien2 + "");
        // lblThanhToan.setText(tongTien2 + "");
        return tongTien2;
    }

    private BigDecimal tinhTongTienGiamGia() throws NumberFormatException {
        // TODO add your handling code here:
        BigDecimal tongTien2 = BigDecimal.ZERO;
        DecimalFormat currencyFormat = new DecimalFormat("#,###");
        for (int i = 0; i < tblGioHang.getRowCount(); i++) {
            BigDecimal donGia = null;
            try {
                donGia = BigDecimal.valueOf(currencyFormat.parse(tblGioHang.getValueAt(i, 7).toString()).doubleValue());

            } catch (ParseException ex) {
                Logger.getLogger(SanPhamView.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            int soLuong = Integer.parseInt(tblGioHang.getValueAt(i, 6).toString());
            BigDecimal tongTien1 = donGia.multiply(BigDecimal.valueOf(soLuong));
            tongTien2 = tongTien2.add(tongTien1);
        }
        txtTongTien.setText(tongTien2 + "");
        // lblThanhToan.setText(tongTien2 + "");
        return tongTien2;
    }

    @Override
    public void chonKH(String makh, String tenkh, String sdt) {
        // String maKHSub = maKH.substring(0, kh.getMaKH().indexOf(" "));
        txtMaKH.setText(makh);
        txtTenKH.setText(tenkh);
        txtSDT.setText(sdt);
    }

    // loc theo cbb cac truong dac trung
    void locCBBTruongDacTrung() {
        String tenMauSac = null;
        String tenKichCo = null;
        String tenChatLieu = null;

        // Retrieve selected items from JComboBoxes
        if (cbbMauSac.getSelectedItem() != null && cbbKichCo.getSelectedItem() != null && cbbChatLieu.getSelectedItem() != null) {
            if (!cbbMauSac.getSelectedItem().equals("Tất Cả")) {
                tenMauSac = cbbMauSac.getSelectedItem().toString();
            }
            if (!cbbChatLieu.getSelectedItem().equals("Tất Cả")) {
                tenChatLieu = cbbChatLieu.getSelectedItem().toString();
            }
            if (!cbbKichCo.getSelectedItem().equals("Tất Cả")) {
                tenKichCo = cbbKichCo.getSelectedItem().toString();
            }
            this.loadTableSanPham(reponBanHang.locTheoCacTruongDacTrung(tenMauSac, tenKichCo, tenChatLieu));
        }
    }

    // Set dữ liệu
    void cleanKhachHang() {
        txtMaKH.setText("KH000");
        txtTenKH.setText("Khách Hàng Lẻ");
        txtSDT.setText("");
    }

    void cleanForm() {
        txtMaHD.setText("");
        txtNgayTao.setText("");
        txtMaNV.setText("");
        txtTongTien.setText("0");
        cbbHinhThuc.setSelectedIndex(0);
        txtTienMat.setText("0");
        txtTienCK.setText("0");
        txtTienThua.setText("");
        cbbGiamGia.setSelectedIndex(0);
        txtTienSauGiamGia.setText("0");
        txtGhiChu.setText("");

    }
}
