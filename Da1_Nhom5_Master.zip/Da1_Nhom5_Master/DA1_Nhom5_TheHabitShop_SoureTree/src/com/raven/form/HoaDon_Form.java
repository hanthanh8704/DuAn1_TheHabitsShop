/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.raven.form;

import java.util.Date;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.raven.classinterface.TaoMaTuSinh_inf;
import com.raven.classmodel.ChiTietSanPham;
import com.raven.classmodel.HinhThucThanhToan;
import com.raven.classmodel.HoaDon;
import com.raven.classmodel.HoaDonChiTiet;
import com.raven.classmodel.HoaDonTraHang;
import com.raven.classmodel.HoaDonTraHangCT;
import com.raven.classmodel.KhachHang;
import com.raven.classmodel.LichSuHoaDon;
import com.raven.classmodel.XLogin;
import com.raven.main.LoginDA1;
import com.raven.main.Main;
import com.raven.reponsitory.BanHangReponsitory;
import com.raven.reponsitory.ChiTietSanPhamRepon;
import com.raven.reponsitory.HoaDonChiTietRepon;
import com.raven.reponsitory.HoaDonRepon;
import com.raven.reponsitory.HoaDonTraHangCTRepon;
import com.raven.reponsitory.HoaDonTraHangRepon;
import com.raven.reponsitory.LichSuHoaDonRepon;
import com.raven.service.GetIdSPCTService;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.sql.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.UUID;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Desktop;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.DecimalFormat;
import java.text.Normalizer;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;
import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;

/**
 *
 * @author ADMIN
 */
public class HoaDon_Form extends javax.swing.JPanel implements Runnable, ThreadFactory {

    private HoaDonChiTietRepon reponHDCT = new HoaDonChiTietRepon();
    private HoaDonTraHangCTRepon reponHDTHCT = new HoaDonTraHangCTRepon();
    BanHangReponsitory reponBH = new BanHangReponsitory();
    List<LichSuHoaDon> listLSHD = new ArrayList<>();
    LichSuHoaDonRepon reponLSHD = new LichSuHoaDonRepon();
    HoaDonRepon reponHD = new HoaDonRepon();
    ChiTietSanPhamRepon reponCTSP = new ChiTietSanPhamRepon();
    DefaultTableModel model = new DefaultTableModel();
    HoaDonTraHangRepon reponHDTH = new HoaDonTraHangRepon();
    List<HoaDon> listHD = new ArrayList<>();
    List<HoaDonChiTiet> listHDCT = new ArrayList<>();
    List<ChiTietSanPham> listCTSP = new ArrayList<>();
    List<HoaDonTraHang> listHDTH = new ArrayList<>();
    List<HoaDonTraHangCT> listHDTHCT = new ArrayList<>();
    LichSuHoaDonRepon lshdRepon = new LichSuHoaDonRepon();
    DefaultComboBoxModel<String> dcb1 = new DefaultComboBoxModel<>();
    DefaultComboBoxModel<String> dcb2 = new DefaultComboBoxModel<>();
    DefaultTableModel modelHDCT = new DefaultTableModel();
    DefaultTableModel modelHDTHCT = new DefaultTableModel();
    DefaultTableModel modelLSHD = new DefaultTableModel();
    private int index = 1;
    private WebcamPanel panel = null;
    private Webcam webcam = null;
    private static final long serialVersionUID = 6441489157408381878L;
    private Executor executor = Executors.newSingleThreadExecutor(this);
    private GetIdSPCTService getidspct = new GetIdSPCTService();
    public static final String pathUnicode = "font\\unicode.ttf";
    private DecimalFormat df = new DecimalFormat("#,###");
    LoginDA1 login = null;
    Connection cn;
    Statement st;
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;

    /**
     * Creates new form HoaDon
     */
    public HoaDon_Form() {
        initComponents();
        //initWebcam();
        modelHDCT = (DefaultTableModel) tblhoaDonCT.getModel();
        // setSoTrang();
        //  loadTableHoaDonPhanTrang(reponHD.phanTrang(tienlui));
        dcb1 = (DefaultComboBoxModel<String>) cboTT.getModel();
        dcb2 = (DefaultComboBoxModel<String>) cboHTTT.getModel();
        loadCBB();
        loadHTTT();
        AddPleacehoderStyle(txtTimKiem);
        AddPleacehoderStyle(txt_TimKiem);
        loadTableHoaDon(reponHD.getAll());
    }

    private String getTinhTrangValue(int tinhTrangValue) {
        switch (tinhTrangValue) {
            case 0:
                return "Đã Giao Hàng";
            case 1:
                return "Đã Hủy";
            case 2:
                return "Chưa Thanh Toán";
            case 3:
                return "Đã Thanh Toán";
            case 4:
                return "Tất Cả";
            default:
                return "Unknown";
        }
    }

    void fillTableHDCT(List<HoaDonChiTiet> listHDCT) {
        modelHDTHCT = (DefaultTableModel) tblHoaDonChiTiet.getModel();
        modelHDTHCT.setRowCount(0);
        int stt = 1;
        for (HoaDonChiTiet hdct : listHDCT) {
            Object[] row = new Object[]{
                stt++,
                hdct.getIdSPCT().getMa(),
                hdct.getIdSPCT().getTenSanPham().getTenSP(),
                hdct.getSoLuong(),
                NumberFormat.getInstance().format(hdct.getIdSPCT().getGiaBan1()),
                hdct.getIdSPCT().getTenNhanHieu().getTen(),
                hdct.getIdSPCT().getTenMauSac().getTenMauSac(),
                hdct.getIdSPCT().getTenKichCo().getTenKichCo(),
                NumberFormat.getInstance().format(hdct.getHoaDon().getTongTienHoaDon())
            };
            modelHDTHCT.addRow(row);
        }
    }

    public void AddPleacehoderStyle(JTextField textField) {
        java.awt.Font font = textField.getFont();
        font = font.deriveFont(Font.ITALIC);
        textField.setFont(font);
        textField.setForeground(Color.gray);
    }

    public void RemovePleacehoderStyle(JTextField textField) {
        java.awt.Font font = textField.getFont();
        font = font.deriveFont(Font.ITALIC);
        textField.setFont(font);
        textField.setForeground(Color.black);
    }

    void loadCBB() {
        dcb1.removeAllElements();
        dcb1.addElement("Tất Cả");
        dcb1.addElement("Chờ Thanh Toán");
        dcb1.addElement("Đã Thanh Toán");
        dcb1.addElement("Đã Hủy");
    }

    void loadHTTT() {
        dcb2.addElement("Tất Cả");
        dcb2.addElement("Chuyển khoản");
        dcb2.addElement("Tiền mặt");
    }

    private String date2String(java.util.Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-YYYY hh:mm:ss");

        return sdf.format(date);
    }

    // Hàm tự viết để chuyển đổi ngày tháng
    private java.util.Date parseDate(String ngayThang) {
        // Đối tượng hỗ trợ đọc kiểu dữ liệu ngày tháng
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        //String date = DateFormat.
        try {
            return sdf.parse(ngayThang);
        } catch (Exception e) {
            //Nếu lỗi trả về thời điểm hiện tại
            return new java.util.Date();
        }
    }

    void loadTableHoaDon(List<HoaDon> listHD) {
        model = (DefaultTableModel) tblHoaDon.getModel();
        model.setRowCount(0);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        int stt = 1;
        for (HoaDon hoaDon : listHD) {
            String tinhTrang = "";
            int tinhTrangValue = hoaDon.getTinhTrang();
            if (tinhTrangValue == 0) {
                tinhTrang = "Chờ Thanh Toán";
            } else if (tinhTrangValue == 1) {
                tinhTrang = "Đã Thanh Toán";
            } else if (tinhTrangValue == 2) {
                tinhTrang = "Chưa Thanh Toán";
            } else {
                tinhTrang = "Đã Hủy";
            }
            BigDecimal tiensaugiam = BigDecimal.ZERO;
            if (hoaDon.getTongTienSauGiamGia().compareTo(BigDecimal.ZERO) > 0) {
                tiensaugiam = hoaDon.getTongTienSauGiamGia();
            } else {
                tiensaugiam = hoaDon.getTongTienHoaDon();
            }
            Object[] row = new Object[]{
                stt++,
                hoaDon.getMa(),
                hoaDon.getIdNhanVien().getMaNV(),
                hoaDon.getIdKhachHang().getTenKH(),
                hoaDon.getIdKhachHang().getSdt(),
                hoaDon.getNgaytaohoadon(),
                hoaDon.getNgaythanhtoan(),
                hoaDon.getTongTienHoaDon() == null ? "0" : NumberFormat.getInstance().format(hoaDon.getTongTienHoaDon()),
                NumberFormat.getInstance().format(tiensaugiam),
                hoaDon.getThanhToan().getTenhinhthuc(),
                hoaDon.getGhichu(),
                tinhTrang
            };
            model.addRow(row);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jSeparator8 = new javax.swing.JSeparator();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        txtTimKiem = new javax.swing.JTextField();
        jScrollPane10 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cboTT = new javax.swing.JComboBox<>();
        btnXuatHoaDon = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tblhoaDonCT = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        dateNgayThanhToan2 = new com.toedter.calendar.JDateChooser();
        dateNgayThanhToan = new com.toedter.calendar.JDateChooser();
        btnInHoaDon = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblLichSuHoaDon = new javax.swing.JTable();
        btnLoc = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        cboHTTT = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        tblHoaDonChiTiet = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        pnQuetQR = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        txt_TimKiem = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtMaHDTH = new javax.swing.JTextField();
        txtTenKH = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        txtTongTien = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtGhiChu = new javax.swing.JTextArea();
        jSeparator9 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        txtTrangThai = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        btnXuatDanhSach = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JSeparator();
        btnTimKiemHD = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Hóa Đơn"), "Hóa Đơn", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hóa Đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        txtTimKiem.setText("Tìm theo các trường của table");
        txtTimKiem.setToolTipText("");
        txtTimKiem.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtTimKiem.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtTimKiemCaretUpdate(evt);
            }
        });
        txtTimKiem.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTimKiemFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTimKiemFocusLost(evt);
            }
        });
        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã Hóa Đơn", "Mã Nhân Viên", "Tên Khách Hàng", "SDT", "Ngày tạo", "Ngày Thanh Toán", "Tổng Tiền", "Tổng Tiền Sau Giảm", "Hình Thức", "Ghi chú", "Trạng thái"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                true, true, false, false, true, false, false, false, true, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHoaDonMouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(tblHoaDon);
        if (tblHoaDon.getColumnModel().getColumnCount() > 0) {
            tblHoaDon.getColumnModel().getColumn(0).setMinWidth(40);
            tblHoaDon.getColumnModel().getColumn(0).setMaxWidth(40);
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Tìm Kiếm");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Trạng thái");

        cboTT.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboTTItemStateChanged(evt);
            }
        });
        cboTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTTActionPerformed(evt);
            }
        });

        btnXuatHoaDon.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnXuatHoaDon.setForeground(new java.awt.Color(51, 51, 51));
        btnXuatHoaDon.setText("Xuất Danh Sách");
        btnXuatHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXuatHoaDonActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hóa Đơn Chi Tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        tblhoaDonCT.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tblhoaDonCT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Ma CTSP", "Tên SP", "SL", "Giá", "Tổng Tiền "
            }
        ));
        tblhoaDonCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblhoaDonCTMouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(tblhoaDonCT);
        if (tblhoaDonCT.getColumnModel().getColumnCount() > 0) {
            tblhoaDonCT.getColumnModel().getColumn(0).setMinWidth(40);
            tblhoaDonCT.getColumnModel().getColumn(0).setMaxWidth(40);
            tblhoaDonCT.getColumnModel().getColumn(1).setMinWidth(80);
            tblhoaDonCT.getColumnModel().getColumn(1).setMaxWidth(80);
            tblhoaDonCT.getColumnModel().getColumn(5).setMinWidth(150);
            tblhoaDonCT.getColumnModel().getColumn(5).setMaxWidth(150);
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 795, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Từ");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("Đến");

        btnInHoaDon.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnInHoaDon.setForeground(new java.awt.Color(51, 51, 51));
        btnInHoaDon.setText("In Hóa Đơn");
        btnInHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInHoaDonActionPerformed(evt);
            }
        });

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lịch Sử Hóa Đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        tblLichSuHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "STT", "Mã NV", "Ngày Giờ", "Hành Động"
            }
        ));
        tblLichSuHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLichSuHoaDonMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tblLichSuHoaDon);
        if (tblLichSuHoaDon.getColumnModel().getColumnCount() > 0) {
            tblLichSuHoaDon.getColumnModel().getColumn(0).setMinWidth(50);
            tblLichSuHoaDon.getColumnModel().getColumn(0).setMaxWidth(50);
        }

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        btnLoc.setText("LỌC");
        btnLoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Hình Thức Thanh Toán");

        cboHTTT.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboHTTTItemStateChanged(evt);
            }
        });
        cboHTTT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboHTTTMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(cboTT, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23)
                                .addComponent(jLabel10)
                                .addGap(18, 18, 18)
                                .addComponent(cboHTTT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dateNgayThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 676, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(btnXuatHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(btnInHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dateNgayThanhToan2, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51)
                                .addComponent(btnLoc)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnXuatHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnInHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cboTT, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cboHTTT, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dateNgayThanhToan2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(dateNgayThanhToan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE))
                                    .addComponent(btnLoc, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("Hóa Đơn", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hóa Đơn Chi Tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 14))); // NOI18N

        tblHoaDonChiTiet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tblHoaDonChiTiet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã CTSP", "Tên SP", "Màu Sắc", "Chất Liệu", "Size", "SL", "Giá", "Tổng Tiền "
            }
        ));
        tblHoaDonChiTiet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHoaDonChiTietMouseClicked(evt);
            }
        });
        jScrollPane12.setViewportView(tblHoaDonChiTiet);
        if (tblHoaDonChiTiet.getColumnModel().getColumnCount() > 0) {
            tblHoaDonChiTiet.getColumnModel().getColumn(0).setMinWidth(40);
            tblHoaDonChiTiet.getColumnModel().getColumn(0).setMaxWidth(40);
            tblHoaDonChiTiet.getColumnModel().getColumn(1).setMinWidth(80);
            tblHoaDonChiTiet.getColumnModel().getColumn(1).setMaxWidth(80);
        }

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 804, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jScrollPane12)
                .addContainerGap())
        );

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Quét QR", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        pnQuetQR.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnQuetQR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(pnQuetQR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel24.setText("Tìm Kiếm Theo Mã ");

        txt_TimKiem.setText("Mã");
        txt_TimKiem.setBorder(null);
        txt_TimKiem.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_TimKiemFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_TimKiemFocusLost(evt);
            }
        });
        txt_TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_TimKiemActionPerformed(evt);
            }
        });
        txt_TimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_TimKiemKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_TimKiemKeyReleased(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thông Tin Khách Hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jLabel2.setText("Mã Hóa Đơn");

        jLabel4.setText("Tên KH");

        txtMaHDTH.setEditable(false);
        txtMaHDTH.setBackground(new java.awt.Color(255, 255, 255));
        txtMaHDTH.setBorder(null);

        txtTenKH.setEditable(false);
        txtTenKH.setBackground(new java.awt.Color(255, 255, 255));
        txtTenKH.setBorder(null);

        jLabel9.setText("SDT");

        jLabel13.setText("Tổng Tiền");

        txtSDT.setEditable(false);
        txtSDT.setBackground(new java.awt.Color(255, 255, 255));
        txtSDT.setBorder(null);

        txtTongTien.setBorder(null);
        txtTongTien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTongTienActionPerformed(evt);
            }
        });

        jSeparator2.setBackground(new java.awt.Color(204, 255, 255));

        jSeparator5.setBackground(new java.awt.Color(153, 255, 255));

        jLabel7.setText("Ghi Chú");

        txtGhiChu.setColumns(20);
        txtGhiChu.setRows(5);
        txtGhiChu.setBorder(null);
        jScrollPane1.setViewportView(txtGhiChu);

        jLabel5.setText("Trạng Thái");

        txtTrangThai.setBorder(null);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtTongTien)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addComponent(jSeparator9))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addComponent(jScrollPane1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(jSeparator3)))
                .addContainerGap())
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtTenKH, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                        .addComponent(jSeparator2))))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(0, 15, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMaHDTH, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTrangThai))))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaHDTH, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
        );

        btnXuatDanhSach.setText("Xuất Hóa Đơn");
        btnXuatDanhSach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXuatDanhSachActionPerformed(evt);
            }
        });

        btnTimKiemHD.setText("Tìm Kiếm");
        btnTimKiemHD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTimKiemHDMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator6)
                    .addComponent(txt_TimKiem, javax.swing.GroupLayout.DEFAULT_SIZE, 759, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnTimKiemHD)
                .addGap(18, 18, 18)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnXuatDanhSach)
                .addGap(10, 10, 10))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_TimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnXuatDanhSach)
                            .addComponent(btnTimKiemHD))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Tìm Kiếm Hóa Đơn", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnInHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInHoaDonActionPerformed
        // TODO add your handling code here:
        if (tblHoaDon.getSelectedRow() < 0) {
            JOptionPane.showMessageDialog(this, "Chọn hoá đơn cần xuất file!!");
        } else if (tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 11).toString().equalsIgnoreCase("Đã huỷ")
                || tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 11).toString().equalsIgnoreCase("Chờ thanh toán")) {
            JOptionPane.showMessageDialog(this, "Hoá đơn " + tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 11) + " không thể xuất!!");
        } else if (tblhoaDonCT.getRowCount() > 0) {
            String path = "";
            JFileChooser jfile = new JFileChooser();
            jfile.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int x = jfile.showSaveDialog(this);
            if (x == JFileChooser.APPROVE_OPTION) {
                path = jfile.getSelectedFile().getAbsolutePath();
                System.out.println(path);
            }
            Document doc = new Document();
            try {
                PdfWriter.getInstance(doc, new FileOutputStream(path + "/" + tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString().trim() + ".pdf"));
                String filePath = path + "/" + tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString().trim() + ".pdf";
                doc.open();// mở luồng ghi file
                String hoaDon_id = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
                String tenKhachHang = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 3).toString();
                String ngayTaoHoaDon = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 6).toString();
                Date now = new Date();
                SimpleDateFormat fomater = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
                String nowS = fomater.format(now);
                // set tieu de cho hoa don
                com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 32, com.itextpdf.text.Font.BOLD, BaseColor.BLACK);
                Paragraph title = new Paragraph("The HabitShop ", titleFont);
                title.setAlignment(Paragraph.ALIGN_CENTER);
                doc.add(title);
                doc.add(new Paragraph("\n"));
                //goi ra cac doan thong tin
                //tạo phông chữ cho các tiêu đề thông tin
                com.itextpdf.text.Font infoFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12, com.itextpdf.text.Font.NORMAL, BaseColor.DARK_GRAY);
                doc.add(new Paragraph("Ma hoa don: " + hoaDon_id, infoFont));
                doc.add(new Paragraph("Ten khach hang: " + removeDiacritics(tenKhachHang), infoFont));
                doc.add(new Paragraph("Ngay tao hoa don: " + ngayTaoHoaDon, infoFont));
                doc.add(new Paragraph("Ngay xuat hoa don: " + nowS, infoFont));
                doc.add(new Paragraph("Ma nguoi tao hoa don: " + removeDiacritics(tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 2).toString()), infoFont));
                doc.add(new Paragraph("Ten nguoi xuat hoa don: " + removeDiacritics(XLogin.user.getTenNV()), infoFont));
                doc.add(new Paragraph("Tong tien cua hoa don: " + tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 7), infoFont));
                doc.add(new Paragraph("Tong tien cua hoa don sau giam gia: " + tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 8), infoFont));
                doc.add(new Paragraph("\n"));
                doc.add(new Paragraph("\n"));
                doc.add(new Paragraph("Danh sach san pham da mua"));
                ///tạo phông chữ cho bảng
                com.itextpdf.text.Font timesNewRoman = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12, com.itextpdf.text.Font.BOLD, BaseColor.DARK_GRAY);
                com.itextpdf.text.Font timesNewRoman2 = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12, com.itextpdf.text.Font.NORMAL, BaseColor.DARK_GRAY);

                // Tạo bảng
                PdfPTable tbl = new PdfPTable(8);
                tbl.setWidthPercentage(100);
                tbl.setSpacingBefore(10f);
                tbl.setSpacingAfter(10f);

                // Tieu de bang
                PdfPCell cell1 = new PdfPCell(new Phrase("Ten san pham", timesNewRoman));
                cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell1);

                PdfPCell cell2 = new PdfPCell(new Phrase("Size", timesNewRoman));
                cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell2);

                PdfPCell cell3 = new PdfPCell(new Phrase("Mau sac", timesNewRoman));
                cell3.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell3);

                PdfPCell cell4 = new PdfPCell(new Phrase("Chat lieu", timesNewRoman));
                cell4.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell4);

                PdfPCell cell5 = new PdfPCell(new Phrase("Hang", timesNewRoman));
                cell5.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell5);

                PdfPCell cell6 = new PdfPCell(new Phrase("Don gia", timesNewRoman));
                cell6.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell6);

                PdfPCell cell7 = new PdfPCell(new Phrase("So luong", timesNewRoman));
                cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell7);

                PdfPCell cell8 = new PdfPCell(new Phrase("Thanh tien", timesNewRoman));
                cell8.setBackgroundColor(BaseColor.LIGHT_GRAY);
                tbl.addCell(cell8);
                //  Bang Du lieu san pham
                for (HoaDonChiTiet hdct : reponHDCT.selectHDCTByMaHD(hoaDon_id)) {
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getMaspct()), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getTensp()), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getTenmausac()), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getTenchatlieu()), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getTenkichco()), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getSoLuong() + ""), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getGia_SPCT() + ""), timesNewRoman2)));
                    tbl.addCell(new PdfPCell(new Phrase(removeDiacritics(hdct.getTongTienCuaHDCT() + ""), timesNewRoman2)));
                }
                String tongTien = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 7).toString();
                PdfPCell totalCell = new PdfPCell(new Phrase("Thanh tien: " + tongTien, timesNewRoman));
                totalCell.setColspan(8); // Đặt colspan bằng số lượng cột của bảng
                totalCell.setHorizontalAlignment(Element.ALIGN_RIGHT); // Căn chỉnh về bên phải
                tbl.addCell(totalCell);
                doc.add(tbl);

                doc.add(new Paragraph("\n"));
                doc.add(new Paragraph("\n"));

                com.itextpdf.text.Font titleFont2 = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 20, com.itextpdf.text.Font.BOLD, BaseColor.BLACK);
                com.itextpdf.text.Font hanTraFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12, com.itextpdf.text.Font.BOLD, BaseColor.BLACK);

                Paragraph hanTra = new Paragraph("Dia chi : Noi tinh yeu bat dau ", hanTraFont);
                doc.add(hanTra);

                Paragraph title2 = new Paragraph("CHUC QUY KHACH MUA SAM VUI VE!!!!", titleFont2);
                doc.add(title2);
                doc.add(new Paragraph("\n"));

                //Tạo footer bằng bảng
                PdfPTable footer = new PdfPTable(1);
                footer.setWidthPercentage(100);
                footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

                // Tạo font Times New Roman cho footer
                com.itextpdf.text.Font footerFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 12, com.itextpdf.text.Font.BOLD, BaseColor.BLACK);

                // Thêm nội dung footer với font Times New Roman
                PdfPCell footerCell = new PdfPCell(new Phrase("----------------------------- CAM ON QUY KHACH DA LUA CHON CUA HANG ---------------------------", footerFont));
                footer.addCell(footerCell);
                doc.add(footer);

                doc.close();
                System.out.println("Xuất hoá đơn bán lẻ nè hhihi");
                int choice = JOptionPane.showConfirmDialog(this, "Xem hoá đơn vừa tạo?", "XEM HOÁ ĐƠN", JOptionPane.YES_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    openPdfFile(filePath);
                }

            } catch (DocumentException ex) {
                //  Logger.getLogger(HoaDon_View.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                // Logger.getLogger(HoaDon_View.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                // Logger.getLogger(HoaDon_View.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Hoá đơn đã trả hết hàng!!");
        }
    }//GEN-LAST:event_btnInHoaDonActionPerformed

    private static void openPdfFile(String filePath) {
        try {
            File file = new File(filePath);
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(file);
            } else {
                System.out.println("Desktop is not supported");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String removeDiacritics(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        input = input.replace("Đ", "D");
        input = input.replace("đ", "d");
        String decomposed = Normalizer.normalize(input, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(decomposed).replaceAll("");
    }

    private void tblhoaDonCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblhoaDonCTMouseClicked

    }//GEN-LAST:event_tblhoaDonCTMouseClicked

    private void btnXuatHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXuatHoaDonActionPerformed
        int option = JOptionPane.showConfirmDialog(this, "Bạn có đồng xuất danh sách?", "Xác nhận",
                JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            try {
                ArrayList<HoaDon> listHD = reponHD.getAll();
                XSSFWorkbook workbook = new XSSFWorkbook();
                XSSFSheet sheet = workbook.createSheet("Hóa Đơn");
                XSSFSheet sheet2 = workbook.createSheet("Hóa Đơn Chi Tiết");
                XSSFSheet sheet3 = workbook.createSheet("Lịch Sử Hóa Đơn");
                XSSFRow row = null;
                XSSFRow row2 = null;
                XSSFRow row3 = null;
                Cell cell = null;
                Cell cell2 = null;
                Cell cell3 = null;

                // Xuất phần hóa đơn
                row = sheet.createRow(0);
                cell = row.createCell(0, CellType.STRING);
                cell.setCellValue("STT");

                cell = row.createCell(1, CellType.STRING);
                cell.setCellValue("MaHD");

                cell = row.createCell(2, CellType.STRING);
                cell.setCellValue("MaNV");

                cell = row.createCell(3, CellType.STRING);
                cell.setCellValue("TenKH");

                cell = row.createCell(4, CellType.STRING);
                cell.setCellValue("SDT");

                cell = row.createCell(5, CellType.STRING);
                cell.setCellValue("NgayTaoHoaDon");

                cell = row.createCell(6, CellType.STRING);
                cell.setCellValue("NgayThanhToan");

                cell = row.createCell(7, CellType.STRING);
                cell.setCellValue("TongTien");

                cell = row.createCell(8, CellType.STRING);
                cell.setCellValue("TongTien");

                cell = row.createCell(9, CellType.STRING);
                cell.setCellValue("HinhThuc");

                cell = row.createCell(10, CellType.STRING);
                cell.setCellValue("TrangThai");

                cell = row.createCell(11, CellType.STRING);
                cell.setCellValue("GhiChu");

                // Xuất phần hóa đơn chi tiết
                row2 = sheet2.createRow(0);
                cell2 = row2.createCell(0, CellType.STRING);
                cell2.setCellValue("STT");

                cell2 = row2.createCell(1, CellType.STRING);
                cell2.setCellValue("MaCTSP");

                cell2 = row2.createCell(2, CellType.STRING);
                cell2.setCellValue("Tên SP");

                cell2 = row2.createCell(3, CellType.STRING);
                cell2.setCellValue("Số Lượng");

                cell2 = row2.createCell(4, CellType.STRING);
                cell2.setCellValue("Màu Sắc");

                cell2 = row2.createCell(5, CellType.STRING);
                cell2.setCellValue("Nhãn Hiệu");

                cell2 = row2.createCell(6, CellType.STRING);
                cell2.setCellValue("Chất Liệu");

                cell2 = row2.createCell(7, CellType.STRING);
                cell2.setCellValue("Kích Cỡ");

                cell2 = row2.createCell(8, CellType.STRING);
                cell2.setCellValue("Giá");

                cell2 = row2.createCell(9, CellType.STRING);
                cell2.setCellValue("Tổng Tiền Của Hóa Đơn");

                // Xuất phần lịch sử 
                row3 = sheet3.createRow(0);
                cell3 = row3.createCell(0, CellType.STRING);
                cell3.setCellValue("STT");

                cell3 = row3.createCell(1, CellType.STRING);
                cell3.setCellValue("Mã NV");

                cell3 = row3.createCell(2, CellType.STRING);
                cell3.setCellValue("Ngày Giờ");

                cell3 = row3.createCell(3, CellType.STRING);
                cell3.setCellValue("Hành Động");

                for (int i = 0; i < listHD.size(); i++) {
                    HoaDon hoaDon = listHD.get(i);
                    row = sheet.createRow(i + 1);
                    BigDecimal tiensaugiam = BigDecimal.ZERO;
                    if (hoaDon.getTongTienSauGiamGia().compareTo(BigDecimal.ZERO) > 0) {
                        tiensaugiam = hoaDon.getTongTienSauGiamGia();
                    } else {
                        tiensaugiam = hoaDon.getTongTienHoaDon();
                    }
                    cell = row.createCell(0, CellType.NUMERIC);
                    cell.setCellValue(i + 1);

                    cell = row.createCell(1, CellType.STRING);
                    cell.setCellValue(hoaDon.getMa());

                    cell = row.createCell(2, CellType.STRING);
                    cell.setCellValue(hoaDon.getIdNhanVien().getMaNV());

                    cell = row.createCell(3, CellType.STRING);
                    cell.setCellValue(hoaDon.getIdKhachHang().getTenKH());

                    cell = row.createCell(4, CellType.STRING);
                    cell.setCellValue(hoaDon.getIdKhachHang().getSdt());

                    cell = row.createCell(5, CellType.STRING);
                    cell.setCellValue(date2String(hoaDon.getNgaytaohoadon()));

                    cell = row.createCell(6, CellType.STRING);
                    cell.setCellValue(date2String(hoaDon.getNgaythanhtoan()));

                    cell = row.createCell(7, CellType.NUMERIC);
                    cell.setCellValue(NumberFormat.getInstance().format(hoaDon.getTongTienHoaDon().doubleValue()));

                    cell = row.createCell(8, CellType.NUMERIC);
                    cell.setCellValue(NumberFormat.getInstance().format(tiensaugiam));

                    cell = row.createCell(9, CellType.STRING);
                    cell.setCellValue(hoaDon.getThanhToan().getTenhinhthuc());

                    cell = row.createCell(10, CellType.STRING);
                    cell.setCellValue(hoaDon.getTinhTrang());

                    cell = row.createCell(11, CellType.STRING);
                    cell.setCellValue(hoaDon.getGhichu());
                }

                List<HoaDonChiTiet> listHDCT = reponHDCT.getInHoaDonCT();
                for (int i = 0; i < listHDCT.size(); i++) {
                    //System.out.println("Danh Sách HDCT" +listHDCT);
                    HoaDonChiTiet hoaDonCT = listHDCT.get(i);
                    row = sheet2.createRow(i + 1);

                    cell = row.createCell(0, CellType.NUMERIC);
                    cell.setCellValue(i + 1);

                    cell = row.createCell(1, CellType.STRING);
                    cell.setCellValue(hoaDonCT.getIdSPCT().getMa());

                    cell = row.createCell(2, CellType.STRING);
                    cell.setCellValue(hoaDonCT.getIdSPCT().getTenSanPham().getTenSP());

                    cell = row.createCell(3, CellType.NUMERIC);
                    cell.setCellValue(hoaDonCT.getSoLuong());

                    cell = row.createCell(4, CellType.NUMERIC);
                    cell.setCellValue(hoaDonCT.getIdSPCT().getTenMauSac().getTenMauSac());

                    cell = row.createCell(5, CellType.NUMERIC);
                    cell.setCellValue(hoaDonCT.getIdSPCT().getTenNhanHieu().getTen());

                    cell = row.createCell(6, CellType.NUMERIC);
                    cell.setCellValue(hoaDonCT.getIdSPCT().getTenChatlieu().getTen());

                    cell = row.createCell(7, CellType.NUMERIC);
                    cell.setCellValue(hoaDonCT.getIdSPCT().getTenKichCo().getTenKichCo());

                    cell = row.createCell(8, CellType.NUMERIC);
                    cell.setCellValue(NumberFormat.getInstance().format(hoaDonCT.getIdSPCT().getGiaBan1().doubleValue()));

                    cell = row.createCell(9, CellType.NUMERIC);
                    cell.setCellValue(hoaDonCT.getHoaDon().getTongTienHoaDon().doubleValue());

                }

                List<LichSuHoaDon> listLSHD = reponLSHD.getListHD();
                for (int i = 0; i < listLSHD.size(); i++) {
                    LichSuHoaDon lshd = listLSHD.get(i);
                    row = sheet3.createRow(i + 1);

                    cell = row.createCell(0, CellType.NUMERIC);
                    cell.setCellValue(i + 1);

                    cell = row.createCell(1, CellType.STRING);
                    cell.setCellValue(lshd.getNhanVien().getMaNV());

                    cell = row.createCell(2, CellType.STRING);
                    cell.setCellValue(lshd.getHoaDon().getNgaytaohoadon());

                    cell = row.createCell(3, CellType.STRING);
                    cell.setCellValue(lshd.getHanhdong());
                }
                FileOutputStream fileOut = new FileOutputStream("D:\\Excel\\HoaDon.xlsx");
                workbook.write(fileOut);
                fileOut.close();
                workbook.close();
                JOptionPane.showMessageDialog(this, "Xuất danh sách thành công");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            // Xử lý khi người dùng không đồng ý thêm
            JOptionPane.showMessageDialog(this, "Đã hủy xuất danh sách", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnXuatHoaDonActionPerformed

//  
    private void tblHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHoaDonMouseClicked
        String maHOaDON = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 1).toString();
        loadTableHDCT(reponHDCT.selectHDCTByMaHD(maHOaDON));
        loadTablelichSuHoaDon(reponHD.selectLSHDByMaHD(maHOaDON));
    }//GEN-LAST:event_tblHoaDonMouseClicked

    void loadTableHDCT(List<HoaDonChiTiet> listHDCT) {
        DefaultTableModel modelHDCT = (DefaultTableModel) tblhoaDonCT.getModel();
        modelHDCT.setRowCount(0);
        int stt = 1;
        for (HoaDonChiTiet hdct : listHDCT) {
            Object[] row = new Object[]{
                stt++,
                hdct.getMaspct(),
                hdct.getTensp(),
                hdct.getSoLuong(),
                hdct.getGia_SPCT(),
                hdct.getTongTienCuaHDCT()
            };
            modelHDCT.addRow(row);

        }
    }

    void loadTablelichSuHoaDon(List<LichSuHoaDon> listLSHD) {
        modelLSHD = (DefaultTableModel) tblLichSuHoaDon.getModel();
        modelLSHD.setRowCount(0);
        int st = 1;
        for (LichSuHoaDon lshd : listLSHD) {
            Object[] trow = new Object[]{
                st++,
                lshd.getNhanVien().getMaNV(),
                date2String(lshd.getHoaDon().getNgaytaohoadon()),
                lshd.getHanhdong()
            };
            modelLSHD.addRow(trow);
        }
    }

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        // TODO add your handling code here:'
        String tk = txtTimKiem.getText();
        search(tk);
    }//GEN-LAST:event_txtTimKiemKeyReleased
    void search(String str) {
        DefaultTableModel model = (DefaultTableModel) tblHoaDon.getModel();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
        tblHoaDon.setRowSorter(trs);
        String searchText = txtTimKiem.getText().trim();
        trs.setRowFilter(RowFilter.regexFilter(str));
    }
    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void txtTimKiemFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiemFocusLost
        // TODO add your handling code here:
        if (txtTimKiem.getText().length() == 0) {
            AddPleacehoderStyle(txtTimKiem);
            txtTimKiem.setText("Tìm theo các trường của table");
        }
    }//GEN-LAST:event_txtTimKiemFocusLost

    private void txtTimKiemFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiemFocusGained
        // TODO add your handling code here:
        if (txtTimKiem.getText().equals("Tìm theo các trường của table")) {
            txtTimKiem.setText(null);
            txtTimKiem.requestFocus();
            RemovePleacehoderStyle(txtTimKiem);
        }
    }//GEN-LAST:event_txtTimKiemFocusGained

    private void txtTimKiemCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtTimKiemCaretUpdate
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemCaretUpdate

    private void txt_TimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_TimKiemActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_txt_TimKiemActionPerformed

    private void txt_TimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_TimKiemKeyReleased
        // TODO add your handling code here
    }//GEN-LAST:event_txt_TimKiemKeyReleased

    public void showForm() {
        removeAll();
        setLayout(new BorderLayout());
        add(new BanHangForm());
        repaint();
        revalidate();
    }

    private void txt_TimKiemFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_TimKiemFocusGained
        // TODO add your handling code here:
        if (txt_TimKiem.getText().equals("Mã")) {
            txt_TimKiem.setText(null);
            txt_TimKiem.requestFocus();
            RemovePleacehoderStyle(txt_TimKiem);
        }
    }//GEN-LAST:event_txt_TimKiemFocusGained

    private void txt_TimKiemFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_TimKiemFocusLost
        // TODO add your handling code here:
        if (txt_TimKiem.getText().length() == 0) {
            AddPleacehoderStyle(txt_TimKiem);
            txt_TimKiem.setText("Mã");
        }
    }//GEN-LAST:event_txt_TimKiemFocusLost

    private void tblLichSuHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLichSuHoaDonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblLichSuHoaDonMouseClicked

    HoaDonTraHangCT readForm() {
//        int row = tblHoaDonTraHang.getSelectedRow();
//        String ma = tblHoaDonTraHang.getValueAt(row, 1).toString();
//        String ten = tblHoaDonTraHang.getValueAt(row, 2).toString();
//        String ma = tblHoaDonTraHang.getValueAt(row, 3).toString();
//        String ma = tblHoaDonTraHang.getValueAt(row, 4).toString();
//        String ma = tblHoaDonTraHang.getValueAt(row, 5).toString();
//        String soLuong = tblHoaDonTraHang.getValueAt(row, 6).toString();
        return new HoaDonTraHangCT();
    }

    private void btnLocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocActionPerformed
        if (dateNgayThanhToan.getDateFormatString().toString().trim().isEmpty() || dateNgayThanhToan2.getDateFormatString().toString().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ ngày và giờ");
            return;
        } else {
            List<HoaDon> list = reponHD.findDate(dateNgayThanhToan, dateNgayThanhToan2);
            DefaultTableModel model = (DefaultTableModel) tblHoaDon.getModel();
            model.setRowCount(0);
            int stt = 1;
            for (HoaDon hoaDon : list) {
                String tinhTrang = "";
                int tinhTrangValue = hoaDon.getTinhTrang();
                if (tinhTrangValue == 0) {
                    tinhTrang = "Chờ Thanh Toán";
                } else if (tinhTrangValue == 1) {
                    tinhTrang = "Đã Thanh Toán";
                } else if (tinhTrangValue == 2) {
                    tinhTrang = "Đã Hủy";
                }
                BigDecimal tiensaugiam = BigDecimal.ZERO;
                if (hoaDon.getTongTienSauGiamGia().compareTo(BigDecimal.ZERO) > 0) {
                    tiensaugiam = hoaDon.getTongTienSauGiamGia();
                } else {
                    tiensaugiam = hoaDon.getTongTienHoaDon();
                }

                Object[] row = new Object[]{
                    stt++,
                    hoaDon.getMa(),
                    hoaDon.getIdNhanVien().getMaNV(),
                    hoaDon.getIdKhachHang().getTenKH(),
                    hoaDon.getIdKhachHang().getSdt(),
                    hoaDon.getNgaytaohoadon(),
                    hoaDon.getNgaythanhtoan(),
                    hoaDon.getTongTienHoaDon() == null ? "0" : NumberFormat.getInstance().format(hoaDon.getTongTienHoaDon()),
                    NumberFormat.getInstance().format(tiensaugiam),
                    hoaDon.getThanhToan().getTenhinhthuc(),
                    hoaDon.getGhichu(),
                    tinhTrang,};
                model.addRow(row);
            }
        }        // TODO add your handling code here:

    }//GEN-LAST:event_btnLocActionPerformed

    private HoaDonTraHangCT getFormData() {
        int row = tblHoaDonChiTiet.getSelectedRow();
        String ma = tblHoaDonChiTiet.getValueAt(row, 1).toString();
        int soluong = Integer.parseInt(tblHoaDonChiTiet.getValueAt(row, 3).toString());
        //String idspct = getidspct.getIdSanPhamChiTiet(ma);
        BigDecimal gia = BigDecimal.valueOf(Double.parseDouble(tblHoaDonChiTiet.getValueAt(row, 4).toString()));
        return new HoaDonTraHangCT(ma, soluong, gia);
    }

    private void tblHoaDonChiTietMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHoaDonChiTietMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblHoaDonChiTietMouseClicked

    // fill table trả hàng
    void fillTable(List<HoaDonChiTiet> listHDCT) {
        model = (DefaultTableModel) tblHoaDonChiTiet.getModel();
        int stt = tblHoaDonChiTiet.getSelectedRow();
        model.setRowCount(0);
        stt += 1;
        for (HoaDonChiTiet hdct : listHDCT) {
            Object[] row = new Object[]{
                stt += 1,
                hdct.getIdSPCT().getMa(),
                hdct.getIdSPCT().getTenSanPham(),
                hdct.getSoLuong(),
                hdct.getGia_SPCT(),
                hdct.getIdSPCT().getTenNhanHieu().getTen(),
                hdct.getIdSPCT().getTenMauSac().getTenMauSac(),
                hdct.getIdSPCT().getTenKichCo().getTenKichCo(),
                hdct.getHoaDon().getTongTienHoaDon(),};
            model.addRow(row);
        }
    }

    private void txt_TimKiemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_TimKiemKeyPressed
        // TODO add your handling code here:
//        DefaultTableModel modelHDTraHang = new DefaultTableModel();
//        modelHDTraHang = (DefaultTableModel) tblHoaDonChiTiet.getModel();
//        modelHDTraHang.setRowCount(0);
//        listHDCT = reponHDCT.getAll();
//        String searchText = txt_TimKiem.getText().trim().toLowerCase(); // Lấy và chuẩn hóa dữ liệu nhập vào
//        int stt = 1; // Khởi tạo số thứ tự từ 1
//        for (HoaDonChiTiet hdct : listHDCT) {
//            // So sánh ID sản phẩm với từ khóa tìm kiếm
//            if (hdct.getIdSPCT().getMa().toLowerCase().contains(searchText)) {
//                Object[] row = new Object[]{
//                    stt++,
//                    hdct.getIdSPCT().getMa(),
//                    hdct.getIdSPCT().getTenSanPham().getTenSP(),
//                    hdct.getSoLuong(),
//                    NumberFormat.getInstance().format(hdct.getGia_SPCT()),
//                    hdct.getIdSPCT().getTenNhanHieu().getTen(),
//                    hdct.getIdSPCT().getTenMauSac().getTenMauSac(),
//                    hdct.getIdSPCT().getTenKichCo().getTenKichCo(),
//                    NumberFormat.getInstance().format(hdct.getHoaDon().getTongTienHoaDon()),};
//                modelHDTraHang.addRow(row);
//            }
//        }

    }//GEN-LAST:event_txt_TimKiemKeyPressed


    private void cboTTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboTTActionPerformed

    private void cboTTItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboTTItemStateChanged
        // TODO add your handling code here:
        locHoaDon();
    }//GEN-LAST:event_cboTTItemStateChanged

    private void btnXuatDanhSachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXuatDanhSachActionPerformed
        // TODO add your handling code here:
        int option = JOptionPane.showConfirmDialog(this, "Bạn có đồng xuất danh sách?", "Xác nhận",
                JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            try {
                XSSFWorkbook workbook = new XSSFWorkbook();
                XSSFSheet sheet2 = workbook.createSheet("Hóa Đơn Chi Tiết");
                XSSFRow row2 = null;
                Cell cell2 = null;
                // Xuất phần hóa đơn chi tiết
                row2 = sheet2.createRow(0);
                cell2 = row2.createCell(0, CellType.STRING);
                cell2.setCellValue("STT");

                cell2 = row2.createCell(1, CellType.STRING);
                cell2.setCellValue("Mã CTSP");

                cell2 = row2.createCell(2, CellType.STRING);
                cell2.setCellValue("Tên SP");

                cell2 = row2.createCell(3, CellType.STRING);
                cell2.setCellValue("Số Lượng");

                cell2 = row2.createCell(4, CellType.STRING);
                cell2.setCellValue("Màu Sắc");

                cell2 = row2.createCell(5, CellType.STRING);
                cell2.setCellValue("Nhãn Hiệu");

                cell2 = row2.createCell(6, CellType.STRING);
                cell2.setCellValue("Chất Liệu");

                cell2 = row2.createCell(7, CellType.STRING);
                cell2.setCellValue("Kích Cỡ");

                cell2 = row2.createCell(8, CellType.STRING);
                cell2.setCellValue("Giá");

                cell2 = row2.createCell(9, CellType.STRING);
                cell2.setCellValue("Tổng Tiền Của Hóa Đơn");

                List<HoaDonChiTiet> listHDCT = reponHDCT.getInHoaDonCT(txt_TimKiem.getText());
                for (int i = 0; i < listHDCT.size(); i++) {
                    HoaDonChiTiet hoaDonCT = listHDCT.get(i);
                    row2 = sheet2.createRow(i + 1);

                    cell2 = row2.createCell(0, CellType.NUMERIC);
                    cell2.setCellValue(i + 1);

                    cell2 = row2.createCell(1, CellType.STRING);
                    cell2.setCellValue(hoaDonCT.getIdSPCT().getMa());

                    cell2 = row2.createCell(2, CellType.STRING);
                    cell2.setCellValue(hoaDonCT.getIdSPCT().getTenSanPham().getTenSP());

                    cell2 = row2.createCell(3, CellType.NUMERIC);
                    cell2.setCellValue(hoaDonCT.getSoLuong());

                    cell2 = row2.createCell(4, CellType.NUMERIC);
                    cell2.setCellValue(hoaDonCT.getIdSPCT().getTenMauSac().getTenMauSac());

                    cell2 = row2.createCell(5, CellType.NUMERIC);
                    cell2.setCellValue(hoaDonCT.getIdSPCT().getTenNhanHieu().getTen());

                    cell2 = row2.createCell(6, CellType.NUMERIC);
                    cell2.setCellValue(hoaDonCT.getIdSPCT().getTenChatlieu().getTen());

                    cell2 = row2.createCell(7, CellType.NUMERIC);
                    cell2.setCellValue(hoaDonCT.getIdSPCT().getTenKichCo().getTenKichCo());

                    cell2 = row2.createCell(8, CellType.NUMERIC);
                    cell2.setCellValue(NumberFormat.getInstance().format(hoaDonCT.getIdSPCT().getGiaBan1().doubleValue()));

                    cell2 = row2.createCell(9, CellType.NUMERIC);
                    cell2.setCellValue(hoaDonCT.getHoaDon().getTongTienHoaDon().doubleValue());

                }
                FileOutputStream fileOut = new FileOutputStream("D:\\Excel\\HoaDon.xlsx");
                workbook.write(fileOut);
                fileOut.close();
                workbook.close();
                JOptionPane.showMessageDialog(this, "Xuất danh sách thành công");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            // Xử lý khi người dùng không đồng ý thêm
            JOptionPane.showMessageDialog(this, "Đã hủy xuất danh sách", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btnXuatDanhSachActionPerformed

    void locHoaDon() {
        Integer trangthai = null;
        String tenhinhthuc = null;
        if (cboHTTT.getItemCount() == 3 && cboTT.getItemCount() == 4) {
            // hàm trạng thái
            if (cboTT.getSelectedItem().equals("Tất Cả")) {
                this.loadTableHoaDon(reponHD.getAll());
            } else if (cboTT.getSelectedItem().equals("Đã Thanh Toán")) {
                trangthai = 1;

            } else if (cboTT.getSelectedItem().equals("Chờ Thanh Toán")) {
                trangthai = 0;

            } else if (cboTT.getSelectedItem().equals("Đã Hủy")) {
                trangthai = 3;

            }
            // hàm tên httt
            if (cboHTTT.getSelectedItem().equals("Tất Cả")) {
                tenhinhthuc = null;
            } else {
                tenhinhthuc = cboHTTT.getSelectedItem().toString();
            }
            this.loadTableHoaDon(reponHD.getCBB(trangthai, tenhinhthuc));
        }
    }

    private void cboHTTTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboHTTTMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_cboHTTTMouseClicked

    private void cboHTTTItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboHTTTItemStateChanged
        // TODO add your handling code here: 
        locHoaDon();
    }//GEN-LAST:event_cboHTTTItemStateChanged

    private void btnTimKiemHDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTimKiemHDMouseClicked
        // TODO add your handling code here:
        if (reponHD.selectHDByMaHD(txt_TimKiem.getText()) == null) {
            JOptionPane.showMessageDialog(this, "Hóa đơn không tìm thấy");
        } else {
            System.out.println("Tìm thấy mã HĐ");
            for (HoaDon hd : reponHD.selectHDByMaHD(txt_TimKiem.getText())) {
                // System.out.println("Mã HĐ" + reponHD.selectHDByMaHD(txtTimKiem.getText()).get(0).getMa());
                String trangthai = "";
                if (hd.getTinhTrang() == 0) {
                    trangthai = "Chờ Thanh Toán";
                } else if (hd.getTinhTrang() == 1) {
                    trangthai = "Đã Thanh Toán";
                } else if (hd.getTinhTrang() == 2) {
                    trangthai = "Chưa Thanh Toán";
                } else {
                    trangthai = "Đã Hủy";
                }
                txtMaHDTH.setText(hd.getMa());
                txtTenKH.setText(hd.getIdKhachHang().getTenKH());
                txtTrangThai.setText(trangthai);
                txtSDT.setText(hd.getIdKhachHang().getSdt());
                txtTongTien.setText(hd.getTongTienHoaDon().toString());
                txtGhiChu.setText(hd.getGhichu());
            }
            this.loadTableHoaDonCT(reponHDCT.selectHDCTByMaHD(txt_TimKiem.getText().trim()));
            System.out.println("tẽt: " + txt_TimKiem);
        }
    }//GEN-LAST:event_btnTimKiemHDMouseClicked

    private void txtTongTienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTongTienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTongTienActionPerformed

    public void loadTableHoaDonCT(List<HoaDonChiTiet> listHDCT) {
        DefaultTableModel modelTimKiem = (DefaultTableModel) tblHoaDonChiTiet.getModel();
        modelTimKiem.setRowCount(0);
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
        int stt = 1;
        for (HoaDonChiTiet h : listHDCT) {
            modelTimKiem.addRow(new Object[]{
                stt++,
                h.getMaspct(),
                h.getTensp(),
                h.getTenmausac(),
                h.getTenchatlieu(),
                h.getTenkichco(),
                h.getSoLuong(),
                NumberFormat.getInstance().format(h.getGia_SPCT()),
                h.getTongTienCuaHDCT()
            });
        }
    }

//    void showDataTraHang() {
//        HoaDon hd = reponHD.getAll().get(index);
//        txtMaHDTH.setText(hd.getMa());
//        txtTenKH.setText(hd.getIdKhachHang().getTenKH());
//        //txtDiaChi.setText(hd.getIdKhachHang().getDiaChi());
//        txtSDT.setText(hd.getIdKhachHang().getSdt());
//        txtEmail.setText(hd.getId_khachhang());
//        txtTongTien.setText(hd.getTongTienHoaDon().toString());
//        txtGhiChu.setText(hd.getGhichu());
//    }
    void showData(int index) {
        //        HoaDonTraHang hd = reponHDTH.mouseClickTraHang().get(index);
        //        txtMaHDNgoai.setText(hd.getMa());
        //        txtTenKHNgoai.setText(hd.getKhachHang().getTen());
        //        txtDiaChiNgoai.setText(hd.getKhachHang().getDiachi());
        //        txtThanhTienNgoai.setText(String.valueOf(hd.getTienHoanTra()));
    }

    void HoaDonJDialog() {
        Main m = new Main();
        new HoaDonTraHangJDiaLog(m, true).setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInHoaDon;
    private javax.swing.JButton btnLoc;
    private javax.swing.JButton btnTimKiemHD;
    private javax.swing.JButton btnXuatDanhSach;
    private javax.swing.JButton btnXuatHoaDon;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboHTTT;
    private javax.swing.JComboBox<String> cboTT;
    private com.toedter.calendar.JDateChooser dateNgayThanhToan;
    private com.toedter.calendar.JDateChooser dateNgayThanhToan2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel pnQuetQR;
    private javax.swing.JTable tblHoaDon;
    private javax.swing.JTable tblHoaDonChiTiet;
    private javax.swing.JTable tblLichSuHoaDon;
    private javax.swing.JTable tblhoaDonCT;
    private javax.swing.JTextArea txtGhiChu;
    private javax.swing.JTextField txtMaHDTH;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTenKH;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtTongTien;
    private javax.swing.JTextField txtTrangThai;
    private javax.swing.JTextField txt_TimKiem;
    // End of variables declaration//GEN-END:variables

    public void addQRCode(String maHDCT) {
        try {
            // kiểm tra và tạo thư mục đích nếu nó chưa tồn tại
            String path = "";
            File dic = new File(path);
            if (!dic.exists()) {
                dic.mkdirs();
            }
            ByteArrayOutputStream out = QRCode.from(maHDCT).to(ImageType.PNG).stream();

            String fileName = maHDCT + ".PNG";
            String fullPath = path + fileName;
            // Ghi hình ảnh vào tệp
            try (FileOutputStream fout = new FileOutputStream(new File(fullPath))) {
                fout.write(out.toByteArray());
                fout.flush();
                System.out.println("Đã tạo và lưu hình ảnh QR code : " + fileName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void loadTableHoaDonChiTietTH() {

    }

    private void initWebcam() {
        Dimension size = WebcamResolution.QVGA.getSize();
        webcam = Webcam.getWebcams().get(0); //0 is default webcam
        webcam.setViewSize(size);
        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(true);
        pnQuetQR.add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 150));
        executor.execute(this);
    }

    @Override
    public void run() {
        String randomCode = generateRandomCode(12);
        do {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Result result = null;
            BufferedImage image = null;
            if (webcam.isOpen()) {
                if ((image = webcam.getImage()) == null) {
                    continue;
                }
            }
            LuminanceSource source = new BufferedImageLuminanceSource(image);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            try {
                result = new MultiFormatReader().decode(bitmap);
            } catch (NotFoundException e) {
                //No result...
            }
            if (result != null) {
                txtMaHDTH.setText(randomCode);
            }
        } while (true);
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, "My Thread");
        t.setDaemon(true);
        return t;
    }

    public static String generateRandomCode(int length) {
        Random random = new Random();
        StringBuilder codeBuilder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int randomNumber = random.nextInt(10); // Sinh số ngẫu nhiên từ 0 đến 9
            codeBuilder.append(randomNumber);
        }

        return codeBuilder.toString();
    }

    void saveHistory() {
        String path = " ";
        try {
            FileWriter writer = new FileWriter(path);
            for (HoaDon hoaDon : listHD) {
                writer.write(hoaDon.toString());
                writer.write(System.lineSeparator());
            }
            writer.close();
        } catch (IOException e) {
            return;
        }
    }

    Date homnay() {
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String formatdate = sdf.format(now);
        return now;
    }

    TaoMaTuSinh_inf genMaHD = new TaoMaTuSinh_inf() {
        @Override
        public String maTuSinh() {
            //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            int maTuSinh = new Random().nextInt(1000000);
            return "HD" + maTuSinh;
        }
    };

    HoaDon readFormHoaDon() {
        KhachHang kh = new KhachHang();
        String id = "069E3C6B-9DD1-4081-B992-E90E08DE5A34";
        HinhThucThanhToan httt = new HinhThucThanhToan();
        String id_httt = "9475E3F6-0DE3-4563-B634-3D780F8423B8";
        UUID id_tt = UUID.fromString(id_httt);
        UUID uuid = UUID.fromString(id);
        kh.setID(uuid);
        httt.setID(id_tt);
        return new HoaDon(
                genMaHD.maTuSinh(),
                "",
                "",
                homnay(),
                BigDecimal.valueOf(0),
                homnay(),
                homnay(),
                homnay(),
                homnay(),
                BigDecimal.valueOf(0),
                BigDecimal.valueOf(0),
                0,
                "",
                id,
                XLogin.user.getId(),
                XLogin.user.getId(),
                homnay(),
                0
        );
    }
}
