/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.raven.form;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import com.raven.classinterface.TaoMaTuSinh_inf;
import com.raven.classmodel.ChucVu;
import com.raven.classmodel.NhanVien;
import com.raven.classmodel.NhanVienRespose;
import com.raven.model.ZXingHelper;
import com.raven.reponsitory.ChucVu_DAO;
import com.raven.reponsitory.DBConnect;
import static com.raven.reponsitory.DBConnect.PASSWORD;

import com.raven.reponsitory.NhanVien_DAO;
import com.raven.service.GetIdSPCTService_Duc;
import java.sql.*;
import java.awt.Dimension;
import java.awt.image.BufferedImage;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import javax.mail.Authenticator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.Color;
import java.awt.Font;
import java.io.ByteArrayInputStream;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;

/**
 *
 * @author MSI 15
 */
public class QuanLyNhanVien extends javax.swing.JPanel implements Runnable, ThreadFactory {

    private ArrayList<NhanVien> list = new ArrayList<>();
    private NhanVien nv = new NhanVien();

    private NhanVien_DAO daoNV = new NhanVien_DAO();

    private GetIdSPCTService_Duc getid = new GetIdSPCTService_Duc();
    // private NhanVien_Service serviceNV = new NhanVien_Service();
    private DefaultTableModel model = new DefaultTableModel();
    private ChucVu_DAO daoCV = new ChucVu_DAO();
    private int index = -1;
    private NhanVienRespose nvResPon = new NhanVienRespose();
    private WebcamPanel panel = null;
    private Webcam webcam = null;
    private static final long serialVersionUID = 6441489157408381878L;
    private Executor executor = Executors.newSingleThreadExecutor(this);

    Connection cn;
    long count, soTrang, trang = 1;
    Statement st;
    ResultSet rs;

    /**
     * Creates new form NewJPanel
     */
    public QuanLyNhanVien() {
        initComponents();
        // initWebcam();

        //fillComBoBoxTrangThai();
        fillComBoBoxCHUCVU();
        fillTableNVPhanTrang(daoNV.selectAllPhanTrang(1));
        countDb();
        if (count % 5 == 0) {
            soTrang = count / 5;
        } else {
            soTrang = count / 5 + 1;
        }

        lbSoTrang.setText("1/" + soTrang);
        lbTrang.setText("1");
        AddPleacehoderStyle(txtTim);

    }

    public void countDb() {
        try {
            String sql = "Select count(*) from NhanVien inner join ChucVu on NhanVien.id_chucvu= ChucVu.id";
            cn = DBConnect.getConnection();
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
                count = rs.getLong(1);
            }
            rs.close();
            st.close();
            cn.close();
        } catch (SQLException ex) {
            Logger.getLogger(QuanLyNhanVien.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private String date2String(java.util.Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-YYYY");

        return sdf.format(date);
    }

    // Hàm tự viết để chuyển đổi ngày tháng
    private java.util.Date parseDate(String ngayThang) {
        // Đối tượng hỗ trợ đọc kiểu dữ liệu ngày tháng
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        //String date = DateFormat.
        try {
            return sdf.parse(ngayThang);
        } catch (Exception e) {
            //Nếu lỗi trả về thời điểm hiện tại
            return new java.util.Date();
        }
    }

    void fillTableNVPhanTrang(List<NhanVien> list) {
        model = (DefaultTableModel) tbNhanVien.getModel();
        model.setRowCount(0);
        int index = 0;
        try {
            for (NhanVien nv : list) {
                index++;
                Object[] row = new Object[]{
                    index,
                    nv.getMaNV(),
                    nv.getTenNV(),
                    nv.getId_chucVu().getTenCV(),
                    date2String(nv.getNgaySinh()),
                    nv.hienThiGioiTinh(),
                    nv.getSDT(),
                    nv.getEmail(),
                    nv.getDiaChi(),
                    nv.hienThiTrangThai()
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi truy vấn dữ liệu");
        }
    }

    void fillComBoBoxCHUCVU() {
        DefaultComboBoxModel mol = new DefaultComboBoxModel();
        mol.removeAllElements();
        List< ChucVu> listCD = daoCV.getAll();
        for (ChucVu nv : listCD) {
            mol.addElement(nv.getTenCV());
        }
        cboChucVu.setModel(mol);

    }

//    void fillComBoBoxTrangThai() {
//        DefaultComboBoxModel mol = new DefaultComboBoxModel();
//        jComboBox1.removeAllItems();
//        List< NhanVien> listCD = daoNV.selectAll();
//        for (NhanVien nv : listCD) {
//            jComboBox1.addItem(nv.hienThiTrangThai()+"");
//        }
//
//    }
//    void fillTable(List<NhanVien> list) {
//        model = (DefaultTableModel) tbNhanVien.getModel();
//        model.setRowCount(0);
//        int index = 0;
//        try {
//            for (NhanVien nv : list) {
//                index++;
//                Object[] row = new Object[]{
//                    index,
//                    nv.getMaNV(),
//                    nv.getTenNV(),
//                    nv.getId_chucVu().getTenCV(),
//                    nv.getNgaySinh(),
//                    nv.hienThiGioiTinh(),
//                    nv.getSDT(),
//                    nv.getEmail(),
//                    nv.getDiaChi(),
//                    nv.hienThiTrangThai()
//                };
//                model.addRow(row);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            JOptionPane.showMessageDialog(this, "Lỗi truy vấn dữ liệu");
//        }
//    }
    void editNhanVien() {
        try {
            String maKH = (String) tbNhanVien.getValueAt(this.index, 1);
            NhanVien model = daoNV.selectById(maKH);
            if (model != null) {
                this.setFormNhanVien(model);
                this.setStatus(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi truy vấn dữ liệu!");
        }
    }

    void setFormNhanVien(NhanVien nv) {
        txtTenNV.setText(nv.getTenNV());
        txtCCCD.setText(nv.getCccd());
        txtEmail.setText(nv.getEmail());
        txtDienThoai.setText(nv.getSDT());
        txtNgaySinh.setDate(nv.getNgaySinh());
        txtDiaChi.setText(nv.getDiaChi());
        txtMaNV.setText(nv.getMaNV());
        if (nv.getGioiTinh() == 1) {
            rbNam.setSelected(true);
        } else {
            rbNu.setSelected(true);
        }

        if (nv.getId_chucVu().getTenCV().equalsIgnoreCase("Nhân viên")) {
            cboChucVu.setSelectedIndex(0);
        } else {
            cboChucVu.setSelectedIndex(1);
        }

    }

    void setFromNV(int index) {
        NhanVien nv = daoNV.selectAllPhanTrang(trang).get(index);
        txtTenNV.setText(nv.getTenNV());
        txtCCCD.setText(nv.getCccd());
        txtEmail.setText(nv.getEmail());
        txtDienThoai.setText(nv.getSDT());
        txtNgaySinh.setDate(nv.getNgaySinh());
        txtDiaChi.setText(nv.getDiaChi());
        txtMaNV.setText(nv.getMaNV());
        if (nv.getGioiTinh() == 1) {
            rbNam.setSelected(true);
        } else {
            rbNu.setSelected(true);

        }
        //    if (nv.getTrangThai() == 1) {
        //  rbDangLam.setSelected(true);
        //   } else {
        //  rbNghiLam.setSelected(true);
        //    }
        if (nv.getId_chucVu().getTenCV().equalsIgnoreCase("Nhân viên")) {
            cboChucVu.setSelectedIndex(1);
        } else {
            cboChucVu.setSelectedIndex(0);
        }

    }

    void clearFormNhanVien() {
        txtMaNV.setText("");
        txtTenNV.setText("");
        txtCCCD.setText("");
        txtEmail.setText("");
        txtDienThoai.setText("");
        txtNgaySinh.setDate(null);
        txtDiaChi.setText("");
    }

    public static String generateRandomUUID() {
        // Tạo một UUID ngẫu nhiên
        UUID uuid = UUID.randomUUID();

        // Chuyển UUID thành chuỗi và trả về
        return uuid.toString();
    }

    NhanVienRespose getFormNhanVien() {
        TaoMaTuSinh_inf taoMaNhanVien = new TaoMaTuSinh_inf() {
            @Override
            public String maTuSinh() {
                //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                int maTuSinh = new Random().nextInt(1000000);
                return "NV" + maTuSinh;
            }
        };
        NhanVienRespose nv = new NhanVienRespose();
        nv.setMaNV(taoMaNhanVien.maTuSinh());
        nv.setDiaChi(txtDiaChi.getText());
        nv.setCccd(txtCCCD.getText());
        nv.setSDT(txtDienThoai.getText());
        nv.setTenNV(txtTenNV.getText());
        nv.setEmail(txtEmail.getText());
        nv.setNgaySinh(txtNgaySinh.getDate());
        nv.setGioiTinh(rbNam.isSelected() ? 1 : 0);
        nv.setId_chucvu(getChucVuIdFromComboBox());

        return nv;

    }

    private String getChucVuIdFromComboBox() {
        // Đoạn mã để lấy ID của ChucVu từ ComboBox, có thể thay đổi tùy thuộc vào cách bạn quản lý dữ liệu trong ComboBox.
        return getid.getIDChucVu(cboChucVu.getSelectedItem() + "");
    }

    void setStatus(boolean insertable) {
        txtMaNV.setEditable(insertable);
        btnThem.setEnabled(insertable);
        btnMoi.setEnabled(insertable);
        btnSUa.setEnabled(!insertable);
    }

    boolean test() {
        // String ktra = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\\\d)(?=.*[@#$%^&+=!])(?=\\\\S+$).{8,12}$";
        // if (txtMa.getText().isEmpty()) {
        //JOptionPane.showMessageDialog(this, "Mã không bỏ trống");

        // return false;
        //   } else if (txtMa.getText().length() > 20) {
        // JOptionPane.showMessageDialog(this, "Mã không được quá 20 kí tự");
        // return false;
        //  }
        if (txtTenNV.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên nhân viên!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return false;
        } else {
            if (!txtTenNV.getText().matches("[\\p{L}\\s-]+")) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập lại tên nhân viên!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }

        if (txtCCCD.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập CCCD!", "Thông báo", 0);
            return false;
        } else if (!txtCCCD.getText().matches("^[0-9]{9,12}$")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập lại CCCD!", "Thông báo", 0);
            return false;
        }
        if (daoNV.checkCCD(txtCCCD.getText())) {
            JOptionPane.showMessageDialog(this, "CCCD đã tồn tại. Vui lòng chọn CCCD khác!", "Thông báo", 0);
            return false;
        }
        if (txtDienThoai.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng số điện thoại!", "Thông báo", 0);
            return false;
        } else {
            if (!txtDienThoai.getText().matches("^09\\d{8}$")) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập lại số điện thoại ", "Thông báo", 0);
                return false;
            }
        }
        if (daoNV.checkSPSDT(txtDienThoai.getText())) {
            JOptionPane.showMessageDialog(this, "Số điện thoại đã tồn tại. Vui lòng chọn số khác!", "Thông báo", 0);
            return false;
        }
        if (txtEmail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập email!", "Thông báo", 0);
            return false;
        } else if (!txtEmail.getText().matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập lại email!", "Thông báo", 0);
            return false;
        }
        if (daoNV.checkEmail(txtEmail.getText())) {
            JOptionPane.showMessageDialog(this, "Email đã tồn tại. Vui lòng chọn email khác!", "Thông báo", 0);
            return false;
        }
        Date currentDate = new Date();
        if (txtNgaySinh.getDate() == null || txtNgaySinh.getDate().after(currentDate)) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập lại ngày sinh!", "Thông báo", 0);

            return false;
        }

        if (txtDiaChi.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập địa chỉ!", "Thông báo", 0);
            return false;
        }
        return true;

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // </editor-fold>
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel3 = new javax.swing.JPanel();
        panelThongTin = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtMaNV = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTenNV = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnSUa = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        txtDienThoai = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rbNam = new javax.swing.JRadioButton();
        rbNu = new javax.swing.JRadioButton();
        cboChucVu = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        txtCCCD = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtDiaChi = new javax.swing.JTextField();
        txtNgaySinh = new com.toedter.calendar.JDateChooser();
        btnEport = new javax.swing.JButton();
        btnImport = new javax.swing.JButton();
        btnMoWebCame = new javax.swing.JButton();
        pnWebCame = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtTim = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        tabs = new javax.swing.JTabbedPane();
        panelDangLam = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbNhanVien = new javax.swing.JTable();
        btnNhoMax = new javax.swing.JButton();
        btnNho = new javax.swing.JButton();
        lbTrang = new javax.swing.JLabel();
        lbLon = new javax.swing.JButton();
        lbLonMax = new javax.swing.JButton();
        lbSoTrang = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nhân viên", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        panelThongTin.setBackground(new java.awt.Color(255, 255, 255));
        panelThongTin.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thiết lập thông tin nhân viên", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Mã nhân viên:");

        txtMaNV.setEditable(false);
        txtMaNV.setEnabled(false);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Tên nhân viên:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("SDT:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Email:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Ngày sinh:");

        btnThem.setBackground(new java.awt.Color(51, 204, 255));
        btnThem.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSUa.setBackground(new java.awt.Color(51, 204, 255));
        btnSUa.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSUa.setText("Sửa");
        btnSUa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSUaActionPerformed(evt);
            }
        });

        btnMoi.setBackground(new java.awt.Color(51, 204, 255));
        btnMoi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMoi.setText("Mới");
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Giới tính:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Chức vụ");

        buttonGroup1.add(rbNam);
        rbNam.setSelected(true);
        rbNam.setText("Nam");

        buttonGroup1.add(rbNu);
        rbNu.setText("Nữ");

        cboChucVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(rbNam)
                        .addGap(34, 34, 34)
                        .addComponent(rbNu, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cboChucVu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(rbNam)
                    .addComponent(rbNu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cboChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("CCCD:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Địa chỉ:");

        txtNgaySinh.setDateFormatString("dd-MM-yyyy");

        btnEport.setBackground(new java.awt.Color(51, 204, 255));
        btnEport.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEport.setText("Export");
        btnEport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEportActionPerformed(evt);
            }
        });

        btnImport.setBackground(new java.awt.Color(51, 204, 255));
        btnImport.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnImport.setText("Import");
        btnImport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportActionPerformed(evt);
            }
        });

        btnMoWebCame.setBackground(new java.awt.Color(51, 204, 255));
        btnMoWebCame.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMoWebCame.setText("Quét CCCD");
        btnMoWebCame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoWebCameActionPerformed(evt);
            }
        });

        pnWebCame.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout panelThongTinLayout = new javax.swing.GroupLayout(panelThongTin);
        panelThongTin.setLayout(panelThongTinLayout);
        panelThongTinLayout.setHorizontalGroup(
            panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelThongTinLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(28, 28, 28)
                .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelThongTinLayout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(108, 108, 108)
                        .addComponent(btnThem)
                        .addGap(12, 12, 12)
                        .addComponent(btnSUa)
                        .addGap(18, 18, 18)
                        .addComponent(btnMoi)
                        .addGap(18, 18, 18)
                        .addComponent(btnEport)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnImport)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnMoWebCame, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(panelThongTinLayout.createSequentialGroup()
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(69, 69, 69)
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7))
                            .addGap(37, 37, 37)
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(panelThongTinLayout.createSequentialGroup()
                            .addComponent(txtCCCD, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel8)
                                .addComponent(jLabel5))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelThongTinLayout.setVerticalGroup(
            panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelThongTinLayout.createSequentialGroup()
                .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelThongTinLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)))
                    .addGroup(panelThongTinLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(txtDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelThongTinLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1))
                    .addGroup(panelThongTinLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtCCCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel8)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelThongTinLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThem)
                            .addComponent(btnSUa)
                            .addComponent(btnMoi)
                            .addGroup(panelThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnEport)
                                .addComponent(btnImport)
                                .addComponent(btnMoWebCame, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tìm kiếm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        txtTim.setText("Tìm kiếm theo mã , tên ,chức vụ , ngày sinh , giới tính, điện thoại , email, địa chỉ ");
        txtTim.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTimFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTimFocusLost(evt);
            }
        });
        txtTim.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimMouseClicked(evt);
            }
        });
        txtTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimActionPerformed(evt);
            }
        });
        txtTim.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKeyReleased(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Tim kiem");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(269, 269, 269)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(16, 16, 16))
        );

        tabs.setBackground(new java.awt.Color(255, 255, 255));
        tabs.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        panelDangLam.setBackground(new java.awt.Color(255, 255, 255));

        tbNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã NV", "Tên NV", "Chức vụ", "Ngày sinh", "Giới tính", "Điện thoại", "Email", "Địa chỉ", "Trạng thái"
            }
        ));
        tbNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbNhanVienMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tbNhanVienMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbNhanVien);

        btnNhoMax.setText("<<");
        btnNhoMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhoMaxActionPerformed(evt);
            }
        });

        btnNho.setText("<");
        btnNho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhoActionPerformed(evt);
            }
        });

        lbTrang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbTrang.setText("jLabel13");

        lbLon.setText(">");
        lbLon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lbLonActionPerformed(evt);
            }
        });

        lbLonMax.setText(">>");
        lbLonMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lbLonMaxActionPerformed(evt);
            }
        });

        lbSoTrang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbSoTrang.setText("jLabel14");

        javax.swing.GroupLayout panelDangLamLayout = new javax.swing.GroupLayout(panelDangLam);
        panelDangLam.setLayout(panelDangLamLayout);
        panelDangLamLayout.setHorizontalGroup(
            panelDangLamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1151, Short.MAX_VALUE)
            .addGroup(panelDangLamLayout.createSequentialGroup()
                .addGap(424, 424, 424)
                .addComponent(btnNhoMax)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNho)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbTrang)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbLon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbLonMax)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbSoTrang)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelDangLamLayout.setVerticalGroup(
            panelDangLamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDangLamLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDangLamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNhoMax)
                    .addComponent(btnNho)
                    .addComponent(lbTrang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbLon)
                    .addComponent(lbLonMax)
                    .addComponent(lbSoTrang))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        tabs.addTab("Danh sách nhân viên", panelDangLam);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tabs)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelThongTin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelThongTin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tabs, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelThongTin.getAccessibleContext().setAccessibleName("");
        jPanel1.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents
public void TaoBarCodeChoCCCD() {
        String code = txtCCCD.getText();

        String ten = txtTenNV.getText();
        if (code.isEmpty()) {
            // Nếu ô trống, thông báo lỗi cho người dùng
            //JOptionPane.showMessageDialog(this, "Vui lòng nhập thông tin Barcode");
        } else {
            // Nếu không trống, tạo ảnh barcode và hiển thị nó trên nhãn
            byte[] result = ZXingHelper.getBarCodeImage(code, 300, 200);
            // Lưu ảnh barcode vào máy tính với tên file là mã barcode
            saveImage(result, ten + ".png");
        }
    }

    private void saveImage(byte[] imageData, String fileName) {
        try {
            // Đường dẫn nơi bạn muốn lưu ảnh
            String directoryPath = "C:\\Users\\ADMIN\\Desktop\\Da1_TheHaBits_Nhom5_master_BanChinh\\DA1_Nhom5_TheHabitShop_SoureTree\\src\\com\\raven\\icon\\TaiQRDuc";
            String filePath = directoryPath + fileName;

            // Tạo đối tượng File để đại diện cho file mà ảnh sẽ được ghi vào
            File file = new File(filePath);

            // Sử dụng ImageIO để ghi dữ liệu ảnh vào file
            ImageIO.write(ImageIO.read(new ByteArrayInputStream(imageData)), "png", file);

            // Hiển thị thông báo thành công
            //  JOptionPane.showMessageDialog(this, "Lưu ảnh barcode thành công tại: " + filePath);
        } catch (IOException e) {
            // Xử lý lỗi: Hiển thị thông báo lỗi cho người dùng và in lỗi ra console
            //JOptionPane.showMessageDialog(this, "Lỗi khi lưu ảnh barcode: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void insert() {
        if (test()) {
            NhanVienRespose nv = this.getFormNhanVien();
            List<NhanVienRespose> list = new ArrayList();
            int choice = JOptionPane.showConfirmDialog(this, "Bạn có muốn thêm không?", "Thông báo ", JOptionPane.YES_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                try {
                    boolean addKH = daoNV.inertNV(getFormNhanVien());

                    this.countDb();
                    fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
                    if (count % 5 == 0) {
                        soTrang = count / 5;
                    } else {
                        soTrang = count / 5 + 1;
                    }

                    lbSoTrang.setText("1/" + soTrang);
                    lbTrang.setText("1");

                    TaoBarCodeChoCCCD();

                    if (addKH) {

                        JOptionPane.showMessageDialog(this, "Thêm thành công");
                        SendMail();
                        clearFormNhanVien();
                    } else {
                        JOptionPane.showMessageDialog(this, "Thêm thất bại");
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Bạn chọn thoát");
            }

        }
    }

    public boolean SendMail() {
        //NhanVienRespose nv = getFormNhanVien();
        final String username = "nguyenminhduc662004@gmail.com";
        final String password = "ahmm dwgv wfqp uaef";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS

        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            // Tạo đối tượng MimeMessage
            Message mimeMessage = new MimeMessage(session);
            mimeMessage.setFrom(new InternetAddress("nguyenminhduc662004@gmail.com"));
            mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(txtEmail.getText()));
            mimeMessage.setSubject("Tạo tài khoản thành công của CỬA HÀNG BÁN GIÀY Sneaker");
            mimeMessage.setText("Đây là tên tài khoản và mật khẩu của bạn: " + txtTenNV.getText()
                    + "\n"
                    + "\n"
                    + "Tài Khoản: "
                    + txtMaNV.getText()
                    + "\n" + "Mật khẩu: " + nv.getMatKhau()
                    + "\n" + "\n" + "\n" + "Sau khi nhận mật khẩu vui lòng đăng nhập và đổi mật khẩu theo ý của mình!!!!!"
            );

            // Gửi email
            Transport.send(mimeMessage);
            JOptionPane.showMessageDialog(this, "Gửi mail thành công ");
        } catch (MessagingException ex) {
            JOptionPane.showMessageDialog(this, "Failed to send email: " + ex.getMessage());
        }
        return true;
    }

    public void XuatFile2() {
        try {
            List<NhanVien> listNV = daoNV.selectAll();

            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.createSheet("nhanvien");

            // Header Row
            XSSFRow headerRow = sheet.createRow(0);
            String[] headers = {"STT", "MaNV", "TenNV", "Chucvu", "NgaySinh", "GioiTinh", "SDT", "Email", "DiaChi", "TrangThai"};
            for (int i = 0; i < headers.length; i++) {
                XSSFCell headerCell = headerRow.createCell(i, CellType.STRING);
                headerCell.setCellValue(headers[i]);
            }

            // Data Rows
            for (int i = 0; i < listNV.size(); i++) {
                XSSFRow dataRow = sheet.createRow(i + 1);

                dataRow.createCell(0, CellType.NUMERIC).setCellValue(i + 1);
                dataRow.createCell(1, CellType.STRING).setCellValue(listNV.get(i).getMaNV());
                dataRow.createCell(2, CellType.STRING).setCellValue(listNV.get(i).getTenNV());
                dataRow.createCell(3, CellType.STRING).setCellValue(listNV.get(i).getId_chucVu().getTenCV());
                dataRow.createCell(4, CellType.STRING).setCellValue(formatDate(listNV.get(i).getNgaySinh()));
                dataRow.createCell(5, CellType.STRING).setCellValue(listNV.get(i).getGioiTinh());
                dataRow.createCell(6, CellType.STRING).setCellValue(listNV.get(i).getSDT());
                dataRow.createCell(7, CellType.STRING).setCellValue(listNV.get(i).getEmail());
                dataRow.createCell(8, CellType.STRING).setCellValue(listNV.get(i).getDiaChi());
                dataRow.createCell(9, CellType.STRING).setCellValue(listNV.get(i).getTrangThai());
            }

            File f = new File("D:\\Excel\\NhanVien.xlsx");
            try (FileOutputStream fis = new FileOutputStream(f)) {
                workbook.write(fis);
                JOptionPane.showMessageDialog(this, "Export thành công");
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi mở file: " + ex.getMessage());
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi ghi file: " + ex.getMessage());
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi lưu file: " + ex.getMessage());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi lấy danh sách nhân viên: " + ex.getMessage());
        }
    }

    private String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        return sdf.format(date);
    }
    private void btnEportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEportActionPerformed
        // TODO add your handling code here:
        XuatFile2();
        // XuatFlie();
    }//GEN-LAST:event_btnEportActionPerformed
    public void XuatFlie() {
        try {
            fillTableNVPhanTrang(daoNV.selectAll());
            // Hiển thị hộp thoại để chọn nơi lưu tệp Excel
            JFileChooser jFileChooser = new JFileChooser();
            jFileChooser.showSaveDialog(this);
            File saveFile = jFileChooser.getSelectedFile();

            if (saveFile != null) {
                // Đảm bảo tệp có đuôi .xlsx
                if (!saveFile.getName().toLowerCase().endsWith(".xlsx")) {
                    saveFile = new File(saveFile.toString() + ".xlsx");
                }

                // Tạo workbook và sheet
                Workbook workbook = new XSSFWorkbook();
                Sheet sheet = workbook.createSheet("nhanvien");

                // Tạo hàng đầu tiên (header) từ tên cột của bảng
                Row headerRow = sheet.createRow(0);
                for (int i = 0; i < tbNhanVien.getColumnCount(); i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(tbNhanVien.getColumnName(i));
                }

                // Sao chép dữ liệu từ bảng vào Excel
                for (int j = 0; j < tbNhanVien.getRowCount(); j++) {
                    Row excelRow = sheet.createRow(j + 1);
                    for (int k = 0; k < tbNhanVien.getColumnCount(); k++) {
                        Cell cell = excelRow.createCell(k);
                        Object cellValue = tbNhanVien.getValueAt(j, k);
                        if (cellValue != null) {
                            cell.setCellValue(cellValue.toString());
                        }
                    }
                }

                // Lưu workbook vào tệp
                try (FileOutputStream out = new FileOutputStream(saveFile)) {
                    workbook.write(out);
                }

                // Đóng workbook
                workbook.close();
            }
            JOptionPane.showMessageDialog(this, "Xuất file thành công");
        } catch (Exception e) {
            e.printStackTrace();
            // Xử lý ngoại lệ theo ý bạn (hiển thị thông báo, ghi log, v.v.)
        }

    }

    private void tbNhanVienMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbNhanVienMousePressed


    }//GEN-LAST:event_tbNhanVienMousePressed

    private void txtTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimActionPerformed

    private void txtTimMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_txtTimMouseClicked

    private void txtTimKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKeyReleased
        // TODO add your handling code here:
        String searchString = txtTim.getText();
        serch(searchString);

    }//GEN-LAST:event_txtTimKeyReleased

    private void tbNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbNhanVienMouseClicked
        // TODO add your handling code here:

        index = tbNhanVien.getSelectedRow();
        int columnIndex = tbNhanVien.getSelectedColumn();
        this.setFromNV(index);

        if (columnIndex == 9) {  // Cột thứ 9 vị trí (0-based) là cột có chỉ số 8

            mouclickThayDoiTrangThai();
        }
    }//GEN-LAST:event_tbNhanVienMouseClicked
    public void ImportSenMail() {
        try {
            // TODO: Mã để import dữ liệu từ tệp Excel
            // Ví dụ: Sử dụng Apache POI để đọc Excel

            // Chọn tệp Excel để import
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Chọn tệp Excel");
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Excel files", "xlsx"));

            int userSelection = fileChooser.showOpenDialog(this);
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                importDataFromExcel(selectedFile);
            }
        } catch (Exception e) {
            // Xử lý lỗi nếu có
            JOptionPane.showMessageDialog(this, "Lỗi khi import dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void btnImportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportActionPerformed
        // TODO add your handling code here:
        Import();
    }//GEN-LAST:event_btnImportActionPerformed

    private void txtTimFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimFocusGained
        // TODO add your handling code here:
        if (txtTim.getText().equals("Tìm kiếm theo mã , tên ,chức vụ , ngày sinh , giới tính, điện thoại , email, địa chỉ ")) {
            txtTim.setText(null);
            txtTim.requestFocus();
            RemovePleacehoderStyle(txtTim);
        }
    }//GEN-LAST:event_txtTimFocusGained

    private void txtTimFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimFocusLost
        // TODO add your handling code here:
        if (txtTim.getText().length() == 0) {
            AddPleacehoderStyle(txtTim);
            txtTim.setText("Tìm kiếm theo mã , tên ,chức vụ , ngày sinh , giới tính, điện thoại , email, địa chỉ");
        }
    }//GEN-LAST:event_txtTimFocusLost

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        // TODO add your handling code here:
        clearFormNhanVien();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void btnSUaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSUaActionPerformed
        // TODO add your handling code here:
        index = tbNhanVien.getSelectedRow();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Mời chọn bản ghi !");
        } else {

            int chon = JOptionPane.showConfirmDialog(this, "Bạn có muốn sửa hay không Yes/No ?", "Thông báo", JOptionPane.YES_NO_OPTION);
            if (chon == JOptionPane.YES_OPTION) {
                NhanVienRespose kh = this.getFormNhanVien();
                String ma = txtMaNV.getText();

                if (daoNV.updateNhanVien(kh, ma) > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa thành công");
                    this.fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
                    clearFormNhanVien();
                } else {
                    JOptionPane.showMessageDialog(this, "Sửa that bai");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Bạn chọn thoát");
            }

        }
    }//GEN-LAST:event_btnSUaActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        insert();
    }//GEN-LAST:event_btnThemActionPerformed


    private void btnMoWebCameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoWebCameActionPerformed
        // TODO add your handling code here:    
        openWebcam();
    }//GEN-LAST:event_btnMoWebCameActionPerformed

    private void btnNhoMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhoMaxActionPerformed
        // TODO add your handling code here:
        trang = 1;
        fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
        lbTrang.setText("1");
        lbSoTrang.setText("1/" + soTrang);
    }//GEN-LAST:event_btnNhoMaxActionPerformed

    private void btnNhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhoActionPerformed
        // TODO add your handling code here:
        if (trang > 1) {
            trang--;
            fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
            lbTrang.setText("" + trang);
            lbSoTrang.setText(trang + "/" + soTrang);
        }
    }//GEN-LAST:event_btnNhoActionPerformed

    private void lbLonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lbLonActionPerformed
        // TODO add your handling code here:
        if (trang < soTrang) {
            trang++;
            fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
            lbTrang.setText("" + trang);
            lbSoTrang.setText(trang + "/" + soTrang);
        }
    }//GEN-LAST:event_lbLonActionPerformed

    private void lbLonMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lbLonMaxActionPerformed
        // TODO add your handling code here:
        trang = soTrang;
        fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
        lbTrang.setText("" + soTrang);
        lbSoTrang.setText(soTrang + "/" + soTrang);
    }//GEN-LAST:event_lbLonMaxActionPerformed
    void xoa() {
        String ma = tbNhanVien.getValueAt(index, 1).toString();
        if (daoNV.delete(ma) > 0) {
            JOptionPane.showMessageDialog(this, "Xóa thành  công  ");
            this.fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
        } else {
            JOptionPane.showMessageDialog(this, "Xoa  thất bại  ");
        }
    }

    public void serch(String str) {
        model = (DefaultTableModel) this.tbNhanVien.getModel();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
        tbNhanVien.setRowSorter(trs);

        // Check if the search string is empty or null
        if (str == null || str.trim().isEmpty()) {
            tbNhanVien.setRowSorter(null);  // Remove the row filter
        } else {
            RowFilter<DefaultTableModel, Object> rowFilter = new RowFilter<DefaultTableModel, Object>() {
                @Override
                public boolean include(Entry<? extends DefaultTableModel, ? extends Object> entry) {
                    for (int i = entry.getValueCount() - 1; i >= 0; i--) {
                        Object value = entry.getValue(i);
                        if (value != null) {
                            String text = value.toString().toLowerCase();
                            if (text.equalsIgnoreCase(str.toLowerCase())) {
                                return true;
                            }
                        }
                    }
                    return false;
                }
            };

            trs.setRowFilter(rowFilter);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEport;
    private javax.swing.JButton btnImport;
    private javax.swing.JButton btnMoWebCame;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnNho;
    private javax.swing.JButton btnNhoMax;
    private javax.swing.JButton btnSUa;
    private javax.swing.JButton btnThem;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cboChucVu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton lbLon;
    private javax.swing.JButton lbLonMax;
    private javax.swing.JLabel lbSoTrang;
    private javax.swing.JLabel lbTrang;
    private javax.swing.JPanel panelDangLam;
    private javax.swing.JPanel panelThongTin;
    private javax.swing.JPanel pnWebCame;
    private javax.swing.JRadioButton rbNam;
    private javax.swing.JRadioButton rbNu;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JTable tbNhanVien;
    private javax.swing.JTextField txtCCCD;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtDienThoai;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtMaNV;
    private com.toedter.calendar.JDateChooser txtNgaySinh;
    private javax.swing.JTextField txtTenNV;
    private javax.swing.JTextField txtTim;
    // End of variables declaration//GEN-END:variables
 JFrame webcamFrame = new JFrame("Webcam Viewer");

    private void openWebcam() {
        initWebcam();

        if (webcam != null) {
            panel = new WebcamPanel(webcam);
            panel.setFPSDisplayed(true);
            panel.setImageSizeDisplayed(true);

            webcamFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            webcamFrame.add(panel);
            webcamFrame.pack();
            webcamFrame.setLocationRelativeTo(null);
            webcamFrame.setVisible(true);
        }
    }

    private void initWebcam() {
        Dimension size = WebcamResolution.QVGA.getSize();
        webcam = Webcam.getWebcams().get(0); //0 is default webcam
        webcam.setViewSize(size);
        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(true);
        pnWebCame.add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 200));
        executor.execute(this);
//        Dimension size = WebcamResolution.QVGA.getSize();
//        webcam = Webcam.getWebcams().get(0);
//        webcam.setViewSize(size);
//
//        panel = new WebcamPanel(webcam);
//        panel.setPreferredSize(size);
//
//        executor.execute(this);
    }

    @Override
    public void run() {
        do {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            Result result = null;
            BufferedImage image = null;

            if (webcam.isOpen()) {
                image = webcam.getImage();
                if (image == null) {
                    continue;
                }

                LuminanceSource source = new BufferedImageLuminanceSource(image);
                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                try {
                    result = new MultiFormatReader().decode(bitmap);
                } catch (NotFoundException e) {
                    // No result...
                }

                if (result != null) {
                    String cccd = result.getText();
                    txtCCCD.setText(cccd);
                    closeWebcamFrame();
                    // Kết nối đến cơ sở dữ liệu và truy vấn thông tin nhân viên
                    try (Connection con = DBConnect.getConnection()) {
                        String query = "SELECT NhanVien.ma, ten, ChucVu.tencv, ngaysinh, gioitinh, cccd, sdt, email, diachi "
                                + "FROM NhanVien JOIN ChucVu ON NhanVien.id_chucvu = ChucVu.id WHERE NhanVien.cccd = ?";
                        try (PreparedStatement ps = con.prepareStatement(query)) {
                            ps.setString(1, cccd);
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next()) {
                                    // Lấy thông tin từ cơ sở dữ liệu
                                    String ma = rs.getString("ma");
                                    String ten = rs.getString("ten");
                                    String chucVu = rs.getString("tencv");
                                    Date ngaySinh = rs.getDate("ngaysinh");
                                    boolean gioiTinh = rs.getBoolean("gioitinh");
                                    String sdt = rs.getString("sdt");
                                    String email = rs.getString("email");
                                    String diaChi = rs.getString("diachi");

                                    // Cập nhật thông tin nhân viên lên các trường dữ liệu
                                    SwingUtilities.invokeLater(() -> {
                                        txtMaNV.setText(ma);
                                        txtTenNV.setText(ten);
                                        txtDienThoai.setText(sdt);
                                        txtDiaChi.setText(diaChi);
                                        txtNgaySinh.setDate(ngaySinh);
                                        txtEmail.setText(email);

                                        cboChucVu.setSelectedItem(chucVu);

                                        // Chọn giới tính
                                        if (gioiTinh) {
                                            rbNam.setSelected(true);
                                        } else {
                                            rbNu.setSelected(true);
                                        }
                                    });

                                } else {
                                    System.out.println("Không tìm thấy nhân viên với CCCD: " + cccd);
                                }
                            }
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    } finally {
                        // Đóng webcam sau khi xử lý
                        webcam.close();

                    }
                }
            }
        } while (true);
    }

    private void closeWebcamFrame() {
        if (webcamFrame != null) {
            webcamFrame.dispose();
        }
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, "My Thread");
        t.setDaemon(true);
        return t;
    }

    public static String generateRandomCode(int length) {
        Random random = new Random();
        StringBuilder codeBuilder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int randomNumber = random.nextInt(10); // Sinh số ngẫu nhiên từ 0 đến 9
            codeBuilder.append(randomNumber);
        }

        return codeBuilder.toString();
    }
//Tải mẫu and Import

    private void importDataFromExcel(File file) throws Exception {
        try (FileInputStream fis = new FileInputStream(file); Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0); // Lấy sheet đầu tiên
            Iterator<Row> iterator = sheet.iterator();

            while (iterator.hasNext()) {
                Row currentRow = iterator.next();
                Iterator<Cell> cellIterator = currentRow.iterator();

                // TODO: Xử lý dữ liệu từ mỗi ô trong tệp Excel
                String email = cellIterator.next().toString(); // Giả sử cột đầu tiên chứa địa chỉ email
                String subject = cellIterator.next().toString(); // Giả sử cột thứ hai chứa tiêu đề email
                String message = cellIterator.next().toString(); // Giả sử cột thứ ba chứa nội dung email

                // Gửi email
                sendEmail(email, subject, message);
            }
        }
    }

    private void sendEmail(String to, String subject, String body) {
        // TODO: Cấu hình thông tin máy chủ email, người gửi, mật khẩu, v.v.
        String host = "smtp.gmail.com";
        String username = "nguyenminhduc662004@gmail.com";
        String password = "ahmm dwgv wfqp uaef";
        int port = 587;

        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            // Tạo đối tượng MimeMessage
            Message message = new MimeMessage(session);

            // Đặt thông tin người gửi và người nhận
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            message.setText(body);

            // Gửi email
            Transport.send(message);

            // Hiển thị thông báo gửi email thành công (có thể sử dụng JOptionPane)
            System.out.println("Email sent successfully to: " + to);
        } catch (MessagingException e) {
            // Xử lý lỗi nếu có
            e.printStackTrace();
            // Hiển thị thông báo lỗi (có thể sử dụng JOptionPane)
            System.err.println("Error sending email to: " + to + " - " + e.getMessage());
        }
    }
// Tỉm kiếm anả

    public void AddPleacehoderStyle(JTextField textField) {
        Font font = textField.getFont();
        font = font.deriveFont(Font.ITALIC);
        textField.setFont(font);
        textField.setForeground(Color.gray);
    }

    public void RemovePleacehoderStyle(JTextField textField) {
        Font font = textField.getFont();
        font = font.deriveFont(Font.PLAIN);
        textField.setFont(font);
        textField.setForeground(Color.black);
    }

    //Import moi 
    private static DefaultTableModel importFromExcel(String filePath) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheetAt(0);

        // Kiểm tra xem Sheet có ít nhất một dòng và dòng tiêu đề không là null
        if (sheet.getLastRowNum() < 1 || sheet.getRow(0) == null) {
            throw new IOException("Sheet không chứa dòng tiêu đề.");
        }

        // Tạo mô hình mới
        DefaultTableModel model = new DefaultTableModel();

        // Đọc dòng tiêu đề và thêm các cột vào mô hình
        Row headerRow = sheet.getRow(0);
        int columnCount = headerRow.getLastCellNum();
        for (int column = 0; column < columnCount; column++) {
            Cell cell = headerRow.getCell(column);
            String columnName = cell.getStringCellValue();
            model.addColumn(columnName);
        }

        // Đọc dữ liệu từ các hàng trong sheet và thêm vào mô hình
        int rowCount = sheet.getLastRowNum() + 1;
        for (int row = 1; row < rowCount; row++) {
            Row sheetRow = sheet.getRow(row);
            Object[] rowData = new Object[columnCount];
            for (int column = 0; column < columnCount; column++) {
                Cell cell = sheetRow.getCell(column);
                Object cellValue = null;
                if (cell != null) {
                    switch (cell.getCellType()) {
                        case STRING:
                            cellValue = cell.getStringCellValue();
                            break;
                        case NUMERIC:
                            if (DateUtil.isCellDateFormatted(cell)) {
                                cellValue = cell.getDateCellValue();
                            } else {
                                cellValue = cell.getNumericCellValue();
                            }
                            break;
                        case BOOLEAN:
                            cellValue = cell.getBooleanCellValue();
                            break;
                        case FORMULA:
                            break;
                        default:
                            break;
                    }
                }
                rowData[column] = cellValue;
            }
            model.addRow(rowData);
            // sendEmailImport(rowData);
        }

        // Đóng workbook và FileInputStream
        workbook.close();
        fis.close();

        return model;
    }

    private static void sendEmailImport(Object[] rowData) {
        String recipientEmail = rowData[7].toString();
        String subject = "Thông báo quan trọng";
        String body = String.format("Hello, %s!<br> Good Morning ", rowData[2]);

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("nguyenminhduc662004@gmail.com", "ahmm dwgv wfqp uaef");
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("nguyenminhduc662004@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setContent(body, "text/html");  // Set content type to HTML

            Transport.send(message);

            System.out.println("Đã gửi email đến: " + recipientEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            System.err.println("Không thể gửi email đến: " + recipientEmail);
        }
    }

    public void Import() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();

            // Gọi phương thức import dữ liệu từ file Excel vào mô hình
            try {
                DefaultTableModel model = importFromExcel(filePath);
                tbNhanVien.setModel(model);

                JOptionPane.showMessageDialog(null, "Import thành công", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Lỗi from Excel: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
//Muosclick thay đổi trạng thái 

    public void mouclickThayDoiTrangThai() {
        int index = tbNhanVien.getSelectedRow();
        String trangThai = tbNhanVien.getValueAt(index, 9).toString();
        String ma = tbNhanVien.getValueAt(index, 1).toString();
        // Kiểm tra xem trạng thái hiện tại có phải là "Active" không
        if ("Đang làm".equals(trangThai)) {
            int choice = JOptionPane.showConfirmDialog(null, "Bạn có muốn thay đổi trạng thái của nhân viên thành 'Nghỉ việc' không?", "Xác nhận Thay Đổi Trạng Thái", JOptionPane.YES_NO_OPTION);

            if (choice == JOptionPane.YES_OPTION) {
                // Lấy thông tin nhân viên từ giao diện người dùng
                NhanVienRespose nv = this.getFormNhanVien();

                // Cập nhật trạng thái trong cơ sở dữ liệu
                int rowsAffected = daoNV.updateTrangThai(nv, 0, ma);

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa thành công");
                    // Cập nhật lại JTable nếu cần
                    this.fillTableNVPhanTrang(daoNV.selectAllPhanTrang(trang));
                } else {
                    JOptionPane.showMessageDialog(this, "Sửa thất bại");
                }
            }
        } else {
            // Thông báo cho người dùng biết rằng trạng thái không thể thay đổi
            JOptionPane.showMessageDialog(null, "Nhân viên được chọn không ở trạng thái 'Đang làm'.", "Không Cho Phép Thay Đổi Trạng Thái", JOptionPane.WARNING_MESSAGE);
        }

    }
}
