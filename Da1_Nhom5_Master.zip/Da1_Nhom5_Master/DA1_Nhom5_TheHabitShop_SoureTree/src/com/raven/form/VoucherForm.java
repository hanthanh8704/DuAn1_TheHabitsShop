/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.raven.form;

import com.raven.classinterface.TableActionEvent;
import com.raven.classmodel.HoaDon;
import com.raven.classmodel.NhanVien;
import com.raven.classmodel.TableActionCellEditor;
import com.raven.classmodel.TableActionCellRender;
import com.raven.reponsitory.DBConnect;
import com.raven.service.GetIdSPCTService11;
import com.raven.service.VoucherService;
import java.awt.Color;
import java.awt.Font;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import java.text.DecimalFormat;
import java.util.Calendar;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;
import java.time.LocalDateTime;
import com.raven.classinterface.GenMaTuDong_Ninh;
import com.raven.classmodel.Voucher_KhachHang;
import com.raven.service.voucher_KhachHangService;
import java.time.LocalDate;
import java.time.ZoneId;

/**
 *
 * @author ADMIN
 */
public class VoucherForm extends javax.swing.JPanel {

    private VoucherService service = new VoucherService();
    private DefaultTableModel model = new DefaultTableModel();
    List<com.raven.classmodel.Voucher> list = service.getAll();
    private GetIdSPCTService11 getid = new GetIdSPCTService11();
    private voucher_KhachHangService servicevckh = new voucher_KhachHangService();
    public int index = -1;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;
    long count, soTrang, trang = 1;

    /**
     * Creates new form Voucher
     */
    public static void main(String[] args) {
        JFrame jf = new JFrame();
        VoucherForm spview = new VoucherForm();
        jf.add(spview);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.pack();
        jf.setVisible(true);
        jf.setLocationRelativeTo(null);
    }

    public VoucherForm() {
        initComponents();
//        UpdateStatusThread thread = new UpdateStatusThread();
//        thread.start();

        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onDelete(int row) {
                if (tblVoicherAll.isEditing()) {
                    tblVoicherAll.getCellEditor().stopCellEditing();
                }
                updateTrangThaiKT(row);
            }
        };
        tblVoicherAll.getColumnModel().getColumn(9).setCellRenderer(new TableActionCellRender());
        tblVoicherAll.getColumnModel().getColumn(9).setCellEditor(new TableActionCellEditor(event));
        this.AddPleacehoderStyle(txtTimKiem);
        cboLoaiGiamGia.removeAllItems();
        String menu[] = {"VND"};
        for (String item : menu) {
            cboLoaiGiamGia.addItem(item);
            cbbLoaiTim.addItem(item);
        }
        String menus[] = {"Sắp diễn ra", "Đang diễn ra", "Đã kết thúc"};
        for (String item : menus) {
            cbbTrangThai.addItem(item);
        }
        this.fillTable(service.getAll());
        countDB();
        if (count % 5 == 0) {
            soTrang = count / 5;
        } else {
            soTrang = count / 5 + 1;
        }
        this.fillTable(service.loadData(1));
        lblSoTrang.setText("1/" + soTrang);
        lblTrang.setText("1");

        Thread t1 = new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
//                    updateTrangThai();
                        fillTable(service.loadData(1));
                        sleep(60000);
                        lblSoTrang.setText("1/" + soTrang);
                        lblTrang.setText("1");
                        cbbLoaiTim.setSelectedIndex(0);
                        cbbTrangThai.setSelectedIndex(0);
                        txtNgayDau.setDate(null);
                        txtNgayCuoi.setDate(null);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        };
        t1.start();

    }

    void updateTrangThaiKT(int row) {
        int chose = JOptionPane.showConfirmDialog(this, "Bạn có muốn sửa phiếu giảm giá không?", "Phiếu giảm giá", JOptionPane.YES_NO_OPTION);
        if (chose == JOptionPane.YES_OPTION) {
            row = tblVoicherAll.getSelectedRow();
            com.raven.classmodel.Voucher nv = this.readForm2();
            String ma = tblVoicherAll.getValueAt((row), 1).toString();
            if (service.update2(nv, ma) > 0) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                this.fillTable(service.loadData(1));
            }
            this.fillTable(service.loadData(1));
        }
    }

//    public void updateTrangThai() {
//        index = tblVoicherAll.getSelectedRow();
//        com.raven.classmodel.Voucher nv = this.readForm1();
//        for (index = 0; index < tblVoicherAll.getRowCount(); index++) {
//            String ma = tblVoicherAll.getValueAt((index), 1).toString();
//
//            if (service.update1(nv, ma) > 0) {
////                JOptionPane.showMessageDialog(this, "Sửa thành công");
//                this.fillTable(service.loadData(1));
//            }
//        }
//        this.fillTable(service.loadData(1));
//        this.fillTable2(service.loadData1(1, 1));
//        this.fillTable2(service.loadData1(1, 2));
//        this.fillTable3(service.loadData1(1, 3));
//
//    }
    DecimalFormat df = new DecimalFormat("###.###");

    public void fillTable(List<com.raven.classmodel.Voucher> list) {
        model = (DefaultTableModel) tblVoicherAll.getModel();
        model.setRowCount(0);
        int stt = (int) ((trang - 1) * 5 + 1);
        for (com.raven.classmodel.Voucher vc : list) {
            String trangthai = "";
            int trangThai = vc.getTrangThai();

            java.util.Date StartDate = vc.getNgayBatDau();
            java.util.Date EndDate = vc.getNgayKetThuc();
            java.util.Date ngayTao = new Date();
            LocalDateTime ngaytao = LocalDateTime.now();
            String id_Voucher = getid.getIDVoucher(vc.getMa());
            if (ngayTao.getTime() < StartDate.getTime()) {
                service.updateTT1(vc, vc.getMa());
                servicevckh.updateTT1(vc, id_Voucher);
            } else if (ngayTao.getTime() >= StartDate.getTime() && ngayTao.getTime() < EndDate.getTime()) {
                service.updateTT2(vc, vc.getMa());
                servicevckh.updateTT2(vc, id_Voucher);
            } else if (ngayTao.getTime() >= EndDate.getTime()) {
                service.updateTT3(vc, vc.getMa());
                servicevckh.updateTT3(vc, id_Voucher);
            }
            if (trangThai == 1) {
                trangthai = "Sắp diễn ra";
            } else if (trangThai == 2) {
                trangthai = "Đang diễn ra";
            } else if (trangThai == 3) {
                trangthai = "Đã kết thúc";
            }
            Object[] toDaTaRow = new Object[]{stt++, vc.getMa(), vc.getTen(), df.format(vc.getGiatrimax()), vc.getLoaiGiamGia(),
                df.format(vc.getGiatrimin()), vc.getNgayBatDau(), vc.getNgayKetThuc(), trangthai, vc.getNgayTao()};

            model.addRow(toDaTaRow);
        }
    }

    private void showData(int index) {
        com.raven.classmodel.Voucher vc = service.getAll().get(index);

        txtTen.setText(vc.getTen());
        txtMa.setText(vc.getMa());
        cboLoaiGiamGia.setSelectedItem(vc.getLoaiGiamGia());
        txtMucGiam.setText(String.valueOf(df.format(vc.getGiatrimax())));
        txtGiaTriMin.setText(String.valueOf(df.format(vc.getGiatrimin())));
        txtStartDate.setDate(vc.getNgayBatDau());
        txtEndDate.setDate(vc.getNgayKetThuc());
    }

    private SimpleDateFormat formats = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aaa");

    private com.raven.classmodel.Voucher readForm() {
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();
        SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aaa");
        System.out.println("Ngày giờ hiện tại sau khi định dạng là " + sdf3.format(date));
        NhanVien nv = new NhanVien();
        HoaDon hd = new HoaDon();
        GenMaTuDong_Ninh genMa = new GenMaTuDong_Ninh() {
            @Override
            public String maTuDong() {
                int gen = new Random().nextInt(1000000);
                return "VC" + gen;
            }
        };
//        getid.(cbbMauSac.getSelectedItem() + "")
//        getid.getIDChatLieu(cbbChatLieu.getSelectedItem() + "")
        NhanVien nvv = new NhanVien();
        HoaDon hdd = new HoaDon();
        String nnv = null;
        String hhd = null;
        String ma = genMa.maTuDong();
        String ten = txtTen.getText();
        String loaigiam = cboLoaiGiamGia.getSelectedItem().toString();
        Double giamGia = Double.parseDouble(txtMucGiam.getText());
        BigDecimal mucGiamGia = BigDecimal.valueOf(giamGia);
        Double giatri = Double.parseDouble(txtGiaTriMin.getText());
        BigDecimal giatrimin = BigDecimal.valueOf(giatri);
        java.util.Date StartDate = txtStartDate.getDate();
        java.util.Date EndDate = txtEndDate.getDate();
        java.util.Date ngayTao = new Date();
        int trangthai = 1;

        if (ngayTao.getTime() >= StartDate.getTime() && ngayTao.getTime() < EndDate.getTime()) {
            trangthai = 2;
        } else if (ngayTao.getTime() >= EndDate.getTime()) {
            trangthai = 3;
        } else if (ngayTao.getTime() < StartDate.getTime()) {
            trangthai = 1;
        }
        return new com.raven.classmodel.Voucher(ma, ten, mucGiamGia, loaigiam, giatrimin, StartDate, EndDate, trangthai, ngayTao);
    }

    private com.raven.classmodel.Voucher readForm2() {
        java.util.Date StartDate = txtStartDate.getDate();
        java.util.Date EndDate = txtEndDate.getDate();
        java.util.Date ngayTao = new Date();
        return new com.raven.classmodel.Voucher(ngayTao);
    }

    //c1
    private String date2String(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(date);
    }

    // Hàm chuyển đổi từ date về string
    private Date parseDate(String ngayThang) {
        // Đối tượng hỗ trợ đọc kiểu dữ liệu ngày tháng
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //String date = DateFormat.
        try {
            return sdf.parse(ngayThang);
        } catch (Exception e) {
            //Nếu lỗi trả về thời điểm hiện tại
            return new Date();
        }
    }

    public void countDB() {
        sql = "Select count(*) from Voucher";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getLong(1);
            }
            con.close();
            ps.close();
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel12 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblVoicherAll = new javax.swing.JTable();
        btnTrai = new javax.swing.JButton();
        btnPhai = new javax.swing.JButton();
        lblSoTrang = new javax.swing.JLabel();
        lblTrang = new javax.swing.JLabel();
        btnPhaiPhai = new javax.swing.JButton();
        btnTraiTrai = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtNgayDau = new com.toedter.calendar.JDateChooser();
        txtNgayCuoi = new com.toedter.calendar.JDateChooser();
        cbbLoaiTim = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        cbbTrangThai = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTen = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cboLoaiGiamGia = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        txtMucGiam = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        txtStartDate = new com.toedter.calendar.JDateChooser();
        txtEndDate = new com.toedter.calendar.JDateChooser();
        txtGiaTriMin = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(null, "QUẢN LÝ PHIẾU GIẢM GIÁ", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Phiếu Giảm Giá", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        tblVoicherAll.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã", "Tên", "Giá trị tối đa", "Loại giảm", "Giá trị tối thiểu", "Ngày bắt đầu", "Ngày kết thúc", "Trạng thái", "Hành động"
            }
        ));
        tblVoicherAll.setRowHeight(25);
        tblVoicherAll.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblVoicherAllMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblVoicherAll);
        if (tblVoicherAll.getColumnModel().getColumnCount() > 0) {
            tblVoicherAll.getColumnModel().getColumn(0).setMinWidth(40);
            tblVoicherAll.getColumnModel().getColumn(0).setMaxWidth(40);
            tblVoicherAll.getColumnModel().getColumn(1).setMinWidth(70);
            tblVoicherAll.getColumnModel().getColumn(1).setMaxWidth(70);
            tblVoicherAll.getColumnModel().getColumn(2).setMinWidth(140);
            tblVoicherAll.getColumnModel().getColumn(2).setMaxWidth(140);
            tblVoicherAll.getColumnModel().getColumn(3).setMinWidth(90);
            tblVoicherAll.getColumnModel().getColumn(3).setMaxWidth(90);
            tblVoicherAll.getColumnModel().getColumn(4).setMinWidth(70);
            tblVoicherAll.getColumnModel().getColumn(4).setMaxWidth(70);
            tblVoicherAll.getColumnModel().getColumn(8).setMinWidth(85);
            tblVoicherAll.getColumnModel().getColumn(8).setMaxWidth(85);
            tblVoicherAll.getColumnModel().getColumn(9).setMinWidth(75);
            tblVoicherAll.getColumnModel().getColumn(9).setMaxWidth(75);
        }

        btnTrai.setText("<");
        btnTrai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTraiActionPerformed(evt);
            }
        });

        btnPhai.setText(">");
        btnPhai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPhaiActionPerformed(evt);
            }
        });

        lblSoTrang.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSoTrang.setForeground(new java.awt.Color(255, 51, 0));
        lblSoTrang.setText("jLabel13");

        lblTrang.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTrang.setForeground(new java.awt.Color(255, 51, 0));
        lblTrang.setText("jLabel14");

        btnPhaiPhai.setText(">>");
        btnPhaiPhai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPhaiPhaiActionPerformed(evt);
            }
        });

        btnTraiTrai.setText("<<");
        btnTraiTrai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTraiTraiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1035, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnTraiTrai, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTrai, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTrang)
                .addGap(12, 12, 12)
                .addComponent(btnPhai, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPhaiPhai, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSoTrang, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTrai)
                    .addComponent(btnPhai)
                    .addComponent(lblSoTrang)
                    .addComponent(lblTrang)
                    .addComponent(btnPhaiPhai)
                    .addComponent(btnTraiTrai)))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Tìm kiếm:");

        txtTimKiem.setText("Tìm kiếm tất cả");
        txtTimKiem.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTimKiemFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTimKiemFocusLost(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Ngày Bắt Đầu");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Ngày Kết Thúc");

        txtNgayDau.setDateFormatString("yyyy-MM-dd hh:mm:ss aaa");

        txtNgayCuoi.setDateFormatString("yyyy-MM-dd hh:mm:ss aaa");

        cbbLoaiTim.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tất cả" }));
        cbbLoaiTim.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbLoaiTimItemStateChanged(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Loại Giảm");

        jButton1.setText("Lọc");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setText("Trạng Thái");

        cbbTrangThai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tất cả" }));
        cbbTrangThai.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbTrangThaiItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtTimKiem)
                    .addComponent(txtNgayDau, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel12)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(txtNgayCuoi, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(cbbLoaiTim, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(cbbTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9)
                            .addComponent(txtNgayDau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(cbbLoaiTim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)
                            .addComponent(cbbTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtNgayCuoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap(301, Short.MAX_VALUE))
            .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                    .addContainerGap(57, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(37, Short.MAX_VALUE)))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Mã Voucher: ");

        txtMa.setEditable(false);
        txtMa.setBackground(new java.awt.Color(229, 229, 229));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Tên Voucher:");

        txtTen.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Ngày Bắt Đầu:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Ngày Kết Thúc:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Loại Giảm Giá:");

        cboLoaiGiamGia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboLoaiGiamGia.setPreferredSize(new java.awt.Dimension(64, 26));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Giá Trị HĐ Được Giảm");

        btnAdd.setBackground(new java.awt.Color(102, 204, 255));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAdd.setText("Thêm");
        btnAdd.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnUpdate.setBackground(new java.awt.Color(102, 204, 255));
        btnUpdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdate.setText("Sửa");
        btnUpdate.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnReset.setBackground(new java.awt.Color(102, 204, 255));
        btnReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnReset.setText("Mới");
        btnReset.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        txtStartDate.setDateFormatString("yyyy-MM-dd hh:mm:ss aaa");
        txtStartDate.setMinimumSize(new java.awt.Dimension(64, 26));
        txtStartDate.setPreferredSize(new java.awt.Dimension(64, 26));

        txtEndDate.setDateFormatString("yyyy-MM-dd hh:mm:ss aaa");
        txtEndDate.setMinimumSize(new java.awt.Dimension(64, 26));
        txtEndDate.setPreferredSize(new java.awt.Dimension(64, 26));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Giá Trị HĐ Được Áp Dụng");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cboLoaiGiamGia, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtMucGiam, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtMa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(67, 67, 67)
                        .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(304, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(4, 4, 4))
                            .addComponent(jLabel5)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtEndDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtStartDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtGiaTriMin, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtMucGiam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(txtStartDate, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(txtEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(txtGiaTriMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboLoaiGiamGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 48, Short.MAX_VALUE)))
                .addGap(18, 21, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(59, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
Boolean vadidate() {
        if (txtTen.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên!");
            return false;
        }
        if (txtMucGiam.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập giá trị tối đa!");
            return false;
        }
        try {
            Double mucGiam = Double.parseDouble(txtMucGiam.getText().trim());
            BigDecimal mucGiamGia = BigDecimal.valueOf(mucGiam);
            if (cboLoaiGiamGia.getSelectedItem().equals("%")) {
                if (mucGiam >= 100 || mucGiam <= 0) {
                    JOptionPane.showMessageDialog(this, ""
                            + "Giá trị tối đa chỉ được giảm 100% trở xuống và lớn hơn 0!");
                    return false;
                }
            }
            if (cboLoaiGiamGia.getSelectedItem().equals("VND")) {
                if (mucGiam <= 0) {
                    JOptionPane.showMessageDialog(this, "Giá trị tối đa chỉ được lớn hơn 0!");
                    return false;
                }
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Giá trị tối đa sai định dạng!");
            return false;
        }
        if (txtMucGiam.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập giá trị tối thiểu!");
            return false;
        }
        try {
            Double toithieu = Double.parseDouble(txtGiaTriMin.getText().trim());
            BigDecimal giatritoithieu = BigDecimal.valueOf(toithieu);
            if (toithieu <= 0) {
                JOptionPane.showMessageDialog(this, "Giá trị tối thiểu phải lớn hơn 0!");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Giá trị tối thiểu sai định dạng!");
            return false;

        }
        try {
            Double toithieu = Double.parseDouble(txtGiaTriMin.getText().trim());
            BigDecimal giatritoithieu = BigDecimal.valueOf(toithieu);

            Double mucGiam = Double.parseDouble(txtMucGiam.getText().trim());
            BigDecimal mucGiamGia = BigDecimal.valueOf(mucGiam);
            if(toithieu < mucGiam){
                JOptionPane.showMessageDialog(this, "Giá trị được giảm không được lớn hơn giá trị hóa đơn được áp dụng");
                return false;
            }
        } catch (Exception e) {
            return false;            
        }
        if (txtStartDate.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập ngày bắt đầu!");
            return false;
        }
        if (txtEndDate.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập ngày kết thúc!");
            return false;
        }
        Date startDateUtil = txtStartDate.getDate();
        Date endDateUtil = txtEndDate.getDate();
// Chuyển đổi từ java.util.Date sang LocalDate
        LocalDate startDate = startDateUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate endDate = endDateUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate currentDate = LocalDate.now();

        if (startDate.isBefore(currentDate)) {
            JOptionPane.showMessageDialog(this, "Ngày bắt đầu phải lớn hơn ngày hiện tại!");
            return false;
        } else if (endDate.isBefore(startDate)) {
            JOptionPane.showMessageDialog(this, "Ngày kết thúc phải lớn hơn ngày bắt đầu!");
            return false;
        }
        return true;
    }
    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // TODO add your handling code here:
        if (this.vadidate()) {
            int chose = JOptionPane.showConfirmDialog(this, "Bạn có muốn thêm phiếu giảm giá không?", "Phiếu giảm giá", JOptionPane.YES_NO_OPTION);
            if (chose == JOptionPane.YES_OPTION) {
//                com.raven.classmodel.Voucher nv = this.readForm();
                com.raven.classmodel.Voucher nv;
                Voucher_KhachHang vckh = new Voucher_KhachHang();
//                NhanVien nv = new NhanVien();
                HoaDon hd = new HoaDon();
                GenMaTuDong_Ninh genMa = new GenMaTuDong_Ninh() {
                    @Override
                    public String maTuDong() {
                        int gen = new Random().nextInt(1000000);
                        return "VC" + gen;
                    }
                };
//        getid.(cbbMauSac.getSelectedItem() + "")
//        getid.getIDChatLieu(cbbChatLieu.getSelectedItem() + "")
                NhanVien nvv = new NhanVien();
                HoaDon hdd = new HoaDon();
                String nnv = null;
                String hhd = null;
                String ma = genMa.maTuDong();
                String ten = txtTen.getText();
                String loaigiam = cboLoaiGiamGia.getSelectedItem().toString();
                Double giamGia = Double.parseDouble(txtMucGiam.getText());
                BigDecimal mucGiamGia = BigDecimal.valueOf(giamGia);
                Double giatri = Double.parseDouble(txtGiaTriMin.getText());
                BigDecimal giatrimin = BigDecimal.valueOf(giatri);
                java.util.Date StartDate = txtStartDate.getDate();
                java.util.Date EndDate = txtEndDate.getDate();
                java.util.Date ngayTao = new Date();
                int trangthai = 1;

                if (ngayTao.getTime() >= StartDate.getTime() && ngayTao.getTime() < EndDate.getTime()) {
                    trangthai = 2;
                } else if (ngayTao.getTime() >= EndDate.getTime()) {
                    trangthai = 3;
                } else if (ngayTao.getTime() < StartDate.getTime()) {
                    trangthai = 1;
                }
                nv = new com.raven.classmodel.Voucher(ma, ten, mucGiamGia, loaigiam, giatrimin, StartDate, EndDate, trangthai, ngayTao);

                index = tblVoicherAll.getSelectedRow();
//                int soLuong = Integer.parseInt(txtSoLuong.getText());
                if (service.getID(nv.getMa()) != null || service.getName(nv.getTen()) != null) {
                    JOptionPane.showMessageDialog(this, "Mã hoặc Tên đã tồn tại đã tồn tại!");
                } else {
                    if (service.insert(nv) > 0) {
                        JOptionPane.showMessageDialog(this, "Thêm thành công");
                        this.Reset();

                    } else {
                        JOptionPane.showMessageDialog(this, "thêm that bai");
                    }

                    GenMaTuDong_Ninh genMa1 = new GenMaTuDong_Ninh() {
                        @Override
                        public String maTuDong() {
                            int gen = new Random().nextInt(1000000);
                            return "VCKH" + gen;
                        }
                    };
                    String ma1 = genMa1.maTuDong();
//                    String mavc = this.readForm().getMa();
                    String id_Voucher = getid.getIDVoucher(ma);
                    int xoatt = 0;
                    String id_NguoiTao = null;
                    String id_KhachHang = null;
                    vckh = new Voucher_KhachHang(ma1, trangthai, id_Voucher, id_KhachHang, id_NguoiTao, ngayTao, xoatt);
                    servicevckh.insert(vckh);
                }
            }
            countDB();
            this.fillTable(service.loadData(1));
            if (count % 5 == 0) {
                soTrang = count / 5;
            } else {
                soTrang = count / 5 + 1;
            }
            lblTrang.setText("" + trang);
            lblSoTrang.setText(trang + "/" + soTrang);
//                lblSoTrang.setText("1/" + soTrang);
//                lblTrang.setText("1");

        }


    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một phiếu giảm giá để sửa");
            return;
        }
        if (this.vadidate()) {
            int chose = JOptionPane.showConfirmDialog(this, "Bạn có muốn sửa phiếu giảm giá không?", "Phiếu giảm giá", JOptionPane.YES_NO_OPTION);
            if (chose == JOptionPane.YES_OPTION) {
                com.raven.classmodel.Voucher nv = this.readForm();
                Voucher_KhachHang vckh = new Voucher_KhachHang();
                index = tblVoicherAll.getSelectedRow();

                String ma = tblVoicherAll.getValueAt((index), 1).toString();
                String id = getid.getIDVoucher(ma);
                GenMaTuDong_Ninh genMa = new GenMaTuDong_Ninh() {
                    @Override
                    public String maTuDong() {
                        int gen = new Random().nextInt(1000000);
                        return "VCKH" + gen;
                    }
                };
                String masv = genMa.maTuDong();
                String mavc = tblVoicherAll.getValueAt(index, 1).toString();
                String id_Voucher = getid.getIDVoucher(mavc);
                java.util.Date ngayTao = new Date();
                int trangthai = 1;
                int xoatt = 0;
                String id_NguoiTao = null;
                String id_KhachHang = null;
                vckh.setMa(masv);
                vckh.setTrangthai(trangthai);
                vckh.setId_Voucher(id_Voucher);
                vckh.setId_KhachHang(id_KhachHang);
                vckh.setId_NguoiTao(id_NguoiTao);
                vckh.setNgayTao(ngayTao);
                vckh.setXoaTT(xoatt);
                vckh = new Voucher_KhachHang(ma, trangthai, id_Voucher, id_KhachHang, id_NguoiTao, ngayTao, xoatt);
                if (service.update(nv, ma) > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa thành công");
                    this.fillTable(service.loadData(1));
                    lblSoTrang.setText("1/" + soTrang);
                    lblTrang.setText("1");
                } else {
                    JOptionPane.showMessageDialog(this, "Sửa thất bại");
                }
                servicevckh.update(vckh, id);
            }

        }

    }//GEN-LAST:event_btnUpdateActionPerformed
    private void Reset() {
        txtTen.setText("");
        txtMa.setText("");
        txtMucGiam.setText("");
        cboLoaiGiamGia.setSelectedIndex(0);
        txtStartDate.setDate(null);
        txtEndDate.setDate(null);
        cbbLoaiTim.setSelectedIndex(0);
        cbbTrangThai.setSelectedIndex(0);
        txtNgayDau.setDate(null);
        txtNgayCuoi.setDate(null);
        txtGiaTriMin.setText("");
        this.fillTable(service.loadData(1));
    }
    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        // TODO add your handling code here:
        this.Reset();
        lblSoTrang.setText("1/" + soTrang);
        lblTrang.setText("1");
    }//GEN-LAST:event_btnResetActionPerformed
    void search(String str) {
        DefaultTableModel model = (DefaultTableModel) tblVoicherAll.getModel();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
        tblVoicherAll.setRowSorter(trs);
        String searchText = txtTimKiem.getText().trim();
        trs.setRowFilter(RowFilter.regexFilter(str));
    }

    public void AddPleacehoderStyle(JTextField textField) {
        Font font = textField.getFont();
        font = font.deriveFont(Font.ITALIC);
        textField.setFont(font);
        textField.setForeground(Color.gray);
    }

    public void RemovePleacehoderStyle(JTextField textField) {
        Font font = textField.getFont();
        font = font.deriveFont(Font.PLAIN);
        textField.setFont(font);
        textField.setForeground(Color.black);
    }
    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        // TODO add your handling code here:
        String trs = txtTimKiem.getText();
        search(trs);
        lblSoTrang.setText("1/" + "1");
        lblTrang.setText("1");

        cbbLoaiTim.setSelectedIndex(0);
        cbbTrangThai.setSelectedIndex(0);
        txtNgayDau.setDate(null);
        txtNgayCuoi.setDate(null);
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void txtTimKiemFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiemFocusGained
        // TODO add your handling code here:
        if (txtTimKiem.getText().equals("Tìm kiếm tất cả")) {
            txtTimKiem.setText(null);
            txtTimKiem.requestFocus();
            RemovePleacehoderStyle(txtTimKiem);
        }
    }//GEN-LAST:event_txtTimKiemFocusGained

    private void txtTimKiemFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTimKiemFocusLost
        // TODO add your handling code here:                                  
        if (txtTimKiem.getText().length() == 0) {
            AddPleacehoderStyle(txtTimKiem);
            txtTimKiem.setText("Tìm kiếm tất cả");

        }
    }//GEN-LAST:event_txtTimKiemFocusLost

    private void cbbLoaiTimItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbLoaiTimItemStateChanged
        // TODO add your handling code here:
        String ten;
        if (cbbLoaiTim.getSelectedItem().equals("Tất cả")) {
            ten = null;
            fillTable(service.loadData(1));
            lblSoTrang.setText("1/" + soTrang);
            lblTrang.setText("1");
        } else {
            ten = cbbLoaiTim.getSelectedItem().toString();
//            ten = "%" + ten + "%";
        }
        if (service.findcbb(ten).size() >= 0) {//co sinh vien tim duoc
            cbbTrangThai.setSelectedIndex(0);
            txtNgayDau.setDate(null);
            txtNgayCuoi.setDate(null);
            this.fillTable(service.findcbb(ten));
            lblSoTrang.setText("1/" + "1");
            lblTrang.setText("1");
        }
    }//GEN-LAST:event_cbbLoaiTimItemStateChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        java.util.Date startDate = txtNgayDau.getDate();
        java.util.Date endDate = txtNgayCuoi.getDate();

        if (txtNgayDau.getDateFormatString().toString().trim().isEmpty() || txtNgayCuoi.getDateFormatString().toString().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ ngày và giờ");
            return;
        } else {
//        cbbTrangThai.setSelectedIndex(0);
//        cbbLoaiTim.setSelectedIndex(0);
            List<com.raven.classmodel.Voucher> list = service.find(txtNgayDau, txtNgayCuoi);
            fillTable(service.find(txtNgayDau, txtNgayCuoi));
            lblSoTrang.setText("1/" + "1");
            lblTrang.setText("1");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnTraiTraiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTraiTraiActionPerformed
        // TODO add your handling code here:
        trang = 1;
        this.fillTable(service.loadData(trang));
        lblTrang.setText("" + trang);
        lblSoTrang.setText("1" + "/" + soTrang);
        cbbLoaiTim.setSelectedIndex(0);
        cbbTrangThai.setSelectedIndex(0);
        txtNgayDau.setDate(null);
        txtNgayCuoi.setDate(null);
    }//GEN-LAST:event_btnTraiTraiActionPerformed

    private void btnPhaiPhaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPhaiPhaiActionPerformed
        // TODO add your handling code here:
        trang = soTrang;
        this.fillTable(service.loadData(trang));
        lblTrang.setText("" + trang);
        lblSoTrang.setText(soTrang + "/" + soTrang);
        cbbLoaiTim.setSelectedIndex(0);
        cbbTrangThai.setSelectedIndex(0);
        txtNgayDau.setDate(null);
        txtNgayCuoi.setDate(null);
    }//GEN-LAST:event_btnPhaiPhaiActionPerformed

    private void btnPhaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPhaiActionPerformed
        // TODO add your handling code here:
        if (trang < soTrang) {
            trang++;
            this.fillTable(service.loadData(trang));
            lblTrang.setText("" + trang);
            lblSoTrang.setText(trang + "/" + soTrang);
            cbbLoaiTim.setSelectedIndex(0);
            cbbTrangThai.setSelectedIndex(0);
            txtNgayDau.setDate(null);
            txtNgayCuoi.setDate(null);
        }
    }//GEN-LAST:event_btnPhaiActionPerformed

    private void btnTraiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTraiActionPerformed
        // TODO add your handling code here:
        if (trang > 1) {
            trang--;
            this.fillTable(service.loadData(trang));
            lblTrang.setText("" + trang);
            lblSoTrang.setText(trang + "/" + soTrang);
            cbbLoaiTim.setSelectedIndex(0);
            cbbTrangThai.setSelectedIndex(0);
            txtNgayDau.setDate(null);
            txtNgayCuoi.setDate(null);
        }
    }//GEN-LAST:event_btnTraiActionPerformed

    private void tblVoicherAllMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblVoicherAllMouseClicked
        // TODO add your handling code here:
        index = tblVoicherAll.getSelectedRow();
        this.showData(index);
    }//GEN-LAST:event_tblVoicherAllMouseClicked

    private void cbbTrangThaiItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbTrangThaiItemStateChanged
        // TODO add your handling code here:

        int trangthai;
        if (cbbTrangThai.getSelectedItem().equals("Tất cả")) {
            trangthai = 0;
            fillTable(service.loadData(1));
            lblSoTrang.setText("1/" + soTrang);
            lblTrang.setText("1");
        } else {
            if (cbbTrangThai.getSelectedItem().equals("Sắp diễn ra")) {
                trangthai = 1;
                this.fillTable(service.findcbbtt(trangthai));
            } else if (cbbTrangThai.getSelectedItem().equals("Đang diễn ra")) {
                trangthai = 2;
                this.fillTable(service.findcbbtt(trangthai));
            } else if (cbbTrangThai.getSelectedItem().equals("Đã kết thúc")) {
                trangthai = 3;
                this.fillTable(service.findcbbtt(trangthai));
            }
            lblSoTrang.setText("1/" + "1");
            lblTrang.setText("1");
            cbbLoaiTim.setSelectedIndex(0);
            txtNgayDau.setDate(null);
            txtNgayCuoi.setDate(null);
        }
    }//GEN-LAST:event_cbbTrangThaiItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnPhai;
    private javax.swing.JButton btnPhaiPhai;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnTrai;
    private javax.swing.JButton btnTraiTrai;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbbLoaiTim;
    private javax.swing.JComboBox<String> cbbTrangThai;
    private javax.swing.JComboBox<String> cboLoaiGiamGia;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblSoTrang;
    private javax.swing.JLabel lblTrang;
    public javax.swing.JTable tblVoicherAll;
    private com.toedter.calendar.JDateChooser txtEndDate;
    private javax.swing.JTextField txtGiaTriMin;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtMucGiam;
    private com.toedter.calendar.JDateChooser txtNgayCuoi;
    private com.toedter.calendar.JDateChooser txtNgayDau;
    private com.toedter.calendar.JDateChooser txtStartDate;
    private javax.swing.JTextField txtTen;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
