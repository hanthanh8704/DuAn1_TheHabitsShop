/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.reponsitory;

import com.raven.classmodel.ChatLieu;
import com.raven.classmodel.HoaDon;
import com.raven.classmodel.HoaDonChiTiet;
import com.raven.classmodel.KhachHang;
import com.raven.classmodel.KichCo;
import com.raven.classmodel.MauSac;
import com.raven.classmodel.NhanHieu;
import com.raven.classmodel.NhanVien;
import com.raven.classmodel.SanPham;
import com.raven.classmodel.SanPhamChiTiet;
import com.raven.classmodel.Voucher;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author ADMIN
 */
public class BanHangReponsitory {

    public List<SanPhamChiTiet> getAllSP() {
        String sql = """
                     SELECT SanPhamChiTiet.ma,SanPham.ten,soluong,SanPhamChiTiet.giaa,MauSac.ten AS 'TenMS',ChatLieu.ten AS 'TenCL',KichCo.ten AS 'TenKC',NhanHieu.ten AS 'TenNH', SanPhamChiTiet.ngaytao AS 'NgayTao' FROM SanPhamChiTiet
                     JOIN SanPham ON SanPham.id = SanPhamChiTiet.id_sanpham
                     JOIN MauSac ON MauSac.id = SanPhamChiTiet.id_mausac
                      JOIN ChatLieu ON ChatLieu.id = SanPhamChiTiet.id_chatlieu
                          JOIN KichCo ON KichCo.id = SanPhamChiTiet.id_kichco
                            JOIN NhanHieu ON NhanHieu.id = SanPhamChiTiet.id_nhanhieu
                     	   ORDER BY NgayTao DESC
                     """;
        try (Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            ArrayList<SanPhamChiTiet> list = new ArrayList<>();
            while (rs.next()) {
                String ma = rs.getString(1);
                String tensp = rs.getString(2);
                Integer soluong = rs.getInt(3);
                BigDecimal gia = rs.getBigDecimal(4);
                String tenms = rs.getString(5);
                String tencl = rs.getString(6);
                String tenkc = rs.getString(7);
                String tennh = rs.getString(8);

                SanPham sp = new SanPham();
                sp.setTenSP(tensp);

                MauSac ms = new MauSac();
                ms.setTenMauSac(tenms);

                ChatLieu cl = new ChatLieu();
                cl.setTen(tencl);

                KichCo kc = new KichCo();
                kc.setTenKichCo(tenkc);

                NhanHieu nh = new NhanHieu();
                nh.setTen(tennh);

                SanPhamChiTiet spct = new SanPhamChiTiet();
                spct.setTenSanPham(sp);
                spct.setTenMauSac(ms);
                spct.setTenChatlieu(cl);
                spct.setTenNhanHieu(nh);
                spct.setTenKichCo(kc);
                spct.setMa(ma);
                spct.setSoLuong(soluong);
                spct.setGiaBan1(gia);
                list.add(spct);
            }
            return list;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

//    public List<HoaDon> getAllHD() {
//        List<HoaDon> listHD = new ArrayList<>();
//        String sql = """
//                        SELECT HoaDon.ma,HoaDon.ngaytaohoadon, NhanVien.ten AS 'tenNV', KhachHang.ten AS 'tenKH',
//                        HoaDon.trangthai FROM HoaDon JOIN HoaDonChiTiet ON HoaDonChiTiet.id_hoadon = HoaDon.id
//                        JOIN NhanVien ON NhanVien.id = HoaDon.id_nhanvien
//                        JOIN KhachHang ON KhachHang.id = HoaDon.id_khachhang WHERE HoaDon.trangthai = 0
//                     """;
//
//        try {
//            conn = DBConnect.getConnection();
//            ps = conn.prepareStatement(sql);
//            rs = ps.executeQuery();
//            while (rs.next()) {
//                //UUID id = UUID.fromString(rs.getString(1));
//                String mahd = rs.getString("ma");
//                Date ngaytaohd = rs.getDate("ngaytaohoadon");
//                Integer tinhtrang = rs.getInt("trangthai");
//                String tennv = rs.getString("tenNV");
//                String tenkh = rs.getString("tenKH");
//
//                NhanVien nv = new NhanVien();
//                nv.setTenNV(tennv);
//                KhachHang kh = new KhachHang();
//                kh.setTenKH(tenkh);
//
//                HoaDon hoaDon = new HoaDon();
//                hoaDon.setMa(mahd);
//                hoaDon.setNgaytaohoadon(ngaytaohd);
//                hoaDon.setTinhTrang(tinhtrang);
//                hoaDon.setIdNhanVien(nv);
//                hoaDon.setIdKhachHang(kh);
//                listHD.add(hoaDon);
//            }
//            return listHD;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//    public int addHoaDon(HoaDon hd) {
//        String sql = """
//                 INSERT INTO [dbo].[HoaDon]
//                            ([ma]
//                            ,[trangthai]
//                            ,[id_nhanvien]
//                            ,[ngaytao]
//                           )
//                      VALUES
//                            (?,?,?,?,?)
//                 """;
//
//        int rowsInserted = 0;
//
//        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
//            ps.setObject(1, hd.getMa());
//            ps.setObject(2, hd.getTinhTrang());
//            ps.setObject(3, hd.getIdNhanVien1());
//            ps.setObject(4, hd.getNgayTao());
//
//            rowsInserted = ps.executeUpdate();
//        } catch (SQLException e) {
//
//            System.err.println("Lỗi khi thêm hóa đơn: " + e.getMessage());
//        }
//
//        return rowsInserted;
//    }
    public String getidNhanVien(String nhanVien) {
        String idMauSac = "";
        String sql = """
                 SELECT  id from NhanVien where ten = ?
                 """;
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, nhanVien);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                idMauSac = rs.getString(1);
            }
            return idMauSac;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public String getIdKhachHang(String khachHang) {
        String idKhachHang = "";
        String sql = """
                   SELECT id FROM KhachHang Where ten = ?
                   """;
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, khachHang);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                idKhachHang = rs.getString(1);
            }
            return idKhachHang;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<HoaDon> getAllHD() {
        List<HoaDon> listHD = new ArrayList<>();
        String sql = """
       SELECT
                                                                                                                                                            [HoaDon].[id],
                                                                                                                                                            [HoaDon].[ma],
                                                                                                                                                            [tennguoinhan],
                                                                                                                                                            [HoaDon].[diachi],
                                                                                                                                                            [ngayxacnhan],
                                                                                                                                                            [phivc],
                                                                                                                                                            [ngaytaohoadon],
                                                                                                                                                            [ngayvanchuyen],
                                                                                                                                                            [ngaynhanhang],
                                                                                                                                                            [ngaythanhtoan],
                                                                                                                                                            [tongtiencuahoadon],
                                                                                                                                                            [tongtiencuahoadonsaugiamgia],
                                                                                                                                                            [HoaDon].[trangthai],
                                                                                                                                                            [ghichu],
                                                                                                                                                            HoaDon.[id_khachhang],
                                                                                                                                                            [id_nhanvien],
                                                                                                                                                            [HoaDon].[id_nguoitao],
                                                                                                                                                            [HoaDon].[ngaytao],
                                                                                                                                                            [HoaDon].[xoa_trangthai],
                                                                                                                                                            NhanVien.ma AS 'MaNV'                                                         
                                                                                                                                                        FROM [dbo].[HoaDon]
                                                                                                                                                        LEFT JOIN NhanVien ON NhanVien.id = HoaDon.id_nhanvien
                                                                                                                                                        WHERE [HoaDon].trangthai = 0
                                                                                                      												  ORDER BY HoaDon.ngaytao desc
                    """;

        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                String mahd = rs.getString("ma");
                Timestamp ngaytaohd = rs.getTimestamp("ngaytao");
                Integer tinhtrang = rs.getInt("trangthai");
                // Integer soluong = rs.getInt("SoLuongSP");
                String manv = rs.getString("MaNV");

                NhanVien nv = new NhanVien();
                nv.setMaNV(mahd);

                HoaDon hoaDon = new HoaDon();
                hoaDon.setMa(mahd);
                hoaDon.setManhanvien(manv);
                //  hoaDon.setSoluongspct(soluong);
                hoaDon.setNgayTao(ngaytaohd);
                hoaDon.setTinhTrang(tinhtrang);
                listHD.add(hoaDon);
            }
            return listHD;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

//    public HoaDon selectTop1DESC(){
//        String sql = """
//                        select top 1 * from hoaDon order by HoaDon.id desc
//                     """;
//         try(Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareCall(sql)){
//            ResultSet rs=ps.executeQuery();
//             while (rs.next()) {                 
//                 
//             }
//    }
    public int themSPGioHang(HoaDonChiTiet hdct) {
        String sql = "{CALL themSPGioHang(?,?,?,?,?)}";
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            if (hdct != null) {
                ps.setObject(1, hdct.getMa());
                ps.setObject(2, hdct.getMahd());
                ps.setObject(3, hdct.getMaspct());
                ps.setObject(4, hdct.getId_nguoitaoString());
                ps.setObject(5, hdct.getSoLuong());
                return ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int check10truong() {
        int pendingCount = 0;
        String sql = "SELECT COUNT(*) AS pendingCount FROM HoaDon WHERE trangthai = 0";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                pendingCount = rs.getInt("pendingCount");
            }
        } catch (SQLException e) {
            // Xử lý exception ở đây, có thể thông báo lỗi hoặc ghi log
            e.printStackTrace();
        }
        return pendingCount;
    }

    public String selectIdHDByMaHD(String maHD) {
        String id = "";
        String sql = """
                     select id from HoaDon where ma = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, maHD);
            rs = ps.executeQuery();
            while (rs.next()) {
                id = rs.getString("id");

            }
            return id;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String selectIDSPCTByMaSPCT(String IDSPCT) {
        String id = "";
        String sql = """
                     select id from SanPhamChiTiet where ma = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, IDSPCT);
            rs = ps.executeQuery();
            while (rs.next()) {
                id = rs.getString("id");

            }
            return id;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // gio hang
    public List<HoaDonChiTiet> selectHDCTByMaHD(String mahdct) {
        List<HoaDonChiTiet> listHDCT = new ArrayList<>();
        String sql = """
       select SanPhamChiTiet.ma , SanPham.ten, KichCo.ten as 'TenKC' , MauSac.ten as'TenMS', ChatLieu.ten as 'TenCL',
                        	   HoaDonChiTiet.soluong, SanPhamChiTiet.giaa, HoaDonChiTiet.tongtiencuahdct from HoaDonChiTiet
                                                JOIN SanPhamChiTiet On SanPhamChiTiet.id = HoaDonChiTiet.id_spct
                                                JOIN HoaDon ON HoaDon.id = HoaDonChiTiet.id_hoadon
                                                JOIN SanPham ON SanPham.id = SanPhamChiTiet.id_sanpham
                        			JOIN KichCo ON KichCo.id = SanPhamChiTiet.id_kichco
                        			JOIN MauSac ON MauSac.id = SanPhamChiTiet.id_mausac
                        			JOIN ChatLieu ON ChatLieu.id = SanPhamChiTiet.id_chatlieu
                     WHERE HoaDon.ma = ? AND HoaDonChiTiet.xoa_trangthai = 0
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, mahdct);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDonChiTiet hdct = new HoaDonChiTiet();
                hdct.setMaspct(rs.getString("ma"));
                hdct.setTensp(rs.getString("ten"));
                hdct.setSoLuong(rs.getInt("soluong"));
                hdct.setGia_SPCT(rs.getBigDecimal("giaa"));
                hdct.setTongTienCuaHDCT(rs.getBigDecimal("tongtiencuahdct"));
                hdct.setTenmausac(rs.getString("TenMS"));
                hdct.setTenkichco(rs.getString("TenKC"));
                hdct.setTenchatlieu(rs.getString("TenCL"));
                listHDCT.add(hdct);
            }
            return listHDCT;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // huy hoa hoa don co hang
    public int huyHoaDon(String hd_id, String hdct_id, String spct_id) {
        String sql = """
                        {CALL huyHoaDonCoHang(?,?,?)}
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, hd_id);
            ps.setObject(2, hdct_id);
            ps.setObject(3, spct_id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // huy hoa dong khong co hang
    public int huyHoaDonKhongCoHang(String hd_id) {
        String sql = """
                        {CALL huyHoaDonKhongCoHang(?)}
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, hd_id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String selecIDHoaDonCTByMaHoaDonAndMaSanPhamCT(String id, String id_spct) {
        String idmahd = "";
        String sql = """
                     select id from HoaDonChiTiet where id_hoadon = ? AND id_spct = ? AND xoa_trangthai = 0
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, id);
            ps.setObject(2, id_spct);
            rs = ps.executeQuery();
            while (rs.next()) {
                idmahd = rs.getString("id");
            }
            System.out.println(id);
            System.out.println(idmahd);
            return idmahd;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int xoaHoaDonChiTiet(String mahdct, String maspct, String mahd) {
        String sql = """
                        {CALL xoaSanPhamGioHang(?,?,?)}
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, mahdct);
            ps.setObject(2, maspct);
            ps.setObject(3, mahd);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int suaHoaDonChiTiet(String mahdct, String maspct, String mahd,
            Integer soluongthaydoi) {
        String sql = """
                        {CALL suaSanPhamGioHang(?,?,?,?)}
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, mahdct);
            ps.setObject(2, maspct);
            ps.setObject(3, mahd);
            ps.setObject(4, soluongthaydoi);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int selectSoLuongByHoaDonChiTietID(String mahdct) {
        int soluong = 0;
        String sql = """
                        SELECT soluong FROM HoaDonChiTiet WHERE id = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, mahdct);
            rs = ps.executeQuery();
            while (rs.next()) {
                soluong = rs.getInt("soluong");
            }
            return soluong;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int selectSoLuongBySanPhamChiTiet(String id_spct, String id_hdct) {
        int soluong = 0;
        String sql = """
                        SELECT SUM(SanPhamChiTiet.soluong + HoaDonChiTiet.soluong) AS 'SoLuongSanPham' FROM SanPhamChiTiet JOIN
                        HoaDonChiTiet ON HoaDonChiTiet.id_spct = SanPhamChiTiet.id
                        WHERE id_spct = ?
                        AND HoaDonChiTiet.id = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, id_spct);
            ps.setObject(2, id_hdct);
            rs = ps.executeQuery();
            while (rs.next()) {
                soluong = rs.getInt("SoLuongSanPham");
            }
            return soluong;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // lay id khach hang tu bang khach hang
    public String selectKhachHangByIdKhachHang(String ma, String sdt) {
        String khachhang = "";
        String sql = """
                        SELECT id FROM KhachHang WHERE ma = ? AND sdt = ? 
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, ma);
            ps.setObject(2, sdt);
            rs = ps.executeQuery();
            while (rs.next()) {
                khachhang = rs.getString("id");

            }
            return khachhang;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // lay id_httt tu ten hinh thuc tt
    public String selectThanhToanByIdTenThanhToan(String ten_httt) {
        String khachhang = "";
        String sql = """
                        SELECT id FROM ThanhToan WHERE tenhinhthuc = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, ten_httt);
            rs = ps.executeQuery();
            while (rs.next()) {
                khachhang = rs.getString("id");

            }
            return khachhang;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String selectIdKhachHangByTen(String ma) {
        String khachhang = "";
        String sql = """
                        SELECT id FROM KhachHang WHERE ma = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, ma);
            rs = ps.executeQuery();
            while (rs.next()) {
                khachhang = rs.getString("id");

            }
            return khachhang;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int themHinhThucThanhToan(String mahd, BigDecimal tongtien,
            String makh, String id_thanhtoan,
            String id_httt,String magd) {
        String sql = "{CALL themHinhThucThanhToan(?,?,?,?,?,?)}";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, mahd);
            pstmt.setBigDecimal(2, tongtien);
            pstmt.setString(3, makh);
            pstmt.setString(4, id_thanhtoan);
            pstmt.setString(5, id_httt);
            pstmt.setString(6, magd);
            return pstmt.executeUpdate(); // Thay đổi tại đây
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public int selecSanPhamChiTietByID(String idspct) {
        int soluongsp = 0;
        String sql = """
                        SELECT soluong FROM SanPhamChiTiet WHERE id = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, idspct);
            rs = ps.executeQuery();
            while (rs.next()) {
                soluongsp = rs.getInt("soluong");

            }
            return soluongsp;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String selectKhachHangLeByMa(String ma, String ten) {
        String makhle = null;
        String sql = """
                        SELECT id FROM KhachHang WHERE ma = ? AND ten = ?
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, ma);
            ps.setObject(2, ten);
            rs = ps.executeQuery();
            while (rs.next()) {
                makhle = rs.getString("id");
            }
            return makhle;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // hàm này để tìm kiếm sản phẩm
    public List<SanPhamChiTiet> findTerSanPham(String thuoctinh) {
        String sql = """
                     SELECT SanPhamChiTiet.ma,SanPham.ten,soluong,SanPhamChiTiet.giaa,MauSac.ten AS 'TenMS',
                     ChatLieu.ten AS 'TenCL',KichCo.ten AS 'TenKC',NhanHieu.ten AS 'TenNH', SanPhamChiTiet.ngaytao AS 'NgayTao' FROM SanPhamChiTiet
                     JOIN SanPham ON SanPham.id = SanPhamChiTiet.id_sanpham
                     JOIN MauSac ON MauSac.id = SanPhamChiTiet.id_mausac
                      JOIN ChatLieu ON ChatLieu.id = SanPhamChiTiet.id_chatlieu
                      JOIN KichCo ON KichCo.id = SanPhamChiTiet.id_kichco
                            JOIN NhanHieu ON NhanHieu.id = SanPhamChiTiet.id_nhanhieu
                     	   WHERE SanPhamChiTiet.ma LIKE N'%' + ? + N'%' or MauSac.ten LIKE N'%' + ? + N'%' 
                     or ChatLieu.ten LIKE N'%' + ? + N'%' or NhanHieu.ten LIKE N'%' + ? + N'%' or KichCo.ten LIKE N'%' + ? + N'%'
                     """;
        try {
            ArrayList<SanPhamChiTiet> list = new ArrayList<>();
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, thuoctinh);
            ps.setObject(2, thuoctinh);
            ps.setObject(3, thuoctinh);
            ps.setObject(4, thuoctinh);
            ps.setObject(5, thuoctinh);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String ma = rs.getString("ma");
                String tensp = rs.getString("ten");
                int soluong = rs.getInt("soluong");
                BigDecimal gia = rs.getBigDecimal("giaa");
                String tenms = rs.getString("TenMS");
                String tencl = rs.getString("TenCL");
                String tenkc = rs.getString("TenKC");
                String tennh = rs.getString("TenNH");

                SanPham sp = new SanPham();
                sp.setTenSP(tensp);

                MauSac ms = new MauSac();
                ms.setTenMauSac(tenms);

                ChatLieu cl = new ChatLieu();
                cl.setTen(tencl);

                KichCo kc = new KichCo();
                kc.setTenKichCo(tenkc);

                NhanHieu nh = new NhanHieu();
                nh.setTen(tennh);

                SanPhamChiTiet spct = new SanPhamChiTiet();
                spct.setTenSanPham(sp);
                spct.setTenMauSac(ms);
                spct.setTenChatlieu(cl);
                spct.setTenNhanHieu(nh);
                spct.setTenKichCo(kc);
                spct.setMa(ma);
                spct.setSoLuong(soluong);
                spct.setGiaBan1(gia);
                list.add(spct);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<KhachHang> findTerKhachHang(String thuoctinh) {

        String sql = """
                            select ma , ten , gioitinh,ngaysinh,sdt,email,diachi from KhachHang
                     	  WHERE ten LIKE N'%' + ? + N'%' or gioitinh LIKE N'%' + ? + N'%'  or sdt LIKE N'%' + ? + N'%' or email LIKE N'%' + ? + N'%'
                     """;
        try {
            List<KhachHang> list = new ArrayList<>();
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, thuoctinh);
            ps.setObject(2, thuoctinh);
            ps.setObject(3, thuoctinh);
            ps.setObject(4, thuoctinh);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String ma = rs.getString("ma");
                String tenkh = rs.getString("ten");
                boolean gioitinh = rs.getBoolean("gioitinh");
                Date ngaysinh = rs.getDate("ngaysinh");
                String sdt = rs.getString("sdt");
                String email = rs.getString("email");
                String diachi = rs.getString("diachi");

                KhachHang kh = new KhachHang();
                kh.setMaKH(ma);
                kh.setTenKH(tenkh);
                kh.setGioiTinh(gioitinh);
                kh.setSdt(sdt);
                kh.setNgaySinh(ngaysinh);
                kh.setEmail(email);
                kh.setDiaChi(diachi);
                list.add(kh);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String selectIdVoucherByMaHD(String idvoucher) {
        String idvc = null;
        String sql = "SELECT id FROM Voucher WHERE ten = ? ";
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, idvoucher);
            rs = ps.executeQuery();
            while (rs.next()) {
                idvc = rs.getString("id");
            }
            return idvc;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Voucher> getAllVC() {
        String sql = """
                     Select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai FROM Voucher WHERE trangthai = 2 order by ngaytao desc 
                     """;
        List<Voucher> list = new ArrayList<>();
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2),
                        rs.getBigDecimal(3), rs.getString(4), rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Voucher> selectAllVoucherById(String id) {
        String sql = """
                     Select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau,
                     ngayketthuc, trangthai FROM Voucher WHERE trangthai = 2 and id = ? order by ngaytao desc 
                     """;
        List<Voucher> list = new ArrayList<>();
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1),
                        rs.getString(2), rs.getBigDecimal(3), rs.getString(4),
                        rs.getBigDecimal(5),
                        rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Voucher> selectVoucherDangDienRa() {
        String sql = """
                     Select id,ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai FROM Voucher WHERE trangthai = 2 order by ngaytao desc
                     """;
        List<Voucher> list = new ArrayList<>();
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Voucher vc = new Voucher();
                vc.setId(UUID.fromString(rs.getString("id")));
                vc.setMa(rs.getString("ma"));
                vc.setTen(rs.getString("ten"));
                vc.setGiatrimin(rs.getBigDecimal("giatrimin"));
                vc.setGiatrimax(rs.getBigDecimal("giatrimax"));
                vc.setLoaiGiamGia(rs.getString("loaigiamgia"));
                vc.setNgayBatDau(rs.getDate("ngaybatdau"));
                vc.setNgayBatDau(rs.getDate("ngayketthuc"));
                vc.setTrangThai(rs.getInt("trangthai"));
                list.add(vc);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // thanh toán không voucher
    public int thanhToanHoaDon(
            String maspct, String mahd, BigDecimal tongtien,
            String mahdct, String makh, String id_thanhtoan,
            String id_httt, BigDecimal tongtien_tienmat, BigDecimal tongtien_the,String ghichu
    ) throws SQLException {
        String query = "{CALL thanhToanHoaDon(?, ?, ?, ?, ?, ?, ?, ?,?,?)}";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, maspct);
            pstmt.setString(2, mahd);
            pstmt.setBigDecimal(3, tongtien);
            pstmt.setString(4, mahdct);
            pstmt.setString(5, makh);
            pstmt.setString(6, id_thanhtoan);
            pstmt.setString(7, id_httt);
            pstmt.setBigDecimal(8, tongtien_tienmat);
            pstmt.setBigDecimal(9, tongtien_the);
            pstmt.setString(10, ghichu);
            return pstmt.executeUpdate(); // Thay đổi tại đây
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }
    }

    // thanh toán có voucher
    public int thanhToanHoaDonVoucher(
            String maspct, String mahd, BigDecimal tongtien,
            String mahdct, String makh, String id_thanhtoan,
            String id_httt, BigDecimal tongtien_tienmat, BigDecimal tongtien_the,
            String id_voucher, String mavoucher_khachhang, BigDecimal tongtiencuahdsaugiamgia, String ghichu
    ) throws SQLException {
        String query = "{CALL thanhToanHoaDonVoucher(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)}";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, maspct);
            pstmt.setString(2, mahd);
            pstmt.setBigDecimal(3, tongtien);
            pstmt.setString(4, mahdct);
            pstmt.setString(5, makh);
            pstmt.setString(6, id_thanhtoan);
            pstmt.setString(7, id_httt);
            pstmt.setBigDecimal(8, tongtien_tienmat);
            pstmt.setBigDecimal(9, tongtien_the);
            pstmt.setString(10, id_voucher);
            pstmt.setString(11, mavoucher_khachhang);
            pstmt.setString(13, ghichu);
            pstmt.setBigDecimal(12, tongtiencuahdsaugiamgia);
            return pstmt.executeUpdate(); // Thay đổi tại đây
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }
    }

    // findter cbb màu sắc 
    public ArrayList<MauSac> getMauSac(String ma) {
        String sql = """
                          SELECT [id]
                                                          ,[ma]
                                                          ,[ten]
                                                          ,[id_nguoitao]
                                                          ,[ngaytao]
                                                      FROM [dbo].[MauSac]
                                                      WHERE [ma] = ?
                                                      ORDER BY [ngaytao] DESC;
                         """;
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(0, ma);
            ps.execute();
            ArrayList<MauSac> listMS = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp ngayTaoTimestamp = rs.getTimestamp("ngaytao");
                LocalDateTime ngayTao = ngayTaoTimestamp.toLocalDateTime();
                MauSac m = new MauSac(rs.getString("id"), rs.getString("ma"), rs.getString("ten"));
                listMS.add(m);
            }
            return listMS;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // findter cbb chất liệu 
    public ArrayList<ChatLieu> getChatLieu(String ma) {
        String sql = """
                         SELECT [id]
                               ,[ma]
                               ,[ten]
                               ,[id_nguoitao]
                               ,[ngaytao]
                           FROM [dbo].[ChatLieu]
                           WHERE [ma] = ?
                           ORDER BY [ngaytao] DESC;
                         """;
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            ps.execute();
            ArrayList<ChatLieu> listMS = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ChatLieu m = new ChatLieu(rs.getString("ma"), rs.getString("ten"));
                listMS.add(m);
            }
            return listMS;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // finter kích cỡ
    public ArrayList<KichCo> getKichCo(String ma) {
        String sql = """
                     SELECT [ma]
                           ,[ten]
                       FROM [dbo].[KichCo]
                      WHERE [ma] = ?
                      ORDER BY [ngaytao] DESC
                     """;
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, ma); // Set the parameter for filtering
            ResultSet rs = ps.executeQuery();
            ArrayList<KichCo> listKichCo = new ArrayList<>();
            while (rs.next()) {
                KichCo k = new KichCo(rs.getString("ma"), rs.getString("ten"));
                listKichCo.add(k);
            }
            return listKichCo;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<SanPhamChiTiet> locTheoCacTruongDacTrung(String tenMauSac, String tenKichCo, String tenChatLieu) {
        String sql = "SELECT SanPhamChiTiet.ma, SanPham.ten, soluong, SanPhamChiTiet.giaa, MauSac.ten AS 'TenMS', "
                + "ChatLieu.ten AS 'TenCL', KichCo.ten AS 'TenKC', NhanHieu.ten AS 'TenNH', SanPhamChiTiet.ngaytao AS 'NgayTao' "
                + "FROM SanPhamChiTiet "
                + "JOIN SanPham ON SanPham.id = SanPhamChiTiet.id_sanpham "
                + "JOIN MauSac ON MauSac.id = SanPhamChiTiet.id_mausac "
                + "JOIN ChatLieu ON ChatLieu.id = SanPhamChiTiet.id_chatlieu "
                + "JOIN KichCo ON KichCo.id = SanPhamChiTiet.id_kichco "
                + "JOIN NhanHieu ON NhanHieu.id = SanPhamChiTiet.id_nhanhieu "
                + "WHERE (MauSac.ten = ? OR ? IS NULL OR 1 = '') "
                + "AND (ChatLieu.ten = ? OR ? IS NULL OR 1 = '') "
                + "AND (KichCo.ten = ? OR ? IS NULL OR 1 = '') "
                + "ORDER BY SanPhamChiTiet.ngaytao DESC";

        try (Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tenMauSac);
            ps.setString(2, tenMauSac);
            ps.setString(3, tenChatLieu);
            ps.setString(4, tenChatLieu);
            ps.setString(5, tenKichCo);
            ps.setString(6, tenKichCo);

            try (ResultSet rs = ps.executeQuery()) {
                List<SanPhamChiTiet> list = new ArrayList<>();
                while (rs.next()) {
                    // Process ResultSet and populate SanPhamChiTiet objects
                    SanPhamChiTiet spct = new SanPhamChiTiet();
                    String maspct = rs.getString("ma");
                    String tensp = rs.getString("ten");
                    Integer soluong = rs.getInt("soluong");
                    BigDecimal gia = rs.getBigDecimal("giaa");
                    String tenms = rs.getString("TenMS");
                    String tencl = rs.getString("TenCL");
                    String tenkc = rs.getString("TenKC");
                    String tennh = rs.getString("TenNH");
                    Timestamp ngaytao = rs.getTimestamp("NgayTao");
                    SanPham sp = new SanPham();
                    sp.setTenSP(tensp);

                    MauSac ms = new MauSac();
                    ms.setTenMauSac(tenms);

                    ChatLieu cl = new ChatLieu();
                    cl.setTen(tencl);

                    KichCo kc = new KichCo();
                    kc.setTenKichCo(tenkc);

                    NhanHieu nh = new NhanHieu();
                    nh.setTen(tennh);

                    spct.setTenSanPham(sp);
                    spct.setTenMauSac(ms);
                    spct.setTenChatlieu(cl);
                    spct.setTenNhanHieu(nh);
                    spct.setTenKichCo(kc);
                    spct.setMa(maspct);
                    spct.setSoLuong(soluong);
                    spct.setGiaBan1(gia);
                    spct.setNgayTao(ngaytao);
                    list.add(spct);
                    list.add(spct);
                }
                return list;

            } catch (SQLException e) {
                e.printStackTrace();
                return Collections.emptyList(); // Return empty list on SQLException
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList(); // Return empty list on SQLException
        }
    }

//    // lọc theo các trường đặc trưng
//    public List<SanPhamChiTiet> locTheoCacTruongDacTrung(String tenMauSac, String tenKichCo, String tenChatLieu) {
//        String sql = """
//                                 SELECT SanPhamChiTiet.ma, SanPham.ten, soluong, SanPhamChiTiet.giaa, MauSac.ten AS 'TenMS', " +
//                                 "ChatLieu.ten AS 'TenCL', KichCo.ten AS 'TenKC', NhanHieu.ten AS 'TenNH', SanPhamChiTiet.ngaytao AS 'NgayTao' " +
//                                 "FROM SanPhamChiTiet " +
//                                 "JOIN SanPham ON SanPham.id = SanPhamChiTiet.id_sanpham " +
//                                 "JOIN MauSac ON MauSac.id = SanPhamChiTiet.id_mausac " +
//                                 "JOIN ChatLieu ON ChatLieu.id = SanPhamChiTiet.id_chatlieu " +
//                                 "JOIN KichCo ON KichCo.id = SanPhamChiTiet.id_kichco " +
//                                 "JOIN NhanHieu ON NhanHieu.id = SanPhamChiTiet.id_nhanhieu " +
//                                 "WHERE (MauSac.ten = ? OR ? IS NULL OR 1 = '') " +
//                                 "AND (ChatLieu.ten = ? OR ? IS NULL OR 1 = '') " +
//                                 "AND (KichCo.ten = ? OR ? IS NULL OR 1 = '') " +
//                                 "ORDER BY SanPhamChiTiet.ngaytao DESC
//                     """;
//        try (Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
//            ps.setString(1, tenMauSac);
//            ps.setString(2, tenMauSac);
//            ps.setString(3, tenChatLieu);
//            ps.setString(4, tenChatLieu);
//            ps.setString(5, tenKichCo);
//            ps.setString(6, tenKichCo);
//            List<SanPhamChiTiet> list = new ArrayList<>();
//            while (rs.next()) {
//                String maspct = rs.getString("ma");
//                String tensp = rs.getString("ten");
//                Integer soluong = rs.getInt("soluong");
//                BigDecimal gia = rs.getBigDecimal("giaa");
//                String tenms = rs.getString("TenMS");
//                String tencl = rs.getString("TenCL");
//                String tenkc = rs.getString("TenKC");
//                String tennh = rs.getString("TenNH");
//                Timestamp ngaytao = rs.getTimestamp("NgayTao");
//                SanPham sp = new SanPham();
//                sp.setTenSP(tensp);
//
//                MauSac ms = new MauSac();
//                ms.setTenMauSac(tenms);
//
//                ChatLieu cl = new ChatLieu();
//                cl.setTen(tencl);
//
//                KichCo kc = new KichCo();
//                kc.setTenKichCo(tenkc);
//
//                NhanHieu nh = new NhanHieu();
//                nh.setTen(tennh);
//
//                SanPhamChiTiet spct = new SanPhamChiTiet();
//                spct.setTenSanPham(sp);
//                spct.setTenMauSac(ms);
//                spct.setTenChatlieu(cl);
//                spct.setTenNhanHieu(nh);
//                spct.setTenKichCo(kc);
//                spct.setMa(maspct);
//                spct.setSoLuong(soluong);
//                spct.setGiaBan1(gia);
//                spct.setNgayTao(ngaytao);
//                list.add(spct);
//            }
//            return list;
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
}
