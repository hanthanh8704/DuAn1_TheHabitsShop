/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.reponsitory;

import com.raven.classinterface.HoaDonInteface;
import com.raven.classmodel.HinhThucThanhToan;
import com.raven.classmodel.HoaDon;
import com.raven.classmodel.HoaDonChiTiet;
import com.raven.classmodel.KhachHang;
import com.raven.classmodel.LichSuHoaDon;
import com.raven.classmodel.NhanVien;
import com.raven.classmodel.ThanhToan;
import com.toedter.calendar.JDateChooser;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.sql.*;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author ADMIN
 */
public class HoaDonRepon implements HoaDonInteface {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;

    public ArrayList<HoaDon> getAll() {
        ArrayList<HoaDon> hoaDonList = new ArrayList<>();
        sql = """
          SELECT HoaDon.ma AS 'MaHD', NhanVien.ma, KhachHang.ten, KhachHang.sdt, HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
          HoaDon.tongtiencuahoadon,HoaDon.tongtiencuahoadonsaugiamgia, ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu, NhanVien.ten, KhachHang.ten AS tenKH, HoaDon.ngaytao 
          FROM HoaDon
          LEFT JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
          LEFT JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
          LEFT JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
          LEFT JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan  
          ORDER BY HoaDon.ngaythanhtoan DESC
          """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String mahd = rs.getString("MaHD");
                Timestamp ngaytaohd = rs.getTimestamp("ngaytaohoadon");
                Timestamp ngaythanhtoan = rs.getTimestamp("ngaythanhtoan");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                BigDecimal tongtiengg = rs.getBigDecimal("tongtiencuahoadonsaugiamgia");
                String HTThanhToan = rs.getString("tenhinhthuc");
                Integer tinhtrang = rs.getInt("trangthai");
                String ghichu = rs.getString("ghichu");

                String manv = rs.getString("ma");
                Timestamp ngaytao = rs.getTimestamp("ngaytao");
                String tenkh = rs.getString("ten");
                String sdt = rs.getString("sdt");

                NhanVien nv = new NhanVien();
                nv.setMaNV(manv);
                KhachHang kh = new KhachHang();
                kh.setTenKH(tenkh);
                kh.setSdt(sdt);
                ThanhToan th = new ThanhToan();
                th.setTenhinhthuc(HTThanhToan);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setThanhToan(th);
                hoaDon.setMa(mahd);
                hoaDon.setNgaytaohoadon(ngaytaohd);
                hoaDon.setNgaythanhtoan(ngaythanhtoan);
                hoaDon.setTongTienHoaDon(tongtien);
                hoaDon.setTongTienSauGiamGia(tongtiengg);
                hoaDon.setTinhTrang(tinhtrang);
                hoaDon.setGhichu(ghichu);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                hoaDon.setNgayTao(ngaytao);
                hoaDonList.add(hoaDon);
            }
            return hoaDonList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ArrayList<HoaDon> getList(int tinhtrang) {
        ArrayList<HoaDon> hoaDonList = new ArrayList<>();
        sql = """
              SELECT HoaDon.ma AS 'MaHD', NhanVien.ma, KhachHang.ten, KhachHang.sdt, HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
              HoaDon.tongtiencuahoadon,ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu,
              NhanVien.id AS 'idNV', NhanVien.ten, KhachHang.id AS idKH, KhachHang.ten AS tenKH FROM HoaDon
              JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
              JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
               JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
              JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan
              WHERE HoaDon.trangthai = ?
              """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, tinhtrang);
            ps.execute();
            //b3: đọc sữ liệu trả về
            rs = ps.executeQuery();
            while (rs.next()) {
                //UUID id = UUID.fromString(rs.getString(1));
                String mahd = rs.getString("MaHD");
                Date ngaytaohd = rs.getDate("ngaytaohoadon");
                Date ngaythanhtoan = rs.getDate("ngaythanhtoan");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                String HTThanhToan = rs.getString("tenhinhthuc");
                Integer tt = rs.getInt("trangthai");
                String ghichu = rs.getString("ghichu");
                UUID idnv = UUID.fromString(rs.getString("idNV"));
                String manv = rs.getString("ma");
                UUID idkh = UUID.fromString(rs.getString("idKH"));
                String tenkh = rs.getString("ten");
                String sdt = rs.getString("sdt");

                NhanVien nv = new NhanVien();
                nv.setId(idnv);
                nv.setMaNV(manv);
                KhachHang kh = new KhachHang();
                kh.setID(idkh);
                kh.setTenKH(tenkh);
                kh.setSdt(sdt);
                ThanhToan th = new ThanhToan();
                th.setTenhinhthuc(HTThanhToan);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setThanhToan(th);
                hoaDon.setMa(mahd);
                hoaDon.setNgaytaohoadon(ngaytaohd);
                hoaDon.setNgaythanhtoan(ngaythanhtoan);
                hoaDon.setTongTienHoaDon(tongtien);
                hoaDon.setTinhTrang(tt);
                hoaDon.setGhichu(ghichu);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                hoaDonList.add(hoaDon);
            }
            return hoaDonList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ArrayList<HoaDon> mouseClick() {
        ArrayList<HoaDon> hoaDonList = new ArrayList<>();
        sql = """
               SELECT HoaDon.ma AS 'MaHD', NhanVien.ma,NhanVien.ten AS 'TenNV', KhachHang.ten AS 'TenKH',
               KhachHang.sdt,HoaDon.diachi,HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
               HoaDon.tongtiencuahoadon,ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu,
               NhanVien.id AS 'idNV', NhanVien.ten, KhachHang.id AS idKH, KhachHang.ten AS tenKH FROM HoaDon
               JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
               JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
               JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
               JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan;
               """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                //UUID id = UUID.fromString(rs.getString(1));
                String mahd = rs.getString("MaHD");
                Date ngaytaohd = rs.getDate("ngaytaohoadon");
                Date ngaythanhtoan = rs.getDate("ngaythanhtoan");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                String tennv = rs.getString("TenNV");
                String HTThanhToan = rs.getString("tenhinhthuc");
                Integer tinhtrang = rs.getInt("trangthai");
                String ghichu = rs.getString("ghichu");
                UUID idnv = UUID.fromString(rs.getString("idNV"));
                String manv = rs.getString("ma");
                UUID idkh = UUID.fromString(rs.getString("idKH"));
                String tenkh = rs.getString("TenKH");
                String diachi = rs.getString("diachi");
                String sdt = rs.getString("sdt");

                NhanVien nv = new NhanVien();
                nv.setId(idnv);
                nv.setMaNV(manv);
                nv.setTenNV(tennv);
                KhachHang kh = new KhachHang();
                kh.setID(idkh);
                kh.setTenKH(tenkh);
                kh.setSdt(sdt);
                HinhThucThanhToan httt = new HinhThucThanhToan();
                ThanhToan th = new ThanhToan();
                th.setTenhinhthuc(HTThanhToan);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setThanhToan(th);
                hoaDon.setMa(mahd);
                hoaDon.setNgaytaohoadon(ngaytaohd);
                hoaDon.setNgaythanhtoan(ngaythanhtoan);
                hoaDon.setTongTienHoaDon(tongtien);
                hoaDon.setDiaChi(diachi);
                hoaDon.setHttt(httt);
                hoaDon.setTinhTrang(tinhtrang);
                hoaDon.setGhichu(ghichu);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                hoaDonList.add(hoaDon);
            }
            return hoaDonList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ArrayList<HoaDon> mouseClickTraHang() {
        ArrayList<HoaDon> listTraHang = new ArrayList<>();
        String sql = "SELECT HoaDon.ma, NhanVien.ten AS 'TenNV', KhachHang.ten AS 'TenKH',HoaDon.diachi,HoaDon.tongtiencuahoadon FROM HoaDon\n"
                + "JOIN KhachHang ON KhachHang.id = HoaDon.id_khachhang\n"
                + "JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id";
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String mahd = rs.getString("ma");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                String tennv = rs.getString("TenNV");
                String diachi = rs.getString("diachi");
                String tenkh = rs.getString("TenKH");
                NhanVien nv = new NhanVien();
                nv.setTenNV(tennv);
                KhachHang kh = new KhachHang();
                kh.setTenKH(tenkh);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setMa(mahd);
                hoaDon.setTongTienHoaDon(tongtien);
                hoaDon.setDiaChi(diachi);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                listTraHang.add(hoaDon);
            }
            return listTraHang;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<HoaDon> findDate(JDateChooser d1, JDateChooser d2) {
        List<HoaDon> listHD = new ArrayList<>();
        String sql = """
                                     SELECT HoaDon.ma AS 'MaHD', NhanVien.ma, KhachHang.ten, KhachHang.sdt, HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
                                     HoaDon.tongtiencuahoadon,HoaDon.tongtiencuahoadonsaugiamgia, ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu,
                                     NhanVien.id AS 'idNV', NhanVien.ten, KhachHang.id AS idKH, KhachHang.ten AS tenKH
                                     FROM HoaDon
                                     JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
                                     JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
                                      JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
                                     JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan
                                     WHERE HoaDon.ngaythanhtoan BETWEEN ? AND ?
                     """;

        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (d1.getDate() != null && d2.getDate() != null) {
                ps.setDate(1, new java.sql.Date(d1.getDate().getTime()));
                ps.setDate(2, new java.sql.Date(d2.getDate().getTime()));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String mahd = rs.getString("MaHD");
                    Date ngaytaohd = rs.getDate("ngaytaohoadon");
                    Date ngaythanhtoan = rs.getDate("ngaythanhtoan");
                    BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                    BigDecimal tongtiengg = rs.getBigDecimal("tongtiencuahoadonsaugiamgia");
                    String HTThanhToan = rs.getString("tenhinhthuc");
                    int tinhtrang = rs.getInt("trangthai");
                    String ghichu = rs.getString("ghichu");
                    UUID idnv = UUID.fromString(rs.getString("idNV"));
                    String manv = rs.getString("ma");
                    UUID idkh = UUID.fromString(rs.getString("idKH"));
                    String tenkh = rs.getString("ten");
                    String sdt = rs.getString("sdt");

                    NhanVien nv = new NhanVien();
                    nv.setId(idnv);
                    nv.setMaNV(manv);
                    KhachHang kh = new KhachHang();
                    kh.setID(idkh);
                    kh.setTenKH(tenkh);
                    kh.setSdt(sdt);
                    HinhThucThanhToan httt = new HinhThucThanhToan();
                    ThanhToan th = new ThanhToan();
                    th.setTenhinhthuc(HTThanhToan);
                    HoaDon hoaDon = new HoaDon();
                    hoaDon.setThanhToan(th);
                    hoaDon.setMa(mahd);
                    hoaDon.setNgaytaohoadon(ngaytaohd);
                    hoaDon.setNgaythanhtoan(ngaythanhtoan);
                    hoaDon.setTongTienHoaDon(tongtien);
                    hoaDon.setTongTienSauGiamGia(tongtiengg);
                    hoaDon.setHttt(httt);
                    hoaDon.setTinhTrang(tinhtrang);
                    hoaDon.setGhichu(ghichu);
                    hoaDon.setIdNhanVien(nv);
                    hoaDon.setIdKhachHang(kh);
                    listHD.add(hoaDon);
                }
                return listHD;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // lịch sử hóa đơn
    public List<LichSuHoaDon> getListHD() {
        List<LichSuHoaDon> listLSHD = new ArrayList<>();
        String sql = """
    SELECT NhanVien.ma,HoaDon.ngaytaohoadon,LichSuHoaDon.hanhdong FROM LichSuHoaDon
JOIN HoaDon ON LichSuHoaDon.id_hoadon = HoaDon.id
JOIN NhanVien ON NhanVien.id = HoaDon.id_nhanvien
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String ma = rs.getString("ma");
                String hanhdong = rs.getString("hanhdong");
                Date ngaytaohd = rs.getDate("ngaytaohoadon");

                NhanVien nv = new NhanVien();
                nv.setMaNV(ma);

                HoaDon hd = new HoaDon();
                hd.setMa(hanhdong);
                hd.setIdNhanVien(nv);
                hd.setNgaytaohoadon(ngaytaohd);

                LichSuHoaDon lshd = new LichSuHoaDon();
                lshd.setHoaDon(hd);
                hd.setIdNhanVien(nv);
            }
            return listLSHD;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<HoaDon> getLichSuHD() {
        List<HoaDon> listHD = new ArrayList<>();
        String sql = "SELECT NhanVien.ma,HoaDon.ngaytaohoadon,HoaDon.trangthai FROM HoaDon\n"
                + "JOIN NhanVien ON NhanVien.id = HoaDon.id_nhanvien";
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String ma = rs.getString("ma");
                Date ngayxacnhan = rs.getDate("ngaytaohoadon");
                Integer tinhtrang = rs.getInt("trangthai");

                NhanVien nv = new NhanVien();
                nv.setMaNV(ma);
                HoaDon hd = new HoaDon();
                hd.setNgaytaohoadon(ngayxacnhan);
                hd.setTinhTrang(tinhtrang);
                listHD.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int addHoaDonCho(HoaDon hd) {
        String sql = """
                     INSERT INTO [dbo].[HoaDon]
                                (
                                [ma]
                                ,[tennguoinhan]
                                ,[diachi]
                                ,[ngayxacnhan]
                                ,[phivc]
                                ,[ngaytaohoadon]
                                ,[ngayvanchuyen]
                                ,[ngaynhanhang]
                                ,[ngaythanhtoan]
                                ,[tongtiencuahoadon]
                                ,[tongtiencuahoadonsaugiamgia]
                                ,[trangthai]
                                ,[ghichu]
                                ,[id_khachhang]
                                ,[id_nhanvien]
                                ,[id_nguoitao]
                                ,[ngaytao]
                                ,[xoa_trangthai])
                          VALUES
                                (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, hd.getMa());
            ps.setObject(2, hd.getTenNguoiNhan());
            ps.setObject(3, hd.getDiaChi());
            ps.setObject(4, hd.getNgayXacNhan());
            ps.setObject(5, hd.getPhiVC());
            ps.setObject(6, hd.getNgaytaohoadon());
            ps.setObject(7, hd.getNgayVanChuyen());
            ps.setObject(8, hd.getNgaynhanHang());
            ps.setObject(9, hd.getNgaythanhtoan());
            ps.setObject(10, hd.getTongTienHoaDon());
            ps.setObject(11, hd.getTongTienSauGiamGia());
            ps.setObject(12, hd.getTinhTrang());
            ps.setObject(13, hd.getGhichu());
            ps.setObject(14, hd.getId_khachhang());
            ps.setObject(15, hd.getNhanvien_id());
            ps.setObject(16, hd.getNhanvien_id());
            ps.setObject(17, hd.getNgayTao());
            ps.setObject(18, hd.getXoa_tt());
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateHoaDon(HoaDon hd, String mahd) {
        String sql = """
                 UPDATE [dbo].[HoaDon]
                 SET
                    [tennguoinhan] = ?,
                    [diachi] = ?,
                    [ngayxacnhan] = ?,
                    [phivc] = ?,
                    [ngaytaohoadon] = ?,
                    [ngayvanchuyen] = ?,
                    [ngaynhanhang] = ?,
                    [ngaythanhtoan] = ?,
                    [tongtiencuahoadon] = ?,
                    [tongtiencuahoadonsaugiamgia] = ?,
                    [trangthai] = ?,
                    [ghichu] = ?,
                    [id_khachhang] = ?,
                    [id_nhanvien] = ?,
                    [id_nguoitao] = ?,
                    [ngaytao] = ?
                 WHERE [ma] = ?
                 """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, hd.getTenNguoiNhan());
            ps.setObject(2, hd.getDiaChi());
            ps.setObject(3, hd.getNgayXacNhan());
            ps.setObject(4, hd.getPhiVC());
            ps.setObject(5, hd.getNgaytaohoadon());
            ps.setObject(6, hd.getNgayVanChuyen());
            ps.setObject(7, hd.getNgaynhanHang());
            ps.setObject(8, hd.getNgaythanhtoan());
            ps.setObject(9, hd.getTongTienHoaDon());
            ps.setObject(10, hd.getTongTienSauGiamGia());
            ps.setObject(11, hd.getTinhTrang());
            ps.setObject(12, hd.getGhichu());
            ps.setObject(13, hd.getId_khachhang());
            ps.setObject(14, hd.getNhanvien_id());
            ps.setObject(15, hd.getId_nguoiTao());
            ps.setObject(16, hd.getNgayTao());
            ps.setObject(17, mahd); // Set the WHERE clause parameter
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public ArrayList<HoaDon> getCBB(Integer trangthai, String tenhinhthuc) {
        ArrayList<HoaDon> hoaDonList = new ArrayList<>();
        sql = """
                           SELECT HoaDon.ma AS 'MaHD', NhanVien.ma, KhachHang.ten, KhachHang.sdt,HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
                                                                                                  HoaDon.tongtiencuahoadon,HoaDon.tongtiencuahoadonsaugiamgia,ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu,
                                                                                                  NhanVien.id AS 'idNV', NhanVien.ten, KhachHang.id AS idKH, KhachHang.ten AS tenKH, HoaDon.ngaytao FROM HoaDon
                                                                                                    LEFT JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
                                                                                                    LEFT JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
                                                                                                    LEFT JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
                                                                                                    LEFT JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan  
                                                                                                  WHERE (HoaDon.trangthai = ? OR ? IS NULL OR 1 = '') AND
                                                        					 (ThanhToan.tenhinhthuc = ? OR ? IS NULL OR 1 = '')
                                                                                                  ORDER BY HoaDon.ngaythanhtoan DESC
                                          
              """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, trangthai);
            ps.setObject(2, trangthai);
            ps.setObject(3, tenhinhthuc);
            ps.setObject(4, tenhinhthuc);
            rs = ps.executeQuery();
            while (rs.next()) {
                //UUID id = UUID.fromString(rs.getString(1));
                String mahd = rs.getString("MaHD");
                Date ngaytaohd = rs.getDate("ngaytaohoadon");
                Date ngaythanhtoan = rs.getDate("ngaythanhtoan");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                BigDecimal tongtiengg = rs.getBigDecimal("tongtiencuahoadonsaugiamgia");
                String HTThanhToan = rs.getString("tenhinhthuc");
                Integer tinhtrang = rs.getInt("trangthai");
                String ghichu = rs.getString("ghichu");
                String manv = rs.getString("ma");
                Date ngaytao = rs.getDate("ngaytao");
                String tenkh = rs.getString("ten");
                String sdt = rs.getString("sdt");

                NhanVien nv = new NhanVien();
                nv.setMaNV(manv);
                KhachHang kh = new KhachHang();
                kh.setTenKH(tenkh);
                kh.setSdt(sdt);
                HinhThucThanhToan httt = new HinhThucThanhToan();
                ThanhToan th = new ThanhToan();
                th.setTenhinhthuc(HTThanhToan);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setThanhToan(th);
                hoaDon.setMa(mahd);
                hoaDon.setNgaytaohoadon(ngaytaohd);
                hoaDon.setNgaythanhtoan(ngaythanhtoan);
                hoaDon.setTongTienHoaDon(tongtien);
                hoaDon.setTongTienSauGiamGia(tongtiengg);
                httt.setId_thanhToan(th);
                hoaDon.setTinhTrang(tinhtrang);
                hoaDon.setGhichu(ghichu);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                hoaDon.setNgayTao(ngaytao);
                hoaDonList.add(hoaDon);
            }
            return hoaDonList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ArrayList<HoaDon> getCBBHTTT(String tenhinhthuc) {
        ArrayList<HoaDon> hoaDonList = new ArrayList<>();
        sql = """
              SELECT HoaDon.ma AS 'MaHD', NhanVien.ma, KhachHang.ten, KhachHang.sdt,HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
                                                        HoaDon.tongtiencuahoadon,ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu,
                                                        NhanVien.id AS 'idNV', NhanVien.ten, KhachHang.id AS idKH, KhachHang.ten AS tenKH, HoaDon.ngaytao FROM HoaDon
                                                          JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
                                                          JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
                                                          JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
                                                          JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan  
                                                        WHERE HinhThucThanhToan.id_thanhtoan = ?
                                                        ORDER BY HoaDon.ngaythanhtoan DESC                                          
              """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, tenhinhthuc);
            rs = ps.executeQuery();
            while (rs.next()) {
                //UUID id = UUID.fromString(rs.getString(1));
                String mahd = rs.getString("MaHD");
                Date ngaytaohd = rs.getDate("ngaytaohoadon");
                Date ngaythanhtoan = rs.getDate("ngaythanhtoan");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                String HTThanhToan = rs.getString("tenhinhthuc");
                Integer tinhtrang = rs.getInt("trangthai");
                String ghichu = rs.getString("ghichu");
                String manv = rs.getString("ma");
                Date ngaytao = rs.getDate("ngaytao");
                String tenkh = rs.getString("ten");
                String sdt = rs.getString("sdt");

                NhanVien nv = new NhanVien();
                nv.setMaNV(manv);
                KhachHang kh = new KhachHang();
                kh.setTenKH(tenkh);
                kh.setSdt(sdt);
                HinhThucThanhToan httt = new HinhThucThanhToan();
                ThanhToan th = new ThanhToan();
                th.setTenhinhthuc(HTThanhToan);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setThanhToan(th);
                hoaDon.setMa(mahd);
                hoaDon.setNgaytaohoadon(ngaytaohd);
                hoaDon.setNgaythanhtoan(ngaythanhtoan);
                hoaDon.setTongTienHoaDon(tongtien);
                httt.setId_thanhToan(th);
                hoaDon.setTinhTrang(tinhtrang);
                hoaDon.setGhichu(ghichu);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                hoaDon.setNgayTao(ngaytao);
                hoaDonList.add(hoaDon);
            }
            return hoaDonList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<HoaDon> timKiemHoaDon(String mahd) {
        List<HoaDon> listHD = new ArrayList<>();
        String sql = """
                     SELECT HoaDon.ma,KhachHang.ten,KhachHang.diachi,KhachHang.sdt,
                     KhachHang.email,HoaDon.tongtiencuahoadon,HoaDon.ghichu FROM HoaDon
                     JOIN KhachHang ON KhachHang.id = HoaDon.id_khachhang 
                     WHERE HoaDon.ma = ?
                     ORDER BY ngaythanhtoan DESC
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, mahd);
            rs = ps.executeQuery();
            while (rs.next()) {
                KhachHang kh = new KhachHang();
                kh.setTenKH(rs.getString("ten"));
                kh.setDiaChi(rs.getString("diachi"));
                kh.setSdt(rs.getString("sdt"));
                kh.setEmail(rs.getString("email"));
                HoaDon hd = new HoaDon();
                hd.setMa(rs.getString("ma"));
                hd.setGhichu(rs.getString("ghichu"));
                hd.setTongTienHoaDon(rs.getBigDecimal("tongtiencuahoadong"));
                hd.setIdKhachHang(kh);
                listHD.add(hd);
            }
            return listHD;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<String> getListMa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getTenKHById(UUID id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getMucGiamById(UUID id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getTenNVKHById(UUID id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<HoaDonChiTiet> getListById(UUID id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<HoaDon> getListByHTTT(UUID id) {
        String sql = "";
        return null;
    }

    @Override
    public List<HoaDon> getListByID(UUID id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public HoaDon findByMa(String ma) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Click hiển thị hdct
    public ArrayList<HoaDon> selectHDByMaHD(String mahoadon) {
        ArrayList<HoaDon> hoaDonList = new ArrayList<>();
        sql = """
          SELECT HoaDon.ma AS 'MaHD', NhanVien.ma, KhachHang.ten, KhachHang.sdt, HoaDon.ngaytaohoadon, HoaDon.ngaythanhtoan,
          HoaDon.tongtiencuahoadon, ThanhToan.tenhinhthuc, HoaDon.trangthai, HoaDon.ghichu, NhanVien.ten, KhachHang.ten AS tenKH, HoaDon.ngaytao 
          FROM HoaDon
          LEFT JOIN NhanVien ON HoaDon.id_nhanvien = NhanVien.id
          LEFT JOIN KhachHang ON HoaDon.id_khachhang = KhachHang.id
          LEFT JOIN HinhThucThanhToan ON HinhThucThanhToan.id_hoadon = HoaDon.id
          LEFT JOIN ThanhToan ON ThanhToan.id = HinhThucThanhToan.id_thanhtoan 
          WHERE HoaDon.ma = ?
          ORDER BY HoaDon.ngaythanhtoan DESC
          """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, mahoadon);
            rs = ps.executeQuery();
            while (rs.next()) {
                String mahd = rs.getString("MaHD");
                Timestamp ngaytaohd = rs.getTimestamp("ngaytaohoadon");
                Timestamp ngaythanhtoan = rs.getTimestamp("ngaythanhtoan");
                BigDecimal tongtien = rs.getBigDecimal("tongtiencuahoadon");
                String HTThanhToan = rs.getString("tenhinhthuc");
                Integer tinhtrang = rs.getInt("trangthai");
                String ghichu = rs.getString("ghichu");

                String manv = rs.getString("ma");
                Timestamp ngaytao = rs.getTimestamp("ngaytao");
                String tenkh = rs.getString("ten");
                String sdt = rs.getString("sdt");

                NhanVien nv = new NhanVien();
                nv.setMaNV(manv);
                KhachHang kh = new KhachHang();
                kh.setTenKH(tenkh);
                kh.setSdt(sdt);
                ThanhToan th = new ThanhToan();
                th.setTenhinhthuc(HTThanhToan);
                HoaDon hoaDon = new HoaDon();
                hoaDon.setThanhToan(th);
                hoaDon.setMa(mahd);
                hoaDon.setNgaytaohoadon(ngaytaohd);
                hoaDon.setNgaythanhtoan(ngaythanhtoan);
                hoaDon.setTongTienHoaDon(tongtien);
                hoaDon.setTinhTrang(tinhtrang);
                hoaDon.setGhichu(ghichu);
                hoaDon.setIdNhanVien(nv);
                hoaDon.setIdKhachHang(kh);
                hoaDon.setNgayTao(ngaytao);
                hoaDonList.add(hoaDon);
            }
            return hoaDonList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<LichSuHoaDon> selectLSHDByMaHD(String maLSHD) {
        List<LichSuHoaDon> listLSHD = new ArrayList<>();
        String sql = """
                        SELECT HoaDon.ma AS 'MaHD',NhanVien.ma,HoaDon.ngaytaohoadon,LichSuHoaDon.hanhdong FROM LichSuHoaDon
                        JOIN HoaDon ON LichSuHoaDon.id_hoadon = HoaDon.id
                        JOIN NhanVien ON NhanVien.id = HoaDon.id_nhanvien
                     WHERE HoaDon.ma = ? 
                     """;
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setObject(1, maLSHD);
            rs = ps.executeQuery();
            while (rs.next()) {
                String mahd = rs.getString("MaHD");
                String ma = rs.getString("ma");
                String hanhdong = rs.getString("hanhdong");
                Date ngaytaohd = rs.getDate("ngaytaohoadon");

                NhanVien nv = new NhanVien();
                nv.setMaNV(ma);

                HoaDon hd = new HoaDon();
                hd.setMa(mahd);
                hd.setNgaytaohoadon(ngaytaohd);

                LichSuHoaDon lshd = new LichSuHoaDon();
                lshd.setHoaDon(hd);
                lshd.setNhanVien(nv);
                lshd.setHanhdong(hanhdong);
                listLSHD.add(lshd);
            }
            return listLSHD;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
