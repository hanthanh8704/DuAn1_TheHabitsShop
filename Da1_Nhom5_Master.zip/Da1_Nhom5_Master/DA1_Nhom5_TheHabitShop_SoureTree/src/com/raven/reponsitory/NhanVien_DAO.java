/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.reponsitory;

import com.raven.classmodel.ChucVu;

import com.raven.classmodel.NhanVien;

import com.raven.classmodel.NhanVienRespose;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author MSI 15
 */
public class NhanVien_DAO {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;

    public void insert(Object entity) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getidChucVu(String chucVu) {
        String idCV = "";
        sql = """
                 SELECT  id from ChucVu where tencv = ?
                 """;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, chucVu);

            rs = ps.executeQuery();
            while (rs.next()) {
                chucVu = rs.getString(1);
            }
            return chucVu;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public boolean inertNV(NhanVienRespose nv) {
        sql = " insert into NhanVien(ma,ten,ngaysinh,diachi,"
                + "gioitinh,cccd,email,sdt,matkhau,id_chucvu,trangthai,xoa_trangthai) values(?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);

            ps.setObject(1, nv.getMaNV());
            ps.setObject(2, nv.getTenNV());
            ps.setObject(3, new java.sql.Date(nv.getNgaySinh().getTime()));
            ps.setObject(4, nv.getDiaChi());
            ps.setObject(5, nv.getGioiTinh());
            ps.setObject(6, nv.getCccd());
            ps.setObject(7, nv.getEmail());
            ps.setObject(8, nv.getSDT());
            ps.setObject(9, nv.getMatKhau());
            ps.setObject(10, UUID.fromString(nv.getId_chucvu()));
            ps.setObject(11, nv.getTrangThai());
            ps.setObject(12, nv.getXoa_trangthai());

            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public void update(Object entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int updateNhanVien(NhanVienRespose nv, String maNV) {
        sql = "UPDATE NhanVien SET ten=?, ngaysinh=?, diachi=?, gioitinh=?, cccd=?, email=?, sdt=?, trangthai=? ,id_chucvu =? WHERE ma=?";

        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, nv.getTenNV());
            ps.setObject(2, nv.getNgaySinh());
            ps.setObject(3, nv.getDiaChi());
            ps.setObject(4, nv.getGioiTinh());
            ps.setObject(5, nv.getCccd());
            ps.setObject(6, nv.getEmail());
            ps.setObject(7, nv.getSDT());
            ps.setObject(8, nv.getTrangThai());
            ps.setObject(9, nv.getId_chucvu());
            ps.setObject(10, maNV);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }

    }

    public int updateNV23(NhanVien nv, String maNV) {
        sql = "update NhanVien set ten=?,ngaysinh=?,diachi=?,gioitinh=?,cccd=?,email=?,"
                + "sdt=?,trangthai=?  where ma=?";

        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, nv.getTenNV());
            ps.setObject(2, nv.getNgaySinh());
            ps.setObject(3, nv.getDiaChi());
            ps.setObject(4, nv.getGioiTinh());
            ps.setObject(5, nv.getCccd());
            ps.setObject(6, nv.getEmail());
            ps.setObject(7, nv.getSDT());
            ps.setObject(8, nv.getTrangThai());
            ps.setObject(9, maNV
            );
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public void delete(Object id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int deleteID(String id) {
        sql = " delete from HoaDonTraHang where id_nhanvien =? \n"
                + " delete from NhanVien where id =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, id);
            ps.setObject(2, id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int delete(String ma) {
        sql = " delete from NhanVien where ma =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);

            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public String getIdNV_HoaDonTraHang(String ma) {
        // NhanVien nv = null;
        sql = "select id from NhanVien where ma=? ";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);

            rs = ps.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien(UUID.fromString(rs.getString(1)));
            }
        } catch (Exception e) {
            e.printStackTrace();
            //return null;
        }
        return null;
    }

    public String getIdNhanVien(String ma) {
        // NhanVien nv = null;
        sql = "select id from NhanVien where ma=? ";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);

            rs = ps.executeQuery();
            while (rs.next()) {
                ma = rs.getString(1);
            }
            return ma;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public List<NhanVien> selectAll() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        ArrayList<NhanVien> list = new ArrayList<>();
        sql = "select  NhanVien.ma, NhanVien.ten , ChucVu.tencv ,ngaysinh,cccd ,email,diachi,sdt ,gioitinh,trangthai "
                + " from NhanVien join ChucVu on NhanVien.id_chucvu = ChucVu.id";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ChucVu cv = new ChucVu(rs.getString(3));
                NhanVien nv = new NhanVien(rs.getString(1), rs.getString(2), cv,
                        rs.getDate(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getInt(9),
                        rs.getInt(10));
                list.add(nv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<NhanVien> selectAllPhanTrang(long trang) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        List<NhanVien> list = new ArrayList<>();
        sql = "select top 5  NhanVien.ma , ten , ChucVu.tencv,ngaysinh,cccd,email,diachi,sdt , gioitinh,trangthai"
                + " from NhanVien join ChucVu on NhanVien.id_chucvu = ChucVu.id where NhanVien.ma not in "
                + "(select top  " + (trang * 5 - 5) + " NhanVien.ma from NhanVien )order by NhanVien.ngaytao desc ";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ChucVu cv = new ChucVu(rs.getString(3));
                NhanVien nv = new NhanVien(rs.getString(1), rs.getString(2), cv,
                        rs.getDate(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getInt(9),
                        rs.getInt(10));
                list.add(nv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List selectBySql(String sql, Object... args) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public NhanVien selectByIdNhanVien(String ten) {
        NhanVien nv = null;
        sql = "select  NhanVien.ma, NhanVien.ten , ChucVu.tencv ,ngaysinh,cccd ,email,\n"
                + "diachi,sdt ,gioitinh,trangthai \n"
                + "from NhanVien join ChucVu on NhanVien.id_chucvu = ChucVu.id where NhanVien.ten like ?";
        List<NhanVien> listNH = new ArrayList<>();
        try {

            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, "%" + ten + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                ChucVu cv = new ChucVu(rs.getString(3));
                nv = new NhanVien(rs.getString(1), rs.getString(2), cv,
                        rs.getDate(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getInt(9),
                        rs.getInt(10));

                listNH.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return null;

    }

    public Object selectById(Object id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<NhanVien> timGioiTinh(boolean gioiTinh) {
        sql = "	select stt, ma ,ten,gioitinh,ngaysinh,diachi,sdt,cccd,email from NhanVien where gioitinh = ? ";
        NhanVien kh = null;
        List<NhanVien> listNH = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, "%" + gioiTinh + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                //kh = new NhanVien(rs.getInt(1), rs.getString(sql), sql, gioiTinh, ngaySinh, sql, sql, sql, sql)
                listNH.add(kh);
            }
            return listNH;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public NhanVien selectById(String maNV) {
        ArrayList<NhanVien> list = new ArrayList<>();
        sql = "select  NhanVien.ma, NhanVien.ten , ChucVu.tencv ,ngaysinh,cccd ,email,diachi,sdt ,gioitinh,trangthai "
                + " from NhanVien join ChucVu on NhanVien.id_chucvu = ChucVu.id where  NhanVien.ma=?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, maNV);
            rs = ps.executeQuery();
            while (rs.next()) {
                ChucVu cv = new ChucVu(rs.getString(3));
                NhanVien nv = new NhanVien(rs.getString(1), rs.getString(2), cv,
                        rs.getDate(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getInt(9),
                        rs.getInt(10));
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean checkSPSDT(String sdt) {
        String sql = "SELECT COUNT(*) FROM [dbo].[NhanVien] WHERE [sdt] = ?";

        try (Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sdt);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0; // Trả về true nếu tên sản phẩm đã tồn tại
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false; // Trả về false nếu có lỗi xảy ra
    }

    public boolean checkEmail(String email) {
        String sql = "SELECT COUNT(*) FROM [dbo].[NhanVien] WHERE [email] = ?";

        try (Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0; // Trả về true nếu tên sản phẩm đã tồn tại
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false; // Trả về false nếu có lỗi xảy ra
    }

    public boolean checkCCD(String email) {
        String sql = "SELECT COUNT(*) FROM [dbo].[NhanVien] WHERE [cccd] = ?";

        try (Connection con = DBConnect.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0; // Trả về true nếu tên sản phẩm đã tồn tại
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false; // Trả về false nếu có lỗi xảy ra
    }

    public int updateTrangThai(NhanVienRespose nv, int trangthai, String ma) {
        sql = "update NhanVien set ten=?,ngaysinh=?,diachi=?,gioitinh=?,cccd=?,email=?,sdt=?,trangthai=? where ma=?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, nv.getTenNV());
            ps.setObject(2, nv.getNgaySinh());
            ps.setObject(3, nv.getDiaChi());
            ps.setObject(4, nv.getGioiTinh());
            ps.setObject(5, nv.getCccd());
            ps.setObject(6, nv.getEmail());
            ps.setObject(7, nv.getSDT());
            ps.setObject(8, trangthai);
            ps.setObject(9, ma
            );
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}
