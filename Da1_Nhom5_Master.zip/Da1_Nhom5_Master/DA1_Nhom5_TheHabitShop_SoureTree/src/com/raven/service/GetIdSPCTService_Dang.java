/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.service;



/**
 *
 * @author ThanhDat
 */
public class GetIdSPCTService_Dang {

//    public Khuyenmai_service spct = new Khuyenmai_service();
//
//    public String getIDKhuyenMai(String ma) {
//        return spct.getidKhuyenMai(ma);
//    }
//
//    public String getIDSanPhamCT(String ma) {
//        return spct.getidSanPhamCT(ma);
//    }
//    public String getIDNhanVien(String ma) {
//        return spct.getidSanPhamCT(ma);
//    }
}
