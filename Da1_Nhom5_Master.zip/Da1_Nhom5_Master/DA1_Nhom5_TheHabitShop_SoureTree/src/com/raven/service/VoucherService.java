/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.service;

import com.raven.classinterface.TheHabitShop;
import com.raven.classmodel.Voucher;
import com.raven.reponsitory.DBConnect;
import com.toedter.calendar.JDateChooser;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;
import java.util.UUID;
import java.util.Date;
/**
 *
 * @author Ninh Than Thanh
 */
public class VoucherService implements TheHabitShop<Voucher, String>{

    Connection con = null;
    ResultSet rs = null;
    PreparedStatement ps = null;
    String sql = null;
    @Override
    
    public List<Voucher> getAll() {
        sql = "Select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai \n" +
"FROM Voucher order by ngaytao desc";
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Voucher> getAll1(int trangthai) {
        sql = "select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai from Voucher where trangthai = ? order by ngaytao desc";
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, trangthai);
            rs = ps.executeQuery();
            while(rs.next()){
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Voucher> loadData1(long trang,int trangthai){
        sql = "select top 5 ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai \n" +
"FROM Voucher WHERE ma NOT IN (SELECT TOP "+(trang*5-5)+" ma FROM Voucher) and trangthai =? order by ngaytao desc";// WHERE HOTEN NOT IN (SELECT TOP "+(trang*5-5)+" FROM STUDENTS)
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, trangthai);
            rs = ps.executeQuery();
            while(rs.next()){
                Voucher sv = new Voucher();
                   sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
                }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Voucher> findcbb(String loaiGiam) {
        sql = "select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai from Voucher where loaigiamgia = ?";
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, loaiGiam);
            rs = ps.executeQuery();
            while(rs.next()){
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Voucher> findcbbtt(int loaiGiam) {
        sql = "select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai from Voucher where trangthai = ?";
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, loaiGiam);
            rs = ps.executeQuery();
            while(rs.next()){
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Voucher> loadData(long trang){
        sql = "select top 5 ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai \n" +
"FROM Voucher WHERE ma NOT IN (SELECT TOP "+(trang*5-5)+" ma FROM Voucher) order by ngaytao desc";// WHERE HOTEN NOT IN (SELECT TOP "+(trang*5-5)+" FROM STUDENTS)
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher();
                sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), 
                        rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), 
                        rs.getTimestamp(6), rs.getTimestamp(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getIdVoucher(String id) {
        String idVoucher = " ";
        sql = "select id from Voucher where ma=? ";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, id);

            rs = ps.executeQuery();
            while (rs.next()) {
               idVoucher = rs.getString(1);
            }
            return idVoucher;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Voucher> find(JDateChooser d1, JDateChooser d2) {
        sql = "select ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc, trangthai from Voucher where ngaybatdau between  ? and ? ";
        List<Voucher> list  = new ArrayList<>();
        try {
            con= DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, d1.getDate());
            ps.setObject(2, d2.getDate());
            rs = ps.executeQuery();
            while(rs.next()){
                com.raven.classmodel.Voucher sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                list.add(sv);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public int insert(Voucher entity) {
        sql="INSERT INTO Voucher(ma,ten,giatrimax,loaigiamgia, giatrimin, ngaybatdau, ngayketthuc,trangthai,ngaytao) VALUES\n" +
"(?,?,?,?,?,?,?,?,?)";
        
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, entity.getMa());
            ps.setObject(2, entity.getTen());
            ps.setObject(3, entity.getGiatrimax());
            ps.setObject(4, entity.getLoaiGiamGia());
            ps.setObject(5, entity.getGiatrimin());
            ps.setObject(6, entity.getNgayBatDau());
            ps.setObject(7, entity.getNgayKetThuc());
            ps.setObject(8, entity.getTrangThai());
            ps.setObject(9, entity.getNgayTao());
//            ps.setObject(11, UUID.fromString(entity.getId_nv()));
//            ps.setObject(12, UUID.fromString(entity.getId_hd()));
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public int update(Voucher entity, String id) {
        sql="UPDATE Voucher SET ten=?,giatrimax=?,loaigiamgia=?,giatrimin=?,ngaybatdau=?,ngayketthuc=?,trangthai =?,ngaytao=? WHERE ma =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, entity.getTen());
            ps.setObject(2, entity.getGiatrimax());
            ps.setObject(3, entity.getLoaiGiamGia());
            ps.setObject(4, entity.getGiatrimin());
            ps.setObject(5, entity.getNgayBatDau());
            ps.setObject(6, entity.getNgayKetThuc());
            ps.setObject(7, entity.getTrangThai());
            ps.setObject(8, entity.getNgayTao());
            ps.setObject(9, id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int update1(Voucher entity, String ma) {
        sql="UPDATE Voucher SET trangthai =? where ma =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, entity.getTrangThai());
            ps.setObject(2, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int updateTT1(Voucher entity, String ma) {
        sql="UPDATE Voucher SET trangthai =1 where ma =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int updateTT2(Voucher entity, String ma) {
        sql="UPDATE Voucher SET trangthai =2 where ma =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int updateTT3(Voucher entity, String ma) {
        sql="UPDATE Voucher SET trangthai =3 where ma =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int update2(Voucher entity, String ma) {
        sql="UPDATE Voucher SET ngaybatdau =ngaytao, ngayketthuc = ngaytao, trangthai=3 where ma = ?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public int delete(String id) {
     sql= "delete from Voucher_KhachHang where id_voucher=?\n"+
             "DELETE FROM Voucher WHERE id = ?\n"
             ;
        try {
            con = DBConnect.getConnection();
            ps= con.prepareStatement(sql);
            ps.setObject(1, id);
            ps.setObject(2, id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public Voucher getID(String id) {
     com.raven.classmodel.Voucher sv = null;
        sql="select ma,ten,giatrimax,loaigiamgia,giatrimin, ngaybatdau, ngayketthuc, trangthai from Voucher where ma = ?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, id);
            rs =ps.executeQuery();
            while(rs.next()){
                sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                }
            return sv;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public Voucher getName(String id) {
     com.raven.classmodel.Voucher sv = null;
        sql="select ma,ten,giatrimax,loaigiamgia,giatrimin, ngaybatdau, ngayketthuc, trangthai from Voucher where ten = ?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, id);
            rs =ps.executeQuery();
            while(rs.next()){
                 sv = new com.raven.classmodel.Voucher(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),rs.getString(4),rs.getBigDecimal(5), rs.getDate(6), rs.getDate(7), rs.getInt(8));
                }
            return sv;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Voucher> getSql(String sql, Object... args) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
}
