/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.service;

import com.raven.classinterface.TheHabitShop;
import com.raven.classmodel.Voucher;
import com.raven.classmodel.Voucher_KhachHang;
import com.raven.reponsitory.DBConnect;
import java.util.List;
import java.sql.*;
/**
 *
 * @author Ninh Than Thanh
 */
public class voucher_KhachHangService implements TheHabitShop<Voucher_KhachHang, String>{
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement ps = null;
    String sql = null;
    
    public int insert(Voucher_KhachHang entity) {
        sql="""
            INSERT INTO [dbo].[Voucher_KhachHang]([ma],[trangthai],[id_voucher],[id_khachhang],[id_nguoitao],[ngaytao],[xoa_trangthai])
                 VALUES(?,?,?,?,?,?,?)
            """;
        
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, entity.getMa());
            ps.setObject(2, entity.getTrangthai());
            ps.setObject(3, entity.getId_Voucher());
            ps.setObject(4, entity.getId_KhachHang());
            ps.setObject(5, entity.getId_NguoiTao());
            ps.setObject(6, entity.getNgayTao());
            ps.setObject(7, entity.getXoaTT());
//            ps.setObject(11, UUID.fromString(entity.getId_nv()));
//            ps.setObject(12, UUID.fromString(entity.getId_hd()));
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public int updateTT1(Voucher entity, String ma) {
        sql="UPDATE Voucher_KhachHang SET trangthai =1 where id_voucher =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int updateTT2(Voucher entity, String ma) {
        sql="UPDATE Voucher_KhachHang SET trangthai =2 where id_voucher =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int updateTT3(Voucher entity, String ma) {
        sql="UPDATE Voucher_KhachHang SET trangthai =3 where id_voucher =?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ma);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int update(Voucher_KhachHang entity, String id) {
        sql="""
            UPDATE [dbo].[Voucher_KhachHang] set [trangthai]=?,[id_voucher]=?,
            [id_khachhang]=?,[id_nguoitao]=?,[ngaytao]=? where [id_voucher] = ?
            """;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, entity.getTrangthai());
            ps.setObject(2, entity.getId_Voucher());
            ps.setObject(3, entity.getId_KhachHang());
            ps.setObject(4, entity.getId_NguoiTao());
            ps.setObject(5, entity.getNgayTao());
            ps.setObject(6, id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public List<Voucher_KhachHang> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Voucher_KhachHang getID(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Voucher_KhachHang> getSql(String sql, Object... args) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
